# Google-Stimme einrichten

LittleChat kann die Antworten mit einer Stimme von Google Cloud Text-to-Speech vorlesen. Die neuen Stimmen (**Chirp 3 HD**) klingen sehr natürlich. Du brauchst ein Google-Cloud-Konto mit Zahlungsmittel und einen API-Schlüssel.

## Was es kostet (Stand 26.11.2026, laut Google-Preisseite)

- **Chirp 3 HD** (empfohlen, in LittleChat Standard): 1 Million Zeichen pro Monat gratis, danach 30 US-Dollar pro Million Zeichen. In der Google-Console in Euro: 26,94 EUR pro Million Zeichen ab der ersten Million (Stand 26.11.2026). LittleChat rechnet in Dollar, weil die Budgets in Dollar geführt werden.
- **Neural2**: 1 Million gratis, danach 16 Dollar pro Million.
- **WaveNet** und **Standard**: 4 Dollar pro Million. Gratis sind bei Standard 4 Millionen; bei WaveNet nennt Google auf verschiedenen Seiten 1 oder 4 Millionen (die Preistabelle sagt 4, die Produktseite 1). Den genauen Wert zeigt deine Cloud-Console unter Abrechnung › Preise.
- Grob: Eine Minute Vorlesen sind etwa 900 Zeichen. 1 Million Zeichen sind also rund 18 Stunden Vorlesen im Monat.
- Neukunden bekommen 300 Dollar Startguthaben. Es läuft nach einiger Zeit ab (Google nennt die Frist im Konto), sieh es nur als Bonus.

LittleChat rechnet die Kosten mit dem **vollen Preis** in die Monatsbudgets (Kind und gesamt) ein, das Gratiskontingent wird nicht abgezogen. So bremst das Budget eher zu früh als zu spät. Feste Ansagen (Begrüßung, Modi, Limits, Schloss) werden verschlüsselt auf dem Server gespeichert und kosten nur einmal.

Aktuelle Preise: [cloud.google.com/text-to-speech/pricing](https://cloud.google.com/text-to-speech/pricing)

## Konto und Budget-Limit

1. Öffne [console.cloud.google.com](https://console.cloud.google.com) und melde dich mit einem Google-Konto an.
2. Ein neues Projekt anlegen, z. B. „LittleChat“.
3. **Abrechnung** einrichten (Kreditkarte oder Konto). Ohne Zahlungsmittel geht die Sprach-Schnittstelle nicht, auch nicht im Gratiskontingent.
4. **Abrechnung › Budgets und Benachrichtigungen › Budget erstellen**: z. B. 5 Euro pro Monat, Benachrichtigung bei 50 %, 90 % und 100 %. **Wichtig:** Ein Google-Budget warnt nur per E-Mail, es stoppt nicht. Die harte Bremse ist das Monatsbudget in LittleChat.
5. Optional als echte Obergrenze: **APIs und Dienste › Cloud Text-to-Speech API › Kontingente** und dort die Zeichen pro Minute bzw. pro Tag begrenzen.

## Schnittstelle und Schlüssel

1. **APIs und Dienste › Bibliothek** › „Cloud Text-to-Speech API“ suchen › **Aktivieren**.
2. **APIs und Dienste › Anmeldedaten › Anmeldedaten erstellen › API-Schlüssel**.
3. Den Schlüssel **einschränken**: unter „API-Einschränkungen“ nur **Cloud Text-to-Speech API** erlauben. So kann ein geklauter Schlüssel nichts anderes in deinem Konto anstellen.
4. Den Schlüssel kopieren. Er beginnt meist mit `AIza`.

## In LittleChat eintragen

1. Eltern-Bereich › **Stimme** › „Google Cloud“ wählen.
2. Schlüssel einfügen, **Stimmen laden** (kostet nichts) und eine Stimme wählen. Die Liste ist nach Stimmtyp gruppiert, der Preis steht dabei: **Chirp 3 HD** (Standard, klingt am natürlichsten), **Neural2**, **WaveNet** und **Standard** (am günstigsten, klingt hörbar künstlicher). Am besten zwei, drei Typen probehören und dann entscheiden.
3. **▶ Probe** zum Anhören (kostet ein paar Zeichen, jede Probe nur einmal).
4. **Speichern und testen**. Ab jetzt sprechen alle Geräte mit dieser Stimme. Pro Kind kannst du bei „Kinder“ › Bearbeiten eine andere Stimme wählen.

> Was gesendet wird: nur der **Text**, der vorgelesen wird (Antworten und Ansagen, darin auch der Vorname des Kindes). Die Stimme deines Kindes geht nicht an Google. Laut Google werden die Texte nicht dauerhaft gespeichert.

> Fällt Google aus, ist der Schlüssel ungültig oder ein Budget erreicht, spricht automatisch **Piper** auf dem Server. Im Eltern-Bereich siehst du den Grund.

Die Menüs der Google-Console ändern sich gelegentlich. Die Schritte bleiben im Kern gleich: Projekt, Abrechnung, Budget, Schnittstelle aktivieren, eingeschränkter Schlüssel.

## Wenn es nicht klappt

- **„Google kennt diesen Schlüssel nicht“** (englisch: *API key not valid*): Der eingetragene Text ist kein gültiger API-Schlüssel. In der Console unter **APIs und Dienste › Anmeldedaten** beim API-Schlüssel auf **Schlüssel anzeigen** und das Kopier-Symbol tippen. Er beginnt mit `AIza` und hat 39 Zeichen. Nicht die OAuth-Client-ID (`…apps.googleusercontent.com`), kein Clientschlüssel (`GOCSPX-…`) und keine Dienstkonto-Datei (JSON). Ein frisch erstellter Schlüssel braucht manchmal ein paar Minuten. LittleChat entfernt mitkopierte Leerzeichen, Zeilenumbrüche und Anführungszeichen selbst.
- **„API ist nicht aktiviert“**: **APIs und Dienste › Bibliothek** › „Cloud Text-to-Speech API“ › **Aktivieren**, dann ein paar Minuten warten. Achte darauf, dass oben in der Console dasselbe Projekt gewählt ist, in dem der Schlüssel liegt.
- **„auf andere Google-Dienste eingeschränkt“**: beim Schlüssel unter **API-Einschränkungen** die Cloud Text-to-Speech API hinzufügen.
- **„Anwendungs-Einschränkung“**: beim Schlüssel **Anwendungseinschränkungen** auf **Keine** stellen. Der Schlüssel liegt ohnehin nur auf deinem Server.
- **„keine Abrechnung“**: Projekt unter **Abrechnung** mit einem Rechnungskonto verknüpfen.
