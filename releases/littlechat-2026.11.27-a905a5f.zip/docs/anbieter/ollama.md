# Ollama (lokal, kostenlos) einrichten

Mit Ollama läuft das Sprachmodell auf deinem eigenen Rechner. Das ist **kostenlos und privat**: Keine Frage verlässt dein Zuhause.

> **Ehrlich gesagt:** Auf einem NUC oder Mini-PC ohne starke Grafikkarte ist das **langsam** (oft 10 bis 60 Sekunden pro Antwort) und die Antworten sind spürbar **schwächer** als bei Claude. Kleine Modelle erfinden häufiger Fakten und haben keinen Schutzfilter des Anbieters. Für Kinder ist das eher etwas zum Ausprobieren als für den Alltag.

## Installieren

1. Ollama von [ollama.com/download](https://ollama.com/download) laden und auf dem Rechner installieren, auf dem LittleChat läuft.
2. Ein Modell laden, z. B. in PowerShell: `ollama pull gemma3:4b` (etwa 3 GB, kann Deutsch ordentlich). Auf schwacher Hardware lieber `gemma3:1b`, mit Grafikkarte auch größere Modelle.
3. Ollama läuft danach im Hintergrund unter `http://127.0.0.1:11434`.

## In LittleChat eintragen

1. Eltern-Bereich › **KI-Anbieter** › **Ollama (lokal)**.
2. Adresse stehen lassen (`http://127.0.0.1:11434`) und **Prüfen & speichern**. LittleChat zeigt die geladenen Modelle.
3. Häkchen setzen: **„Ich habe verstanden, ungetestet“**. Erst dann ist Ollama wählbar.
4. Ollama als Standard für alle Kinder oder nur für einzelne Kinder wählen und den Warnhinweis bestätigen.
5. Optional: **Jetzt testen** (Kinderfragen-Test) und die Antworten lesen. Lokal läuft das nacheinander und kann einige Minuten dauern.

Kosten: keine. Token zählen trotzdem für das Token-Limit pro Kind.

> **Verantwortung:** Eltern tragen die Verantwortung für die Nutzung durch ihre Kinder und haften im Rahmen ihrer Aufsichtspflicht. Behaltet Themen und Gespräche im Blick. Nutzung auf eigene Gefahr.
