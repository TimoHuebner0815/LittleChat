# Gesprächsmodi

Jede `.md`-Datei in diesem Ordner ist ein Modus, den das Kind auf dem Walkie-Talkie per Symbol wählt.
Der Text unter dem Kopf wird an die Persönlichkeit (`kid_persona.md`) und die Kinderschutz-Regeln
(`kid_safety.md`) angehängt. Die Kinderschutz-Regeln gelten in jedem Modus und gehen immer vor.

Eltern können den Text unter dem Kopf im Eltern-Bereich anpassen (Persönlichkeit › Gesprächsmodi). Ihre Fassung
liegt in der Datenbank und bleibt bei Updates erhalten; „Auf Standard zurücksetzen“ holt wieder diese Datei.
Der Kopf (Name, Symbol, Farbe, Ansage) kommt immer aus der Datei.

Kopf (zwischen den `---`-Zeilen):

| Feld     | Bedeutung |
|----------|-----------|
| `name`   | Anzeigename (Kind und Eltern) |
| `emoji`  | Symbol auf dem Knopf |
| `symbol` | So nennt die KI das Symbol, wenn sie auf den Knopf verweist, so wie es nach „Knopf mit …“ klingt (z. B. `dem Pinsel`) |
| `farbe`  | Knopffarbe (#rrggbb) |
| `reihe`  | Reihenfolge der Knöpfe |
| `ansage` | Wird vorgelesen, wenn das Kind den Modus antippt |
| `eltern` | Kurze Beschreibung im Eltern-Bereich |
| `avatare` | `ja`: In diesem Modus (ab Werk: „Avatar“) kann das Kind Avatare (Profilbilder) erfinden, höchstens 3 pro Kind |
| `figur-tipp` | `ja`: Hat das Kind noch keine Figur, schlägt die KI in diesem Modus vor, eine zu erfinden, und erklärt den Knopf (ab Werk: Langeweile) |

Platzhalter wie in der Persona: `{{NAME}}`, `{{AGE}}`, `{{APP}}` (Name des Assistenten, von Eltern änderbar).
Der Dateiname (ohne `.md`) ist die feste Kennung; nicht umbenennen, sonst verlieren Kinder die Freigabe.
Neue Dateien sind für alle Kinder automatisch freigeschaltet, außer die Eltern haben die Modi des Kindes
schon einmal eingeschränkt.
