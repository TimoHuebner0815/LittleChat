# Microsoft-Azure-Stimme einrichten

LittleChat kann mit den Neural-Stimmen von Azure AI Speech vorlesen, z. B. **Seraphina** (sehr natürlich) oder **Gisela** (eine Kinderstimme). Du brauchst ein Azure-Konto, eine **Speech-Ressource**, ihren **Schlüssel** und ihre **Region**.

## Was es kostet (Stand 26.11.2026)

- Kostenlose Stufe **F0**: 0,5 Millionen Zeichen pro Monat für Neural-Stimmen, dauerhaft gratis, danach ist für den Monat Schluss (kein Kostenrisiko).
- Stufe **S0** (Bezahlen nach Verbrauch): ca. 15 US-Dollar pro Million Zeichen, HD-Stimmen ca. 22 Dollar. Die offizielle Preisseite zeigt die Beträge erst nach Wahl von Region und Währung, die Zahlen hier stammen aus einem Vergleich vom November 2026, nicht direkt von Microsoft.
- Grob: Eine Minute Vorlesen sind etwa 900 Zeichen. 0,5 Millionen Zeichen sind rund 9 Stunden im Monat.

**Empfehlung:** mit F0 anfangen. Dann kann es gar nichts kosten. Ist das Kontingent aufgebraucht, spricht für den Rest des Monats Piper.

LittleChat rechnet die Kosten mit dem vollen Preis in die Monatsbudgets ein (auch bei F0, sicher ist sicher). Feste Ansagen werden verschlüsselt auf dem Server gespeichert und kosten nur einmal.

Aktuelle Preise: [azure.microsoft.com/pricing/details/speech](https://azure.microsoft.com/en-us/pricing/details/speech/)

## Konto, Ressource und Budget

1. Öffne [portal.azure.com](https://portal.azure.com) und melde dich an (ein kostenloses Azure-Konto braucht eine Kreditkarte zur Prüfung).
2. **Ressource erstellen** › „Speech“ suchen › **Speech** (Azure AI Speech) › Erstellen.
3. Region wählen, z. B. **Germany West Central** oder **West Europe**. Tarif: **Free F0**.
4. Bei S0: **Kostenverwaltung › Budgets** ein Budget setzen, z. B. 5 Euro. Auch hier gilt: Das Budget warnt, es stoppt nicht. Die harte Bremse ist das Monatsbudget in LittleChat.

## Schlüssel und Region

1. Die neue Speech-Ressource öffnen › **Schlüssel und Endpunkt**.
2. **Schlüssel 1** kopieren.
3. Die **Region** ablesen, so wie sie dort steht, z. B. `germanywestcentral` oder `westeurope`.

## In LittleChat eintragen

1. Eltern-Bereich › **Stimme** › „Microsoft Azure“ wählen.
2. Schlüssel und Region eintragen, **Stimmen laden** (kostet nichts), Stimme wählen.
3. **▶ Probe** zum Anhören, dann **Speichern und testen**.
4. Pro Kind eine andere Stimme: „Kinder“ › Bearbeiten › Stimme.

> Was gesendet wird: nur der **Text**, der vorgelesen wird (Antworten und Ansagen, darin auch der Vorname des Kindes), an die gewählte Azure-Region. Die Stimme deines Kindes geht nicht an Microsoft.

> Fällt Azure aus, ist das Kontingent leer oder ein Budget erreicht, spricht automatisch **Piper** auf dem Server.
