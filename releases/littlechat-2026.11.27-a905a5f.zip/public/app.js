// Oberfläche. Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, mit keinem KI-Anbieter verbunden. Kennt keinen API-Schlüssel; spricht nur mit dem eigenen Server.
const $ = (s) => document.querySelector(s);
const screens = ["setup", "wizard", "home", "talk", "parent"];
const show = (name) => { screens.forEach((s) => ($("#screen-" + s).hidden = s !== name));
  // Erwachsenen-Bereiche: ruhige Farben und klare Gliederung; Kinderansicht bleibt bunt
  document.body.classList.toggle("adult", ["parent", "wizard", "setup"].includes(name)); if (name !== "talk") setThemeColor(["parent", "wizard", "setup"].includes(name) ? "#f3f5f7" : null); setTimeout(() => wakeCheck(), 0); };
// Statusleiste (Android) in der Farbe des Kindes, sonst Standard
const THEME_DEFAULT = document.querySelector('meta[name="theme-color"]')?.content || "#3f63d6";
function setThemeColor(c) { const m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = c || THEME_DEFAULT; }
// Helle Kinderfarbe? Dann dunkle statt weißer Schrift (Kontrast zu Weiß unter 2,5:1, z. B. Gelb, Orange, Weiß).
function kidLight(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || ""); if (!m) return false;
  const lin = (i) => { const v = parseInt(m[1].slice(i, i + 2), 16) / 255; return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
  const L = 0.2126 * lin(0) + 0.7152 * lin(2) + 0.0722 * lin(4);
  return 1.05 / (L + 0.05) < 2.5;
}
function paintKid(el, color) { el.style.setProperty("--kid", color); el.classList.toggle("kid-light", kidLight(color)); }

// Zeitzone des Geräts (z. B. "Europe/Berlin"). Der Server nimmt nur die Zone, nie die Uhrzeit des Tablets.
const DEVICE_TZ = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch { return ""; } })();
const H = (extra = {}) => ({ "X-LC": "1", ...(DEVICE_TZ ? { "X-LC-TZ": DEVICE_TZ } : {}), ...extra });
async function api(path, { method = "GET", body } = {}) {
  const r = await fetch(path, {
    method,
    credentials: "same-origin",
    headers: H(body ? { "Content-Type": "application/json" } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = (r.headers.get("content-type") || "").includes("json") ? await r.json() : await r.text();
  if (r.status === 401 && path.startsWith("/api/parent") && parentOpen()) parentLock("Abgemeldet. Bitte neu anmelden.");
  if (!r.ok) throw Object.assign(new Error(data?.error || data?.say || "Fehler " + r.status), { status: r.status, data });
  return data;
}

// ------------------------------------------------------------------ Stimme
const store = {
  get: (k, d) => { try { return JSON.parse(localStorage.getItem("lc_" + k)) ?? d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem("lc_" + k, JSON.stringify(v)); } catch {} },
};
const synth = window.speechSynthesis;
let voices = [];
// Bewertet Systemstimmen nach Klangqualität: Premium/Natural/Enhanced und Google/Siri zuerst, Spaß-Stimmen raus.
const NOVELTY = /\b(eddy|flo|grandma|grandpa|oma|opa|reed|rocko|sandy|shelley|bad news|bells|boing|bubbles|cellos|good news|jester|organ|superstar|trinoids|whisper|wobble|zarvox|albert|fred|junior|kathy|ralph|bahh|hysterical|deranged|pipe organ)\b/i;
function voiceScore(v) {
  const n = v.name || "";
  let s = 0;
  if (NOVELTY.test(n)) s -= 1000;
  if (/premium/i.test(n)) s += 60;
  if (/natural|neural|online/i.test(n)) s += 55;
  if (/enhanced|erweitert|verbessert/i.test(n)) s += 45;
  if (/google/i.test(n)) s += 35;
  if (/siri/i.test(n)) s += 40;
  if (/compact|kompakt|espeak/i.test(n)) s -= 30;
  if (/anna|petra|helena|katja|marlene|vicki|seraphina|amala|louisa|elke|klarissa/i.test(n)) s += 8;
  if (/de[-_]DE/i.test(v.lang)) s += 5;
  return s;
}
function loadVoices() {
  if (!synth) return;
  voices = synth.getVoices().filter((v) => v.lang?.toLowerCase().startsWith("de")).sort((a, b) => voiceScore(b) - voiceScore(a));
  const sel = $("#voice");
  sel.innerHTML = "";
  sel.add(new Option(voices.length ? `Automatisch: beste Stimme (${voices[0].name})` : "Keine deutsche Stimme gefunden", ""));
  for (const v of voices) if (voiceScore(v) > -1000) sel.add(new Option(`${voiceScore(v) >= 40 ? "★ " : ""}${v.name} (${v.lang})`, v.voiceURI));
  sel.value = store.get("voice", "") || "";
  if (sel.selectedIndex < 0) sel.value = "";
}
if (synth) { loadVoices(); synth.onvoiceschanged = loadVoices; }
function pickVoice() {
  const saved = store.get("voice", "");
  return voices.find((v) => v.voiceURI === saved) || voices[0] || null;
}
function cleanForSpeech(t) {
  return t.replace(/[*_#`>~|]/g, "").replace(/\[(.*?)\]\(.*?\)/g, "$1").replace(/https?:\/\/\S+/g, "").replace(/\s+/g, " ").trim();
}
let speakQueue = 0;
function speakBrowser(t, done) {
  if (!synth) return done();
  const u = new SpeechSynthesisUtterance(t);
  u.onstart = () => showCaption(t);
  u.lang = "de-DE";
  const v = pickVoice();
  if (v) u.voice = v;
  u.rate = store.get("rate", 0.95);
  u.pitch = 1.08; // etwas heller und freundlicher, ohne Mickymaus-Effekt
  u.onend = done;
  u.onerror = (e) => { if (e?.error === "not-allowed") audioBlocked = true; done(); };
  synth.speak(u);
}
// Server-Stimme: jeden Satz sofort anfordern (läuft parallel), aber der Reihe nach abspielen.
const player = new Audio();
player.preload = "auto";
let ttsChain = Promise.resolve(), ttsGen = 0;
// Browser sperren Ton, solange niemand den Bildschirm berührt hat (iPad/Android fast immer beim App-Start)
let audioBlocked = false;
// Pro Kind kann eine eigene Stimme gelten (auch die Gerätestimme); ohne gewähltes Kind die Stimme für alle
const useServerVoice = () => (kid?.tts || state.tts) === "server" && (state.device || state.parent);
// Unterbrechen: stopSpeaking() löst „stopped“ aus. Jeder wartende oder spielende Satz hört sofort auf,
// statt die nächste Ansage hinter sich festzuhalten. Laufende Anfragen an den Server werden abgebrochen.
const waiter = () => { let resolve; const promise = new Promise((r) => (resolve = r)); return { promise, resolve }; };
let stopped = waiter(), ttsAbort = new AbortController(), fallbackGen = -1;
// Feste Ansagen bleiben auf dem Gerät: zweites Antippen spielt sofort, ohne Server.
// Schlüssel enthält den Fingerabdruck der Stimme, damit nach einem Stimmwechsel nichts Altes kommt.
const ttsBlobs = new Map(), ttsPrefetching = new Map(), TTS_BLOBS_MAX = 150;
const ttsKey = (t) => ((kid ? kid.ttsSig : state.ttsSig) || "") + "|" + t;
function blobPut(k, b) { ttsBlobs.delete(k); ttsBlobs.set(k, b); if (ttsBlobs.size > TTS_BLOBS_MAX) ttsBlobs.delete(ttsBlobs.keys().next().value); }
// Wartezeit, nach der ein Satz notfalls mit der Gerätestimme kommt (Server langsam oder nicht erreichbar)
const TTS_WAIT_FIXED = 4000, TTS_WAIT_ANSWER = 9000;
function fetchTts(t, fixed, signal, prefetch = false) {
  const k = fixed ? ttsKey(t) : null;
  if (k && ttsBlobs.has(k)) { const b = ttsBlobs.get(k); blobPut(k, b); return Promise.resolve(b); }
  if (k && ttsPrefetching.has(k)) return ttsPrefetching.get(k); // wird gerade vorgeladen: mitbenutzen
  // Bei einem Fehler des Servers einmal nachfassen, bevor auf die Systemstimme gewechselt wird:
  // sonst spricht z. B. die „Ich schlafe“-Ansage plötzlich mit einer anderen Stimme.
  const ask = () => fetch("/api/tts", { method: "POST", credentials: "same-origin", signal, headers: H({ "Content-Type": "application/json" }), body: JSON.stringify({ text: t, kidId: kid?.id, fixed, prefetch }) })
    .then((r) => (r.ok ? r.blob() : r.status >= 500 ? "retry" : null)).catch(() => (signal.aborted ? null : "retry"));
  const p = ask().then((b) => (b === "retry" && !signal.aborted ? new Promise((res) => setTimeout(res, 400)).then(ask) : b))
    .then((b) => (b && b !== "retry" ? b : null))
    .then((b) => { if (k && b) blobPut(k, b); return b; });
  if (k && prefetch) { ttsPrefetching.set(k, p); p.finally(() => ttsPrefetching.delete(k)); }
  return p;
}
function playBlob(blob, t, stop) {
  return new Promise((res) => {
    const url = URL.createObjectURL(blob);
    let over = false, guard = 0;
    const finish = () => {
      if (over) return;
      over = true; clearTimeout(guard);
      player.onended = player.onerror = player.onloadedmetadata = null;
      URL.revokeObjectURL(url);
      res();
    };
    stop.then(finish);
    player.onended = player.onerror = () => { if (player.src === url) finish(); };
    // Sicherheitsnetz: falls ein Gerät das Ende nie meldet, hängt nicht die ganze Sprachausgabe
    player.onloadedmetadata = () => { if (isFinite(player.duration)) { clearTimeout(guard); guard = setTimeout(finish, player.duration * 1000 + 1500); } };
    guard = setTimeout(finish, 60_000);
    player.src = url;
    showCaption(t);
    player.play().catch((e) => { if (e?.name === "NotAllowedError") audioBlocked = true; finish(); });
  });
}
function speakServer(t, done, fixed = false) {
  const gen = ttsGen, stop = stopped.promise;
  const audio = fetchTts(t, fixed, ttsAbort.signal);
  ttsChain = ttsChain.then(async () => {
    if (gen !== ttsGen) return;
    // Server zu langsam: diese Ansage mit der Gerätestimme zu Ende sprechen, statt das Kind warten zu lassen
    let slow;
    const blob = fallbackGen === gen ? null
      : await Promise.race([audio, stop.then(() => null), new Promise((res) => (slow = setTimeout(() => res("slow"), fixed ? TTS_WAIT_FIXED : TTS_WAIT_ANSWER)))]);
    clearTimeout(slow);
    if (gen !== ttsGen) return;
    if (!blob || blob === "slow") {
      fallbackGen = gen;
      return Promise.race([new Promise((res) => speakBrowser(t, res)), stop]);
    }
    await playBlob(blob, t, stop);
  }).catch(() => {}).then(done);
}
// Feste Ansagen im Hintergrund vorladen, damit sie beim Antippen sofort kommen. Nacheinander und beim
// Server hinten angestellt, damit nichts vor dem landet, was das Kind gerade hört.
let prefetchRun = 0;
async function prefetchSpeech(texts) {
  if (!useServerVoice() || !texts.length) return;
  const run = ++prefetchRun, signal = new AbortController().signal;
  for (const text of texts) {
    for (const part of splitSentences(cleanForSpeech(text))) {
      if (run !== prefetchRun) return;
      if (ttsBlobs.has(ttsKey(part))) continue;
      if (!(await fetchTts(part, true, signal, true))) return; // Server will oder kann nicht: nicht weiter drängeln
    }
  }
}
// fixed: feste Ansage (Begrüßung, Modi, Limits, Schloss). Der Server speichert sie bei Cloud-Stimmen, damit sie nur einmal kostet.
function speak(text, onDone, { fixed = false } = {}) {
  const t = cleanForSpeech(text);
  if (!t) { onDone?.(); return; }
  speakQueue++;
  let finished = false;
  const done = () => { if (finished) return; finished = true; speakQueue = Math.max(0, speakQueue - 1); if (!speakQueue) hideCaption(); onDone?.(); };
  // Lange Texte (Begrüßung, Erklärungen) satzweise: der erste Satz klingt sofort, keine Server-Anfrage
  // dauert zu lange, und die Untertitel laufen Satz für Satz mit.
  const parts = splitSentences(t);
  if (useServerVoice()) parts.forEach((p, i) => speakServer(p, i === parts.length - 1 ? done : () => {}, fixed));
  else if (synth) parts.forEach((p, i) => speakBrowser(p, i === parts.length - 1 ? done : () => {}));
  else done();
}
// ------------------------------------------------------------------ Untertitel
// Zeigt den Satz, der gerade vorgelesen wird, groß im Sprechbildschirm (pro Kind abschaltbar).
let captionTimer = 0;
function showCaption(t) {
  clearTimeout(captionTimer);
  const c = $("#caption");
  if (!c || !kid || kid.captions === false || $("#screen-talk").hidden) return;
  c.textContent = t;
  c.hidden = false;
  c.classList.add("on");
  $("#status").hidden = true; // Untertitel steht an der Stelle der Anzeige, damit nichts verrutscht
}
function hideCaption(now = false) {
  clearTimeout(captionTimer);
  const c = $("#caption");
  if (!c || c.hidden) return;
  // Den letzten Satz kurz stehen lassen, damit er zu Ende gelesen werden kann
  const off = () => { c.classList.remove("on"); c.hidden = true; c.textContent = ""; $("#status").hidden = false; };
  if (now) off(); else captionTimer = setTimeout(off, 2500);
}
function splitSentences(t, max = 220) {
  const out = [];
  for (const s of t.match(/[^.!?…]+[.!?…]+["“”»«]?\s*|[^.!?…]+$/g) || [t]) {
    const x = s.trim();
    if (!x) continue;
    // Sätze zusammenfassen, solange sie kurz sind; sehr lange Sätze an Kommas teilen
    if (out.length && (out.at(-1) + " " + x).length <= 120) out[out.length - 1] += " " + x;
    else if (x.length > max) out.push(...(x.match(new RegExp(`.{1,${max}}(,\\s|$)`, "g")) || [x]).map((y) => y.trim()).filter(Boolean));
    else out.push(x);
  }
  return out.length ? out : [t];
}
function stopSpeaking() {
  ttsGen++;
  stopped.resolve(); stopped = waiter();
  ttsAbort.abort(); ttsAbort = new AbortController();
  player.pause(); synth?.cancel(); speakQueue = 0; hideCaption(true);
}
// iOS/Android geben Ton nur frei, wenn er einmal aus einer Berührung heraus startet
const SILENCE = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=";
function unlockAudio() {
  audioBlocked = false;
  if (synth && !synth.speaking) synth.speak(Object.assign(new SpeechSynthesisUtterance(" "), { volume: 0 }));
  if (useServerVoice() && player.paused) { player.src = SILENCE; player.play().catch(() => {}); }
}

// ------------------------------------------------------------------ Start
let state = {};
let APP = "LittleChat";
async function boot() {
  state = await api("/api/state");
  // Neu geöffnete App (nicht nur neu geladen): eine übrig gebliebene Eltern-Anmeldung beenden.
  if (state.parent && !sess.get()) { await api("/api/logout", { method: "POST" }).catch(() => {}); state.parent = false; }
  APP = state.appName || APP;
  document.title = APP;
  document.querySelectorAll(".app-name").forEach((el) => (el.textContent = APP));
  if (!state.setup) return show("setup");
  return goHome({ greet: true });
}

// ------------------------------------------------------------------ Einrichtung
$("#setup-save").onclick = async () => {
  const pw = $("#setup-pw").value, pw2 = $("#setup-pw2").value;
  $("#setup-error").textContent = "";
  if (pw.length < 10) return ($("#setup-error").textContent = "Mindestens 10 Zeichen.");
  if (pw !== pw2) return ($("#setup-error").textContent = "Passwörter sind verschieden.");
  try {
    await api("/api/setup", { method: "POST", body: { code: $("#setup-code").value, password: pw } });
    parentLoggedIn();
    openWizard();
  } catch (e) { $("#setup-error").textContent = e.message; }
};

// ------------------------------------------------------------------ Kinder-Auswahl
async function goHome({ greet = false } = {}) {
  stopSpeaking();
  prefetchRun++; // Vorladen fürs vorige Kind beenden
  homeGreetWaiting = false;
  $("#home-hear").classList.remove("waiting");
  // Kinderansicht = Eltern sind fertig: immer abmelden, egal auf welchem Weg man hierher kommt
  if (sess.get()) { sess.set(false); await api("/api/logout", { method: "POST" }).catch(() => {}); }
  show("home");
  state = await api("/api/state");
  const list = $("#kid-list"), msg = $("#home-msg");
  list.innerHTML = "";
  msg.hidden = true;
  $("#pair-box").hidden = !!state.device;
  // Noch nicht gekoppelt: das erledigen Eltern, also ruhiges Eltern-Design statt Kinderauswahl
  document.body.classList.toggle("adult", !state.device);
  $("#home-title").hidden = !state.device;
  setThemeColor(state.device ? null : "#f3f5f7");
  renderInstall($("#install-home"));
  if (!state.device) {
    msg.hidden = false;
    msg.textContent = isStandalone() ? "Fast geschafft! Dieses Gerät muss nur noch gekoppelt werden." : "Dieses Gerät ist noch nicht freigegeben.";
    homeText = "";
    $("#home-hear").hidden = true;
    return;
  }
  const kids = await api("/api/kids");
  if (!kids.length) {
    msg.hidden = false;
    msg.textContent = "Noch keine Kinder angelegt. Eltern: Zahnrad oben rechts 2 Sekunden gedrückt halten.";
  }
  for (const k of kids) {
    const b = document.createElement("button");
    b.className = "kid";
    paintKid(b, k.color);
    b.innerHTML = `<span class="kid-avatar"></span><span class="kid-name"></span>`;
    if (k.avatar) b.querySelector(".kid-avatar").append(avatarImg(k.avatar, ""));
    else b.querySelector(".kid-avatar").textContent = k.name.slice(0, 1).toUpperCase();
    b.querySelector(".kid-name").textContent = k.name;
    if (k.locked) { const l = document.createElement("span"); l.className = "kid-lock"; l.textContent = "🔒"; l.setAttribute("aria-label", "abgeschlossen"); b.querySelector(".kid-avatar").append(l); }
    b.onclick = () => openTalk(k);
    list.append(b);
  }
  homeText = homeGreeting(kids);
  $("#home-hear").hidden = false;
  if (greet) greetHome();
}

// ------------------------------------------------------------------ Ansage beim Öffnen der App
// Beim Start erklärt LittleChat, was zu tun ist. Ohne vorherige Berührung blockieren die meisten Tablets
// den Ton. Dann pulsiert der Lautsprecher-Knopf, und die erste Berührung neben den Namen holt die Ansage nach.
let homeText = "", homeGreetWaiting = false;
function homeGreeting(kids) {
  if (!kids.length) return `Hallo! Ich bin ${APP}. Mama oder Papa müssen mich erst noch einrichten. Dann können wir reden.`;
  const anyLock = kids.some((k) => k.locked);
  const who = kids.length === 1 ? `Bist du ${kids[0].name}? Dann tipp auf deinen Namen.` : "Wer bist du? Tipp auf deinen Namen.";
  return `Hallo! Ich bin ${APP}. ${who} Dann können wir reden.` +
    (anyLock ? " Hast du ein Schloss, tippst du danach deine drei Farben." : "") +
    " Und wenn du das nochmal hören willst, drück auf den Lautsprecher.";
}
function speakHome() {
  homeGreetWaiting = false;
  $("#home-hear").classList.remove("waiting");
  stopSpeaking(); unlockAudio();
  if (homeText) speak(homeText, null, { fixed: true });
}
function greetHome() {
  if (!homeText || document.hidden) return;
  speak(homeText, null, { fixed: true });
  // Ob der Ton gesperrt war, zeigt sich erst nach dem ersten Abspielversuch (Server-Stimme braucht etwas)
  setTimeout(() => {
    if (!audioBlocked || $("#screen-home").hidden) return;
    stopSpeaking();
    homeGreetWaiting = true;
    $("#home-hear").classList.add("waiting");
  }, 2500);
}
$("#home-hear").onclick = (e) => { e.stopPropagation(); speakHome(); };
$("#screen-home").addEventListener("pointerup", (e) => {
  // Antippen eines Namens oder des Zahnrads hat eigene Ansagen
  if (!homeGreetWaiting || e.target.closest("button, input, dialog")) return;
  speakHome();
});

// ------------------------------------------------------------------ Bildschirm wach halten
// Solange die Kinderansicht offen ist, bleibt das Display an (Screen Wake Lock API). Nach X Minuten ohne
// Berührung (Eltern-Bereich, Standard 10) wird freigegeben, damit der Akku nicht leer läuft.
// Greift nicht überall: iPad/iPhone erst ab iOS 16.4, als App vom Home-Bildschirm erst ab iOS 18.4;
// sonst gilt die Einstellung „Automatische Sperre“ des Geräts. Braucht HTTPS (über Tailscale gegeben).
const WAKE_SUPPORTED = "wakeLock" in navigator;
let wakeLock = null, wakeAsking = false, wakeTouchedAt = Date.now();
async function wakeCheck() {
  const mins = state?.wakeMinutes ?? 10;
  const kidView = !$("#screen-home").hidden || !$("#screen-talk").hidden;
  const active = busy || holding || Date.now() - wakeTouchedAt < mins * 60_000;
  const want = WAKE_SUPPORTED && mins > 0 && kidView && !document.hidden && active;
  if (!want) { if (wakeLock) { const w = wakeLock; wakeLock = null; w.release().catch(() => {}); } return; }
  if (wakeLock || wakeAsking) return;
  wakeAsking = true;
  try {
    const w = await navigator.wakeLock.request("screen");
    w.addEventListener("release", () => { if (wakeLock === w) wakeLock = null; });
    wakeLock = w;
  } catch {} // z. B. Energiesparmodus oder Seite nicht sichtbar
  wakeAsking = false;
}
["pointerdown", "keydown"].forEach((ev) => document.addEventListener(ev, () => { wakeTouchedAt = Date.now(); wakeCheck(); }, { capture: true, passive: true }));
document.addEventListener("visibilitychange", () => { if (!document.hidden) wakeTouchedAt = Date.now(); wakeCheck(); });
// Tablets beenden die App beim Wegwischen oft nicht: wer sie nach einer Weile wieder öffnet, hört die Ansage auch
let homeHiddenAt = 0;
document.addEventListener("visibilitychange", () => {
  if (document.hidden) { homeHiddenAt = Date.now(); return; }
  if (homeHiddenAt && Date.now() - homeHiddenAt > 2 * 60_000 && !$("#screen-home").hidden && !document.querySelector("dialog[open]")) greetHome();
  homeHiddenAt = 0;
});
setInterval(wakeCheck, 15_000);

// ------------------------------------------------------------------ Eltern-Anmeldung absichern
// Kinder benutzen dieselben Tablets. Deshalb endet die Eltern-Anmeldung, wenn
//  - die App geschlossen wird (Sitzungs-Cookie + sessionStorage-Merker, beim Verlassen zusätzlich Abmelden),
//  - die App länger als 2 Minuten im Hintergrund war (iPad/Android beenden PWAs beim Wegwischen oft nicht),
//  - 3 Minuten nichts im Eltern-Bereich passiert ist (Server prüft das ebenfalls),
//  - „Fertig, zurück zum Kind“ gedrückt oder die Kinderansicht auf anderem Weg geöffnet wird.
const sess = {
  get: () => { try { return sessionStorage.getItem("lc_parent") === "1"; } catch { return false; } },
  set: (on) => { try { on ? sessionStorage.setItem("lc_parent", "1") : sessionStorage.removeItem("lc_parent"); } catch {} },
};
const HIDDEN_LOCK_MS = 2 * 60_000;
let parentActiveAt = Date.now(), hiddenAt = 0;
const parentOpen = () => !$("#screen-parent").hidden || !$("#screen-wizard").hidden;
function parentLoggedIn() { sess.set(true); parentActiveAt = Date.now(); }
function beaconLogout() {
  try { fetch("/api/logout", { method: "POST", credentials: "same-origin", headers: H(), keepalive: true }); } catch {}
}
let locking = false;
async function parentLock(reason) {
  if (locking) return;
  locking = true;
  sess.set(false);
  await api("/api/logout", { method: "POST" }).catch(() => {});
  document.querySelectorAll("dialog[open]").forEach((d) => d.close());
  await goHome().catch(() => {});
  if (reason) { $("#home-msg").hidden = false; $("#home-msg").textContent = reason; setTimeout(() => ($("#home-msg").hidden = true), 8000); }
  locking = false;
}
["pointerdown", "keydown", "input", "wheel"].forEach((ev) => document.addEventListener(ev, () => (parentActiveAt = Date.now()), { capture: true, passive: true }));
setInterval(() => {
  if (sess.get() && parentOpen() && Date.now() - parentActiveAt > (state?.parentIdleMin || 3) * 60_000)
    parentLock("Nach " + (state?.parentIdleMin || 3) + " Minuten ohne Aktion abgemeldet.");
}, 15_000);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) { hiddenAt = Date.now(); return; }
  // Im Einrichtungs-Assistenten nicht: dort holt man den API-Schlüssel oft aus einer anderen App.
  if (sess.get() && hiddenAt && Date.now() - hiddenAt > HIDDEN_LOCK_MS && $("#screen-wizard").hidden)
    parentLock("Die App war im Hintergrund. Bitte neu anmelden.");
  hiddenAt = 0;
});
// App oder Tab wird geschlossen: sofort abmelden (nicht bei bfcache, dann bleibt die Seite erhalten)
window.addEventListener("pagehide", (e) => { if (!e.persisted && sess.get() && !reloadingForUpdate) { sess.set(false); beaconLogout(); } });
let reloadingForUpdate = false;

// Eltern-Zahnrad: 2 Sekunden halten
(() => {
  const g = $("#parent-gear");
  let t;
  let opened = false, lastExplain = 0;
  const start = (e) => { e.preventDefault(); unlockAudio(); opened = false; g.classList.add("holding"); t = setTimeout(() => { opened = true; g.classList.remove("holding"); stopSpeaking(); askPassword(); }, 2000); };
  const cancel = () => { clearTimeout(t); g.classList.remove("holding"); };
  // Kurz angetippt: kindgerecht erklären, wofür das Zahnrad ist (höchstens alle 8 Sekunden)
  const explain = () => {
    if (opened || Date.now() - lastExplain < 8000) return;
    lastExplain = Date.now();
    stopSpeaking();
    speak(state.device
      ? "Das Zahnrad ist für Mama oder Papa. Dort stellen sie ein, wer mit mir reden darf und wie lange. Dafür braucht man ihr Passwort. Wenn du mit mir reden willst, tipp auf deinen Namen."
      : "Das Zahnrad ist für Mama oder Papa. Dort richten sie dieses Tablet ein. Dafür braucht man ihr Passwort.", null, { fixed: true });
  };
  g.addEventListener("pointerdown", start);
  g.addEventListener("pointerup", () => { cancel(); explain(); });
  ["pointerleave", "pointercancel"].forEach((ev) => g.addEventListener(ev, cancel));
  g.addEventListener("contextmenu", (e) => e.preventDefault());
})();

async function askPassword() {
  if ((await api("/api/state")).parent && sess.get()) return openParent();
  const d = $("#pw-dialog");
  $("#pw-input").value = "";
  $("#pw-error").textContent = "";
  d.showModal();
}
$("#pw-cancel").onclick = () => $("#pw-dialog").close();
$("#pw-form").addEventListener("submit", async (e) => {
  if (e.submitter && e.submitter.value !== "ok") return;
  e.preventDefault();
  try {
    await api("/api/login", { method: "POST", body: { password: $("#pw-input").value } });
    parentLoggedIn();
    $("#pw-dialog").close();
    openParent();
  } catch (err) { $("#pw-error").textContent = err.message; }
});

// ------------------------------------------------------------------ Walkie-Talkie
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
// Spracherkennung: im Browser (Standard) oder auf dem eigenen Server (lokaler Whisper), je nach Server-Einstellung
const serverStt = () => state.stt === "server" && !!navigator.mediaDevices?.getUserMedia && !!window.MediaRecorder;
const canListen = () => serverStt() || !!SR;
let kid = null, busy = false, heard = "", holding = false, abortCtl = null, convoId = null, bubbles = [], avatars = [], mode = null;

// Bis einschließlich 8 Jahre erklärt LittleChat jeden Knopf und jeden Bildschirm mit Stimme.
const EXPLAIN_MAX_AGE = 8;
const explainAll = (k = kid) => !!k && (k.age ?? 99) <= EXPLAIN_MAX_AGE;
function setStatus(text, mode) {
  $("#status").textContent = text;
  $("#screen-talk").dataset.mode = mode || "idle";
}
async function openTalk(k) {
  unlockAudio(); // läuft noch innerhalb des Antippens
  if (k.locked && !(await unlockKid(k))) return;
  kid = k;
  convoId = null;
  $("#talk-name").textContent = k.name;
  avatars = [];
  renderTalkAvatar();
  paintKid($("#screen-talk"), k.color);
  setThemeColor(k.color);
  $("#heard").textContent = "";
  $("#extend-open").hidden = true;
  $("#text-fallback").hidden = canListen();
  setStatus(canListen() ? "Drück und halte mich!" : "Hier kann ich leider nicht zuhören.", "idle");
  $("#talk-lock").textContent = k.locked ? "🔒" : "🔓";
  mode = pickMode(store.get("mode_" + k.id, ""));
  renderModes();
  show("talk");
  prewarmMic();
  await loadBubbles();
  // Begrüßung: einmal am Tag ausführlich, sonst kurz. Feste Ansage, kein API-Aufruf.
  const today = new Date().toDateString();
  const seen = store.get("intro_" + k.id, "");
  store.set("intro_" + k.id, today);
  playIntro(seen !== today);
  // Was das Kind als Nächstes antippen könnte, schon mal holen: Modi, Farbtopf, Fragezeichen
  const k2 = k;
  setTimeout(() => {
    if (kid !== k2) return;
    const list = (k2.modes || []).length > 1 ? k2.modes : [];
    prefetchSpeech([...list.map(modeSay), colorSay(k2), introText(k2, true), "Okay, ein neues Thema! Was möchtest du wissen?", "Plopp! Die Blase ist zerplatzt."]);
  }, 1500);
}
function introText(k, full) {
  const hasBubbles = bubbles.length > 0 || avatars.length > 0;
  const manyModes = (k.modes || []).length > 1;
  // Kleine Kinder hören jedes Mal, was alle Knöpfe machen; Größere nur einmal am Tag ausführlich
  const toolsHint = " Ganz oben sind noch drei Knöpfe: Mit dem Farbtopf suchst du dir deine Farbe aus. Mit dem Schloss schließt du dein Profil ab. " +
    "Und das Fragezeichen erklärt dir alles nochmal. Der Pfeil links bringt dich zurück zu den Namen.";
  if (!full && explainAll(k)) return `Hallo ${k.name}! Drück den großen Knopf und halt ihn fest, dann sag deine Frage. Wenn du loslässt, antworte ich.` +
    (manyModes ? " Mit den bunten Knöpfen oben suchst du aus, was wir machen." : "") +
    (hasBubbles ? " Tipp eine Seifenblase an, dann reden wir weiter darüber. Lang festhalten lässt sie zerplatzen." : "") +
    " Was die Knöpfe ganz oben machen, sagt dir das Fragezeichen.";
  if (!full) return `Hallo ${k.name}! Drück den großen Knopf, wenn du mich was fragen willst.` +
    (manyModes ? " Mit den bunten Knöpfen oben suchst du aus, was wir machen." : "") +
    (hasBubbles ? " Oder tipp eine Seifenblase an. Lang drücken lässt sie zerplatzen." : "") +
    (avatars.length ? " Die Blasen mit deinen Figuren kannst du antippen, dann kannst du sie ändern oder zu deinem Bild beim Namen machen." : "");
  const modeHint = !manyModes ? "" : k.age >= 10
    ? ` Mit den bunten Knöpfen oben wählst du, wie wir reden: ${k.modes.map((m) => m.name).join(", ").replace(/, ([^,]*)$/, " oder $1")}. Tipp einen an, dann erkläre ich ihn.`
    : " Oben sind bunte Knöpfe mit Bildern. Damit suchst du aus, was wir zusammen machen, zum Beispiel lernen, eine Geschichte erfinden oder ein Spiel gegen Langeweile. Tipp einfach einen an, dann sage ich dir, was er macht.";
  const bubbleHint = hasBubbles
    ? (k.age >= 10
      ? " Die Seifenblasen oben sind unsere letzten Gespräche. Tipp eine an, dann machen wir dort weiter. Hältst du eine lange gedrückt, zerplatzt sie."
      : " Siehst du die Seifenblasen? Da drin sind unsere Erinnerungen. Tipp eine an, dann reden wir weiter darüber. Und wenn du eine ganz lange festhältst, macht sie Plopp und ist weg.")
    : "";
  const avatarHint = !avatars.length ? ""
    : ` In ${avatars.length === 1 ? "einer Blase wohnt deine Figur" : "manchen Blasen wohnen deine Figuren"}. Tipp drauf, dann kannst du sie zu deinem Bild beim Namen machen oder etwas an ihr ändern. Lange festhalten löscht sie, ich frage aber vorher nach.`;
  if (k.age >= 10)
    return `Hallo ${k.name}, hier ist ${APP}. Ich bin eine KI, also ein Computerprogramm, kein Mensch. So funktioniert es: Halte den großen Knopf gedrückt und stell deine Frage. ` +
      `Wenn du loslässt, antworte ich. Du kannst mich alles fragen, was dich interessiert, oder mit mir ein Quiz machen. ` +
      `Wenn ich zu lange rede, drück einfach wieder auf den Knopf.` + modeHint + bubbleHint + avatarHint +
      " Oben rechts wählst du mit dem Farbtopf deine Farbe, das Schloss schließt dein Profil ab.";
  return `Hallo ${k.name}! Ich bin ${APP}. Ich bin kein Mensch, sondern ein Computerprogramm, das sprechen kann. Ich bin wie ein Walkie-Talkie. ` +
    `Drück den großen Knopf und halt ihn fest. Dann sag deine Frage. Wenn du fertig bist, lass den Knopf los. ` +
    `Dann denke ich kurz nach und antworte dir. Du kannst mich alles fragen, was du wissen willst.` + modeHint + bubbleHint + avatarHint + toolsHint + ` Probier es mal aus!`;
}

// ------------------------------------------------------------------ Gesprächsmodi
// Das Kind wählt per Symbol, was es machen will. Antippen sagt den Modus an und beginnt ein neues Gespräch.
// Eine Seifenblase bringt ihren eigenen Modus mit.
function pickMode(id) {
  const list = kid?.modes || [];
  return (list.find((m) => m.id === id) || list.find((m) => m.id === "erkunden") || list[0])?.id || null;
}
const modeOf = (id) => (kid?.modes || []).find((m) => m.id === id) || null;
function renderModes() {
  const box = $("#modes");
  const list = kid?.modes || [];
  box.innerHTML = "";
  box.hidden = list.length < 2; // nur ein Modus freigeschaltet: keine Auswahl nötig
  for (const m of list) {
    const b = document.createElement("button");
    b.className = "mode" + (m.id === mode ? " on" : "");
    b.style.setProperty("--m", m.color);
    b.setAttribute("aria-label", m.name);
    b.setAttribute("aria-pressed", String(m.id === mode));
    b.innerHTML = `<span class="mode-icon"></span><span class="mode-name"></span>`;
    b.querySelector(".mode-icon").textContent = m.emoji;
    b.querySelector(".mode-name").textContent = m.name;
    b.onclick = () => chooseMode(m);
    box.append(b);
  }
}
function setMode(id) {
  if (!id || id === mode || !modeOf(id)) return;
  mode = id;
  renderModes();
}
function chooseMode(m) {
  abortCtl?.abort();
  stopSpeaking();
  unlockAudio();
  mode = m.id;
  store.set("mode_" + kid.id, m.id);
  convoId = null; // neuer Modus = neues Gespräch
  renderModes();
  renderBubbles();
  setStatus(m.emoji + " " + m.name, "speaking");
  speak(modeSay(m), idleIfDone, { fixed: true });
}
function modeSay(m) {
  // Figur-Knopf (Avatare): sagt, wie viele Figuren es schon gibt und wie es geht
  const offer = !m.avatars ? ""
    : !avatars.length ? ` Du hast noch keine eigene Figur, ${kid.name}. Drück den großen Knopf und erzähl mir, wie sie aussehen soll!`
    : avatars.length < 3 ? ` Deine Figuren fliegen oben in den Seifenblasen. Willst du noch eine erfinden? Dann erzähl mir einfach, wie sie aussehen soll. Antippen einer Figur-Blase ändert sie.`
    : ` Du hast schon drei Figuren, mehr passen nicht. Tipp eine an, dann kannst du sie ändern. Lange festhalten löscht sie, dann ist Platz für eine neue.`;
  return m.say + offer;
}

// ------------------------------------------------------------------ Seifenblasen (Erinnerungen)
async function loadBubbles() {
  if (!kid) return;
  const q = "?kidId=" + encodeURIComponent(kid.id);
  const before = new Set(bubbles.map((c) => c.id));
  [bubbles, avatars] = await Promise.all([api("/api/bubbles" + q).catch(() => []), api("/api/avatars" + q).catch(() => [])]);
  // Themenwechsel: der Server hat das Gespräch geteilt. Die neue Blase löst sich sanft aus der alten
  // (startet an deren Platz, klein, und wächst), und hier geht das Gespräch weiter. Keine Ansage, das Kind redet einfach weiter.
  for (const c of bubbles) {
    if (!c.splitFrom || before.has(c.id)) continue;
    if (c.splitFrom === convoId) convoId = c.id;
    const from = flight.get(c.splitFrom);
    if (from && !flight.has(c.id)) flight.set(c.id, { x: from.x, y: from.y, vx: -from.vx || 12, vy: -from.vy || -8, bud: true });
  }
  renderBubbles();
}
// Seifenblasen fliegen über den ganzen Kinder-Bildschirm, auch hinter der Kopfzeile. Sie steigen sanft nach oben
// (Auftrieb) und weichen allen Knöpfen, der Anzeige und dem Text aus. Unten gibt es eine Sperrzone über die ganze
// Breite: Neben und über der Sprechtaste liegt nie eine antippbare Blase, damit kein Kind beim Drücken das Gespräch wechselt.
// Größe: wächst mit der Gesprächszeit (ab 30 Minuten 1,8-mal so groß). Nur die letzten RECENT Gespräche sind groß,
// ältere werden klein und blass und treiben an den linken oder rechten Rand.
const flight = new Map(); // id -> { x, y, vx, vy } bleibt über Neuzeichnen erhalten
let flightRaf = 0, flightLast = 0;
// Windows mit ausgeschalteten „Animationseffekten“ (und iPad mit „Bewegung reduzieren“) melden prefers-reduced-motion.
// Dann schweben die Blasen trotzdem, nur halb so schnell; Wackeln und Platz-Effekte bleiben aus.
const REDUCED_MOTION = matchMedia("(prefers-reduced-motion: reduce)").matches;
const FLIGHT_SPEED = REDUCED_MOTION ? 0.5 : 1;
const RECENT = 6;            // so viele Gespräche bleiben groß
const OLD_SCALE = 0.68;      // ältere Blasen: so viel kleiner
const TITLE_H = 30;          // Platz für den Titel unter einer Blase (gehört zur Tippfläche)
const KEEP_OFF = 10;         // Abstand zu Knöpfen und Anzeige
const PTT_ZONE = 28;         // Sperrzone über der Sprechtaste (zusätzlich zu ihrem Leuchtring)
const BUOYANCY = 9;          // Auftrieb nach oben (px/s²): die Blasen halten sich bevorzugt oben auf
const MIN_TAP = 44;          // kleinste Blase: noch gut antippbar
const TOP_GAP = 4;           // Abstand zum Rand oben und seitlich (Abzeichen und Leuchten bleiben sichtbar)
function bubbleScale(minutes) { return 1 + 0.8 * Math.min(1, Math.sqrt(Math.max(0, minutes || 0) / 30)); }
// Freie Fläche: Rechtecke, in die keine Blase darf (relativ zum Blasen-Feld), und die Untergrenze über der Sprechtaste
function bubbleField() {
  const box = $("#bubbles"), o = box.getBoundingClientRect();
  const rect = (el, pad = KEEP_OFF) => {
    const r = el.getBoundingClientRect();
    return r.width && r.height ? { l: r.left - o.left - pad, t: r.top - o.top - pad, r: r.right - o.left + pad, b: r.bottom - o.top + pad } : null;
  };
  const els = [...document.querySelectorAll("#screen-talk .talk-head button, #screen-talk .talk-who, #modes:not([hidden]) .mode, #status, #extend-open:not([hidden]), #text-fallback:not([hidden])"),
    ...["#caption", "#heard"].map((q) => $(q)).filter((el) => !el.hidden && el.textContent.trim())];
  const ptt = $("#ptt").getBoundingClientRect(), dock = $(".talk-dock").getBoundingClientRect();
  const floor = Math.min(ptt.top - 14 - PTT_ZONE, dock.top) - o.top; // 14 px: Leuchtring um die Taste
  const fl = { W: box.clientWidth, floor: Math.max(0, floor), walls: els.map((el) => rect(el)).filter(Boolean) };
  // freie Plätze für die kleinste Blase (12-px-Raster): Ziel für eingeklemmte Blasen und Maß für die freie Fläche
  fl.spots = [];
  for (let y = TOP_GAP; y + MIN_TAP + 6 <= fl.floor; y += 12) for (let x = 0; x + MIN_TAP <= fl.W; x += 12)
    if (!fl.walls.some((w) => hits({ x, y, size: MIN_TAP, th: 6 }, w))) fl.spots.push({ x, y });
  return fl;
}
// Blase aus einem Rechteck schieben. Blase = Kreis + Titel darunter, als Rechteck gerechnet. Sie geht auf die Seite
// zurück, von der sie kam (px/py = Stand vor dem Schritt), sonst nimmt sie den kürzesten Weg, der im Feld bleibt.
// So kann eine Blase, die von anderen nach oben gedrückt wird, nie durch eine Knopfreihe hindurchrutschen.
const hits = (f, w) => !(f.x >= w.r || f.x + f.size <= w.l || f.y >= w.b || f.y + f.size + f.th <= w.t);
function keepOut(f, w, fl) {
  if (!hits(f, w)) return;
  const h = f.size + f.th;
  const left = f.x + f.size - w.l, right = w.r - f.x, up = f.y + h - w.t, down = w.b - f.y;
  const px = f.px ?? f.x, py = f.py ?? f.y;
  let m;
  if (py >= w.b - 0.5) m = down;
  else if (py + h <= w.t + 0.5) m = up;
  else if (px >= w.r - 0.5) m = right;
  else if (px + f.size <= w.l + 0.5) m = left;
  else {
    const ok = [[left, f.x - left >= 0], [right, f.x + right + f.size <= fl.W], [up, f.y - up >= 0], [down, f.y + down + h <= fl.floor]].filter((d) => d[1]);
    m = Math.min(...(ok.length ? ok : [[left], [right], [up], [down]]).map((d) => d[0]));
  }
  if (m === up) { f.y -= up; f.vy = -Math.abs(f.vy); }
  else if (m === down) { f.y += down; f.vy = Math.abs(f.vy); }
  else if (m === left) { f.x -= left; f.vx = -Math.abs(f.vx); }
  else { f.x += right; f.vx = Math.abs(f.vx); }
}
// Steckt eine Blase trotzdem fest (zwischen Knöpfen eingeklemmt, Bildschirm gedreht), ist sie nicht antippbar
// und schwebt zurück in die freie Mitte. Erst dort wird sie wieder antippbar.
function unstick(f, fl) {
  f.stuck = fl.walls.some((w) => hits(f, w));
  f.el.classList.toggle("stuck", f.stuck);
}
function keepInside(f, fl) {
  const maxX = Math.max(TOP_GAP, fl.W - f.size - TOP_GAP), maxY = Math.max(0, fl.floor - f.size - f.th);
  if (f.x < TOP_GAP) { f.x = TOP_GAP; f.vx = Math.abs(f.vx); } else if (f.x > maxX) { f.x = maxX; f.vx = -Math.abs(f.vx); }
  if (f.y < TOP_GAP) { f.y = TOP_GAP; f.vy = Math.abs(f.vy) * 0.5; } else if (f.y > maxY) { f.y = maxY; f.vy = -Math.abs(f.vy); }
}
function renderBubbles() {
  const box = $("#bubbles");
  // Nie neu aufbauen, während ein Finger auf einer Blase liegt: sonst verliert das Halten sein Element
  if (box.querySelector(".bubble.pressing")) { clearTimeout(renderBubbles.later); renderBubbles.later = setTimeout(renderBubbles, 300); return; }
  box.innerHTML = "";
  box.hidden = !bubbles.length && !avatars.length;
  $("#bubble-room").hidden = box.hidden;
  if (box.hidden) { stopFlight(); return; }
  // Reihenfolge: Neues Thema, Figuren, dann Gespräche (neueste zuerst). Die ersten RECENT Gespräche sind groß.
  const items = [{ id: null, emoji: "✨", title: "Neues Thema", minutes: 0 },
    ...avatars.map((a) => ({ ...a, avatar: true, minutes: 12 })), ...bubbles.map((c, i) => (i < RECENT ? c : { ...c, old: true }))];
  const fl = bubbleField();
  const base = Math.min(84, Math.max(62, innerWidth * 0.15));
  const maxB = Math.max(base, Math.min(base * 1.8, fl.floor / 3)); // große Blasen dürfen das Feld nicht verstopfen
  // Passt alles in die freie Fläche? Sonst alle Blasen gleichmäßig kleiner (nie unter MIN_TAP, gut antippbar).
  // Reicht auch das nicht (kleines Handy), fallen die ältesten weg. Eltern sehen sie weiter, das Kind findet sie wieder,
  // sobald neuere zerplatzen. Bedarf je Blase: Kreis + Titel + Abstand, mal 1,6 Luft, damit sie noch schweben können.
  // Freie Fläche: alle Rasterfelder, die eine kleinste Blase an einem freien Platz bedecken (keine schmalen Ritzen)
  const G = 12, cols = Math.ceil(fl.W / G) + 1, cells = new Uint8Array(cols * (Math.ceil(fl.floor / G) + 1));
  for (const { x, y } of fl.spots)
    for (let cy = Math.round(y / G); cy < Math.round((y + MIN_TAP + 6) / G); cy++) for (let cx = x / G; cx < Math.round((x + MIN_TAP) / G); cx++) cells[cy * cols + cx] = 1;
  const free = cells.reduce((a, v) => a + v, 0) * G * G;
  const want = (c) => (c.old ? base * OLD_SCALE : Math.min(maxB, base * bubbleScale(c.minutes)));
  // Sehr eng (Handy): Titel fallen weg, das Bild reicht. Das Kind hört den Titel beim Antippen ohnehin.
  const titleH = (c, compact) => (c.old || compact ? 6 : TITLE_H);
  const need = (list, k, compact) => list.reduce((a, c) => { const d = Math.max(MIN_TAP, want(c) * k); return a + (d + 8) * (d + titleH(c, compact) + 8) * 1.6; }, 0);
  const compact = need(items, 0, false) > free;
  while (items.length > 3 && need(items, 0, compact) > free) items.pop();
  let fit = 1;
  if (need(items, 1, compact) > free) {
    let lo = 0, hi = 1;
    for (let k = 0; k < 12; k++) { const mid = (lo + hi) / 2; if (need(items, mid, compact) <= free) lo = mid; else hi = mid; }
    fit = lo;
  }
  const keep = new Set();
  items.forEach((c, i) => {
    const key = c.id || "new";
    keep.add(key);
    const size = Math.round(Math.max(MIN_TAP, want(c) * fit));
    const b = document.createElement("button");
    b.className = "bubble" + (c.avatar ? " avatar" + (c.active ? " current" : "") : c.id === convoId ? " active" : "") + (c.id === null ? " fresh" : "");
    if (c.id && !c.avatar) b.dataset.convo = c.id;
    b.style.setProperty("--b", size + "px");
    b.style.setProperty("--d", (i * 0.7).toFixed(1) + "s");
    b.setAttribute("aria-label", c.title);
    b.innerHTML = `<span class="bubble-inner"><span class="bubble-emoji"></span></span><span class="bubble-title"></span>`;
    if (c.avatar) b.querySelector(".bubble-emoji").replaceWith(avatarImg(c.svg));
    else b.querySelector(".bubble-emoji").textContent = c.emoji;
    if (c.avatar) b.setAttribute("aria-label", "Figur " + c.name + (c.active ? ", dein Bild beim Namen" : ""));
    if (c.avatar && c.active) {
      const badge = document.createElement("span");
      badge.className = "bubble-mode bubble-star";
      badge.textContent = "⭐";
      b.append(badge);
    }
    const bm = c.id && !c.avatar && !c.old && (kid?.modes || []).length > 1 ? modeOf(c.mode) : null;
    if (bm) {
      const badge = document.createElement("span");
      badge.className = "bubble-mode";
      badge.style.setProperty("--m", bm.color);
      badge.textContent = bm.emoji;
      b.append(badge);
    }
    b.querySelector(".bubble-title").textContent = c.avatar ? c.name : c.title;
    if (c.old && c.id !== convoId) b.classList.add("old");
    if (compact) b.classList.add("notitle");
    if (!c.id) b.onclick = newTopic;
    else if (c.avatar) pressable(b, () => tapAvatar(c), () => holdAvatar(c, b));
    else pressable(b, () => resumeBubble(c), () => popBubble(c, b));
    let f = flight.get(key);
    if (!f) {
      // Startpunkt: oben, zufällig verteilt; ältere am Rand. Richtung zufällig, langsam (gut antippbar)
      const a = Math.random() * Math.PI * 2, v = (c.old ? 6 : 10) + Math.random() * (c.old ? 6 : 12);
      const p = fl.spots.length ? fl.spots[Math.floor(Math.random() * fl.spots.length)] : { x: 0, y: 0 };
      f = { x: p.x, y: p.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v };
      flight.set(key, f);
    }
    if (f.bud) { delete f.bud; if (!REDUCED_MOTION) b.classList.add("budding"); }
    f.size = size; f.el = b;
    f.th = titleH(c, compact); f.old = !!c.old; f.side = i % 2 ? 1 : -1;
    for (let k = 0; k < 3; k++) { keepInside(f, fl); fl.walls.forEach((w) => keepOut(f, w, fl)); }
    keepInside(f, fl);
    unstick(f, fl);
    b.style.transform = `translate(${f.x}px, ${f.y}px)`;
    box.append(b);
  });
  for (const k of [...flight.keys()]) if (!keep.has(k)) flight.delete(k);
  startFlight();
}
function startFlight() {
  if (flightRaf) return;
  flightLast = performance.now();
  let fl = null, flAt = 0;
  const step = (now) => {
    const box = $("#bubbles");
    if ($("#screen-talk").hidden || !box.childElementCount) { flightRaf = 0; return; }
    const dt = Math.min(0.05, (now - flightLast) / 1000);
    flightLast = now;
    // Knöpfe und Text bewegen sich selten (Untertitel, Scrollen): Hindernisse 5-mal pro Sekunde neu messen
    if (!fl || now - flAt > 200) { fl = bubbleField(); flAt = now; }
    const list = [...flight.values()].filter((f) => f.el?.isConnected);
    for (const f of list) {
      // Gedrückte oder platzende Blase bleibt stehen, damit Antippen und Halten sicher klappen
      f.pin = f.el.classList.contains("pressing") || f.el.classList.contains("popping") || f.el.matches(":active");
      if (f.pin) continue;
      if (f.stuck && fl.spots.length) {
        // eingeklemmt: geradewegs zum nächsten freien Platz
        const t = fl.spots.reduce((best, p) => (Math.hypot(p.x - f.x, p.y - f.y) < Math.hypot(best.x - f.x, best.y - f.y) ? p : best));
        const tx = t.x, ty = t.y, d = Math.hypot(tx - f.x, ty - f.y) || 1;
        f.x += (tx - f.x) / d * Math.min(d, 60 * dt); f.y += (ty - f.y) / d * Math.min(d, 60 * dt);
        continue;
      }
      // Auftrieb nach oben; ältere Blasen treiben zusätzlich zu ihrem Rand
      f.vy -= BUOYANCY * dt;
      if (f.old) {
        const want = f.side > 0 ? fl.W - f.size : 0;
        f.vx += Math.sign(want - f.x) * Math.min(6, Math.abs(want - f.x) / 10) * dt;
      }
      // Tempo bleibt ruhig: nicht zu schnell (gut antippbar), nie ganz still
      const sp = Math.hypot(f.vx, f.vy), lo = f.old ? 5 : 8, hi = f.old ? 14 : 24;
      if (sp > hi) { f.vx *= hi / sp; f.vy *= hi / sp; } else if (sp < lo) { const a = Math.random() * Math.PI * 2; f.vx += Math.cos(a) * 2; f.vy += Math.sin(a) * 2; }
      f.x += f.vx * dt * FLIGHT_SPEED; f.y += f.vy * dt * FLIGHT_SPEED;
      keepInside(f, fl);
    }
    for (const f of list) if (f.px === undefined) { f.px = f.x; f.py = f.y; }
    // Blasen stoßen sich sanft ab, statt sich zu überdecken. Danach hart: aus Knöpfen, Anzeige und der Sperrzone heraus
    // (auch eine gedrückte Blase nie dort). Dreimal pro Bild, damit es auch im Gedränge (Handy) aufgeht.
    for (let it = 0; it < 3; it++) {
      for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
        const a = list[i], b = list[j];
        if (a.stuck || b.stuck) continue;
        // Kreis um Blase und Titel, damit kein Titel unter einer Nachbarblase verschwindet
        const dx = (b.x + b.size / 2) - (a.x + a.size / 2), dy = (b.y + (b.size + b.th) / 2) - (a.y + (a.size + a.th) / 2);
        const min = (a.size + a.th * 0.7 + b.size + b.th * 0.7) / 2 + 4, d = Math.hypot(dx, dy) || 0.01;
        if (d < min) {
          // eine gedrückte Blase bleibt unter dem Finger, die andere weicht ganz aus
          const nx = dx / d, ny = dy / d, ka = a.pin ? 0 : b.pin ? 1 : 0.5, push = min - d;
          a.x -= nx * push * ka; a.y -= ny * push * ka; b.x += nx * push * (1 - ka); b.y += ny * push * (1 - ka);
          const rel = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
          if (it === 0 && rel < 0) { a.vx += rel * nx; a.vy += rel * ny; b.vx -= rel * nx; b.vy -= rel * ny; }
        }
      }
      for (const f of list) if (!f.stuck && !f.pin) { fl.walls.forEach((w) => keepOut(f, w, fl)); keepInside(f, fl); }
    }
    for (const f of list) { unstick(f, fl); f.px = f.x; f.py = f.y; }
    for (const f of list) f.el.style.transform = `translate(${f.x.toFixed(1)}px, ${f.y.toFixed(1)}px)`;
    flightRaf = requestAnimationFrame(step);
  };
  flightRaf = requestAnimationFrame(step);
}
function stopFlight() { if (flightRaf) cancelAnimationFrame(flightRaf); flightRaf = 0; }
addEventListener("resize", () => { if (!$("#screen-talk").hidden) renderBubbles(); });
// Sprechtaste steht fest unten (.talk-dock). Reicht der Platz darüber nicht (Handy, Querformat), scrollt der obere
// Bereich. Dann immer das Neueste zeigen: Anzeige, Untertitel und Gehörtes stehen unten und bleiben so sichtbar.
{
  const stage = $(".talk-stage");
  let raf = 0;
  const toEnd = () => {
    raf = 0;
    // Untertitel geht vor, sonst das unterste Text-Element mit Inhalt; passt es ohne Scrollen, bleibt der Bereich oben (Modi sichtbar)
    const vis = (q) => { const el = $(q); return !el.hidden && el.textContent.trim() ? el : null; };
    const last = vis("#caption") || ["#heard", "#extend-open", "#status"].map(vis).find(Boolean);
    if (!last) return;
    const want = last.getBoundingClientRect().bottom - stage.getBoundingClientRect().top + stage.scrollTop + 8 - stage.clientHeight;
    stage.scrollTop = Math.max(0, want);
  };
  new MutationObserver((list) => {
    if (raf || $("#screen-talk").hidden || list.every((m) => m.target.closest?.("#bubbles") || m.target.parentElement?.closest("#bubbles"))) return;
    raf = requestAnimationFrame(toEnd);
  }).observe(stage, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["hidden"] });
}
// Kurz tippen = weiterreden, lange halten (0,8 s) = zerplatzen. Die Blase wackelt beim Halten, damit das Kind sieht, was passiert.
// Kinderfinger wackeln: Bis HOLD_SLOP Pixel Bewegung zählt noch als Halten. Ohne touch-action: none und
// Pointer-Capture machte der Browser aus dem Wackeln ein Wischen (pointercancel) und das Halten brach still ab.
const HOLD_SLOP = 28;
let heldAt = 0; // Loslassen nach einem Halten: der Klick, den Touch-Geräte danach schicken, darf im Dialog nichts auslösen
function pressable(el, onTap, onHold) {
  let t = null, held = false, x0 = 0, y0 = 0;
  const cancel = () => { clearTimeout(t); t = null; el.classList.remove("pressing"); };
  el.addEventListener("pointerdown", (e) => {
    held = false;
    x0 = e.clientX; y0 = e.clientY;
    try { el.setPointerCapture(e.pointerId); } catch {}
    el.classList.add("pressing");
    clearTimeout(t);
    t = setTimeout(() => { t = null; held = true; heldAt = Date.now(); el.classList.remove("pressing"); onHold(); }, 800);
  });
  el.addEventListener("pointermove", (e) => { if (t && Math.hypot(e.clientX - x0, e.clientY - y0) > HOLD_SLOP) cancel(); });
  ["pointerup", "pointercancel"].forEach((ev) => el.addEventListener(ev, () => { if (held) heldAt = Date.now(); cancel(); }));
  el.addEventListener("contextmenu", (e) => e.preventDefault());
  el.addEventListener("click", (e) => { if (held) { e.preventDefault(); held = false; return; } onTap(); });
}
let audioCtx = null;
function popSound() {
  try {
    audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const now = audioCtx.currentTime, o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(900, now);
    o.frequency.exponentialRampToValueAtTime(180, now + 0.12);
    g.gain.setValueAtTime(0.5, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    o.connect(g).connect(audioCtx.destination);
    o.start(now);
    o.stop(now + 0.16);
  } catch {}
}
async function popBubble(c, el) {
  navigator.vibrate?.(40);
  popSound();
  el.classList.add("popping");
  for (let i = 0; i < 8; i++) {
    const d = document.createElement("span");
    d.className = "droplet";
    d.style.setProperty("--a", i * 45 + "deg");
    el.append(d);
  }
  if (convoId === c.id) convoId = null;
  try { await api("/api/bubbles/pop", { method: "POST", body: { kidId: kid.id, convoId: c.id } }); } catch {}
  setTimeout(() => {
    bubbles = bubbles.filter((x) => x.id !== c.id);
    renderBubbles();
  }, 450);
  stopSpeaking();
  speak("Plopp! Die Blase ist zerplatzt.", idleIfDone, { fixed: true });
}
// Avatar fertig: Gesprächsblase platzt wie beim Festhalten, nur ohne Ansage (die KI sagt gerade „Tadaa!“)
function avatarDonePop(id) {
  if (convoId === id) convoId = null;
  const el = $(`#bubbles .bubble[data-convo="${id}"]`);
  if (el) {
    popSound();
    el.classList.add("popping");
    for (let i = 0; i < 8; i++) { const d = document.createElement("span"); d.className = "droplet"; d.style.setProperty("--a", i * 45 + "deg"); el.append(d); }
  }
  setTimeout(() => { bubbles = bubbles.filter((x) => x.id !== id); renderBubbles(); }, 450);
}
// ------------------------------------------------------------------ Figuren (intern Avatare, Knopf „Meine Figur“)
// Antippen: sagt, ob der Avatar das Profilbild ist, sonst Frage, ob er es werden soll. Lang halten: löschen mit Rückfrage.
// Das SVG kommt bereinigt vom Server und wird nur als <img> gezeigt (darin läuft nie ein Script).
const avatarSrc = (svg) => "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
function avatarImg(svg, cls = "bubble-avatar") {
  const img = document.createElement("img");
  img.src = avatarSrc(svg);
  img.alt = "";
  img.draggable = false;
  if (cls) img.className = cls;
  return img;
}
function setProfileAvatar(list) {
  avatars = list;
  if (kid) kid.avatar = list.find((a) => a.active)?.svg || null;
  renderTalkAvatar();
  renderBubbles();
}
function renderTalkAvatar() {
  const el = $("#talk-avatar");
  el.hidden = !kid?.avatar;
  if (kid?.avatar) el.src = avatarSrc(kid.avatar);
}
function avatarSay(t) {
  speak(t, idleIfDone, { fixed: true });
  setStatus("…", "speaking");
}
// Antippen: erst (falls nötig) Profilbild-Frage, dann „Möchtest du was ändern?“.
// Ja: Gespräch zum Umgestalten (Zusammenfassung, Änderungen besprechen, neu zeichnen). Nein: kurze Fantasiegeschichte.
async function tapAvatar(a) {
  abortCtl?.abort();
  stopSpeaking();
  unlockAudio();
  let intro = `Das ist ${a.name}, dein Profilbild. `;
  if (!a.active) {
    const yes = await askChoice({ title: `${a.name} als Profilbild?`, hint: "Ja: dann siehst du dieses Bild bei deinem Namen.",
      say: `Das ist ${a.name}. Soll ${a.name} dein Profilbild werden? Dann siehst du ${a.name} bei deinem Namen. Tipp auf Ja oder auf Nein.`,
      options: [{ value: true, kind: "renew", svg: `<img src="${avatarSrc(a.svg)}" alt="">`, label: "Ja" }, { value: false, kind: "keep", svg: ICON_NO, label: "Nein" }] });
    if (yes === null) return avatarSay("Okay.");
    intro = "Okay. ";
    if (yes) {
      try { setProfileAvatar(await api("/api/avatars/activate", { method: "POST", body: { kidId: kid.id, avatarId: a.id } })); intro = `Super! ${a.name} ist jetzt dein Profilbild. `; }
      catch { return avatarSay("Hoppla, das hat nicht geklappt. Versuch es gleich nochmal."); }
    }
  }
  const change = await askChoice({ title: `${a.name} ändern?`, hint: "Ja: wir besprechen zusammen, was anders werden soll. Nein: du hörst eine kleine Geschichte.",
    say: intro + `Möchtest du an ${a.name} was ändern? Tipp auf Ja oder auf Nein.`,
    options: [{ value: true, kind: "renew", svg: ICON_PEN, label: "Ja" }, { value: false, kind: "keep", svg: `<img src="${avatarSrc(a.svg)}" alt="">`, label: "Nein" }] });
  if (change === null) return avatarSay("Okay.");
  const m = (kid.modes || []).find((x) => x.avatars);
  if (!m) return avatarSay(`${a.name} bleibt, wie er ist.`);
  convoId = null; // eigenes, neues Gespräch
  setMode(m.id);
  renderBubbles();
  ask(change ? `Ich möchte ${a.name} ändern.` : `Erzähl mir eine Geschichte von ${a.name}.`, change ? { avatarEdit: a.id } : { avatarStory: a.id });
}
async function holdAvatar(a, el) {
  abortCtl?.abort();
  stopSpeaking();
  navigator.vibrate?.(40);
  const del = await askChoice({ title: `${a.name} löschen?`, hint: "Der Mülleimer löscht, der andere Knopf behält die Figur.",
    say: `Willst du ${a.name} wirklich löschen? Dann fliegt ${a.name} nicht mehr bei dir herum. Der Mülleimer löscht, der andere Knopf behält ${a.name}.`,
    options: [{ value: true, kind: "trash", svg: ICON_TRASH, label: "Löschen" }, { value: false, kind: "keep", svg: `<img src="${avatarSrc(a.svg)}" alt="">`, label: "Behalten" }] });
  if (!del) return avatarSay(`Okay, ${a.name} bleibt bei dir.`);
  popSound();
  el.classList.add("popping");
  try {
    const list = await api("/api/avatars/delete", { method: "POST", body: { kidId: kid.id, avatarId: a.id } });
    setTimeout(() => setProfileAvatar(list), 450);
    avatarSay(`Plopp! ${a.name} ist weg.` + (list.length < 3 ? " Jetzt ist Platz für eine neue Figur. Die erfinden wir mit dem Knopf Meine Figur." : ""));
  } catch { el.classList.remove("popping"); avatarSay("Hoppla, das hat nicht geklappt. Versuch es gleich nochmal."); }
}

function newTopic() {
  abortCtl?.abort();
  stopSpeaking();
  convoId = null;
  renderBubbles();
  setStatus("…", "speaking");
  speak("Okay, ein neues Thema! Was möchtest du wissen?", idleIfDone, { fixed: true });
}
async function resumeBubble(c) {
  abortCtl?.abort();
  stopSpeaking();
  convoId = c.id;
  renderBubbles();
  setStatus("…", "speaking");
  try {
    const r = await api("/api/bubbles/resume", { method: "POST", body: { kidId: kid.id, convoId: c.id } });
    setMode(r.mode);
    speak(r.say);
    if (r.notice) speak(r.notice, null, { fixed: true });
    speak(r.then, idleIfDone, { fixed: true });
  } catch {
    speak(`Weißt du noch? Wir haben über ${c.title} gesprochen. Was möchtest du noch wissen?`, idleIfDone);
  }
}
function idleIfDone() {
  if (!busy && !holding && speakQueue === 0) setStatus(canListen() ? "Drück und halte mich!" : "Tippe deine Frage unten ein.", "idle");
}
function playIntro(full) {
  if (!kid) return;
  stopSpeaking();
  setStatus("…", "speaking");
  speak(introText(kid, full), idleIfDone, { fixed: true });
}
$("#talk-help").onclick = () => playIntro(true);

// ------------------------------------------------------------------ Farbschloss
// Kinderschloss für Geschwister: 3 von 6 Farben in Reihenfolge. Farben haben zusätzlich ein Zeichen,
// damit es auch bei Farbsehschwäche klappt.
const LOCK_COLORS = [["#e53935", "♥", "Rot"], ["#f9c80e", "★", "Gelb"], ["#43a047", "▲", "Grün"], ["#1e88e5", "●", "Blau"], ["#8e24aa", "◆", "Lila"], ["#fb8c00", "■", "Orange"]];
function askCombo({ title, hint = "", say, error = "" }) {
  const d = $("#lock-dialog"), pad = $("#lock-pad"), dots = [...document.querySelectorAll(".lock-dots span")], undo = $("#lock-undo");
  $("#lock-title").textContent = title;
  $("#lock-hint").textContent = hint;
  $("#lock-error").textContent = error;
  const card = d.querySelector(".lock-card");
  card.classList.remove("shake");
  if (error) { void card.offsetWidth; card.classList.add("shake"); }
  const combo = [];
  const show = () => { dots.forEach((x, i) => (x.style.background = combo[i] == null ? "" : LOCK_COLORS[combo[i]][0])); undo.hidden = !combo.length; };
  show();
  pad.innerHTML = "";
  return new Promise((resolve) => {
    let closed = false;
    const done = (v) => { if (closed) return; closed = true; d.close(); stopSpeaking(); resolve(v); };
    LOCK_COLORS.forEach(([c, sym, name], i) => {
      const b = document.createElement("button");
      b.style.setProperty("--c", c);
      b.textContent = sym;
      b.setAttribute("aria-label", name);
      b.onclick = () => {
        if (closed || combo.length >= 3) return; // schnelles Weitertippen nach der dritten Farbe ignorieren
        combo.push(i);
        show();
        if (combo.length === 3) setTimeout(() => done(combo), 300);
      };
      pad.append(b);
    });
    undo.onclick = () => {
      if (combo.length >= 3 || !combo.length) return;
      combo.pop(); show();
      if (explainAll()) { stopSpeaking(); speak("Die letzte Farbe ist wieder weg.", null, { fixed: true }); }
    };
    $("#lock-cancel").onclick = () => done(null);
    $("#lock-hear").onclick = () => { stopSpeaking(); unlockAudio(); speak(say || [error, hint].filter(Boolean).join(" "), null, { fixed: true }); };
    d.oncancel = (e) => { e.preventDefault(); done(null); };
    d.showModal();
    // Sofort erklären: eine laufende Begrüßung würde die Ansage sonst hinter sich einreihen
    stopSpeaking();
    if (say) speak(say, null, { fixed: true });
  });
}
const LOCK_WRONG = "Hm, das waren nicht deine Farben. Probier es nochmal. Wenn du sie vergessen hast, frag Mama oder Papa.";
// Aktuelle Farben abfragen und beim Server prüfen. Gibt die Farben zurück, null bei Abbruch oder Pause.
async function confirmCombo(k, first) {
  let error = "";
  for (;;) {
    const combo = await askCombo({ title: first.title, hint: first.hint, say: error ? null : first.say, error });
    if (!combo) return null;
    try { await api("/api/kids/unlock", { method: "POST", body: { kidId: k.id, combo } }); return combo; }
    catch (e) {
      if (e.status === 429) { speak(e.message); return null; }
      error = e.message;
      speak(LOCK_WRONG, null, { fixed: true });
    }
  }
}
function unlockKid(k) {
  return confirmCombo(k, { title: `Hallo ${k.name}!`, hint: "Tipp deine drei Farben.",
    say: `Hallo ${k.name}! Dein Profil ist abgeschlossen. Tipp deine drei Farben in der richtigen Reihenfolge.` }).then(Boolean);
}
// Große Bildknöpfe zum Auswählen, mit Ansage. Gibt den Wert des gewählten Knopfs zurück oder null.
function askChoice({ title, hint = "", say, options }) {
  const d = $("#choice-dialog"), list = $("#choice-list");
  $("#choice-title").textContent = title;
  $("#choice-hint").textContent = hint;
  list.innerHTML = "";
  return new Promise((resolve) => {
    const done = (v) => { d.close(); stopSpeaking(); resolve(v); };
    list.classList.toggle("swatches", options.some((o) => o.color));
    for (const o of options) {
      const b = document.createElement("button");
      b.className = o.color ? "choice-swatch" + (o.current ? " current" : "") : "choice-big" + (o.kind ? " " + o.kind : "");
      if (o.color) b.style.setProperty("--c", o.color);
      b.innerHTML = `<span class="choice-icon">${o.svg || ""}</span><span class="choice-label"></span>`;
      b.lastChild.textContent = o.label;
      b.setAttribute("aria-label", o.label);
      b.onclick = () => { if (Date.now() - heldAt < 350) return; done(o.value); };
      list.append(b);
    }
    $("#choice-cancel").onclick = () => done(null);
    $("#choice-hear").onclick = () => { stopSpeaking(); unlockAudio(); speak(say || hint, null, { fixed: true }); };
    d.oncancel = (e) => { e.preventDefault(); done(null); };
    d.showModal();
    stopSpeaking();
    if (say) speak(say, null, { fixed: true });
  });
}
const ICON_TRASH = '<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M24 10h16l2 5h10a3 3 0 0 1 0 6H12a3 3 0 0 1 0-6h10z" fill="currentColor"/><path d="M15 25h34l-3 28a5 5 0 0 1-5 4.5H23a5 5 0 0 1-5-4.5z" fill="currentColor" opacity=".9"/><path d="M26 32v18M32 32v18M38 32v18" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/></svg>';
const ICON_PEN = '<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M42 10l12 12-28 28-15 3 3-15z" fill="currentColor"/><path d="M38 14l12 12" stroke="#fff" stroke-width="4" stroke-linecap="round"/><path d="M14 40l10 10" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".7"/></svg>';
const ICON_NO = '<svg viewBox="0 0 64 64" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="8" stroke-linecap="round"><path d="M18 18l28 28M46 18L18 46"/></svg>';
const ICON_RENEW = '<svg viewBox="0 0 64 64" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"><path d="M50 26A19 19 0 0 0 16 20"/><path d="M14 38a19 19 0 0 0 34 6"/><path d="M15 9v12h12" /><path d="M49 55V43H37"/></svg>';
// Neue Farben zweimal abfragen. Bei Abweichung freundlich von vorn, ohne den Ablauf abzubrechen.
async function askNewCombo(k, intro) {
  let first = intro;
  for (;;) {
    const c1 = await askCombo(first);
    if (!c1) return null;
    const c2 = await askCombo({ title: "Nochmal bitte", hint: "Tipp dieselben drei Farben noch einmal, in derselben Reihenfolge.",
      say: "Prima! Und jetzt zur Sicherheit nochmal dieselben drei Farben, in derselben Reihenfolge." });
    if (!c2) return null;
    if (c2.join() === c1.join()) return c1;
    first = { title: "Nochmal von vorn", hint: "Tipp drei Farben und merk dir die Reihenfolge.", error: "Das waren andere Farben.",
      say: "Hoppla, das waren andere Farben. Kein Problem, wir fangen nochmal von vorn an. Tipp drei Farben und merk dir die Reihenfolge gut." };
  }
}
// Farbschloss oben im Sprechbildschirm.
// Kein Schloss: neue Farben festlegen. Schloss da: erst die jetzigen Farben, dann Mülleimer (weg) oder Pfeile (neu).
async function setupLock() {
  if (!kid) return;
  unlockAudio();
  const k = kid;
  const after = (t) => {
    speak(t, null, { fixed: true });
    setStatus(t, "idle");
    setTimeout(() => { if (kid === k) idleIfDone(); }, 4000);
  };
  const keep = () => after(k.locked ? "Okay, dein Schloss bleibt, wie es war." : "Okay, dann bleibt dein Profil offen.");
  let oldCombo = null;
  if (k.locked) {
    oldCombo = await confirmCombo(k, { title: "Deine Farben", hint: "Zeig mir zuerst deine jetzigen drei Farben.",
      say: `Das ist dein Farbschloss, ${k.name}. Zeig mir zuerst deine jetzigen drei Farben, damit ich weiß, dass du es bist.` });
    if (!oldCombo) return keep();
    const want = await askChoice({ title: "Was möchtest du machen?", hint: "Mülleimer: Schloss weg. Pfeile: neue Farben.",
      say: "Richtig! Jetzt siehst du zwei Knöpfe. Der Mülleimer macht dein Schloss weg, dann kann jeder dein Profil öffnen. " +
        "Die Pfeile im Kreis geben dir neue Farben. Tipp auf einen Knopf.",
      options: [{ value: "remove", kind: "trash", svg: ICON_TRASH, label: "Schloss weg" }, { value: "change", kind: "renew", svg: ICON_RENEW, label: "Neue Farben" }] });
    if (!want) return keep();
    if (want === "remove") return saveLock(k, oldCombo, null, after);
  }
  const combo = await askNewCombo(k, k.locked
    ? { title: "Neue Farben", hint: "Tipp drei neue Farben und merk dir die Reihenfolge.",
        say: "Super. Jetzt tipp drei neue Farben und merk dir die Reihenfolge gut." }
    : { title: "Dein Farbschloss",
        hint: "Damit kommt nur noch in dein Profil, wer deine drei Farben kennt. Tipp drei Farben nacheinander und merk dir die Reihenfolge.",
        say: `Das ist dein Farbschloss, ${k.name}. Damit kannst du dein Profil abschließen. Dann kommt nur noch rein, wer deine drei Farben kennt. ` +
          "Tipp jetzt drei Farben nacheinander an. Die gleiche Farbe darf auch zweimal vorkommen. Merk dir die Reihenfolge gut! " +
          "Wenn du dich vertippst, macht der Pfeil unten die letzte Farbe wieder weg." });
  if (!combo) return keep();
  return saveLock(k, oldCombo, combo, after);
}
async function saveLock(k, oldCombo, combo, after) {
  try {
    const r = await api("/api/kids/lock", { method: "POST", body: { kidId: k.id, oldCombo, combo } });
    k.locked = r.locked;
    if (kid === k) $("#talk-lock").textContent = k.locked ? "🔒" : "🔓";
    after(combo === null
      ? "Erledigt, dein Schloss ist weg und deine Farben sind gelöscht. Jetzt kann jeder dein Profil öffnen. Wenn du wieder ein Schloss möchtest, tipp einfach oben auf das offene Schloss."
      : oldCombo
        ? "Super, geschafft! Ab jetzt gelten deine neuen Farben. Die alten gehen nicht mehr."
        : "Super, geschafft! Dein Profil ist jetzt abgeschlossen. Wenn du das nächste Mal auf deinen Namen tippst, tippst du einfach deine drei Farben. Das Schloss oben zeigt dir, dass es zu ist.");
  } catch (e) { after(e.message); }
}
$("#talk-lock").onclick = setupLock;

// ------------------------------------------------------------------ Eigene Farbe
// Das Kind sucht sich seine Farbe selbst aus, aus allen gängigen Farben (auch Orange: das Orange-Verbot gilt nur fürs App-Design).
// Helle Farben (Gelb, Orange, Gold, Rosa, Silber, Weiß) bekommen automatisch dunkle Schrift, siehe kidLight().
const KID_PALETTE = [["#e5484d", "Rot"], ["#ff8a1f", "Orange"], ["#ffd60a", "Gelb"], ["#d4a017", "Gold"],
  ["#5fb300", "Hellgrün"], ["#2bb673", "Grün"], ["#1b7f4b", "Dunkelgrün"], ["#00a6b8", "Türkis"],
  ["#1e9be0", "Hellblau"], ["#3d7aff", "Blau"], ["#3f51b5", "Dunkelblau"], ["#b44dff", "Lila"],
  ["#e040c8", "Magenta"], ["#ff4d8d", "Pink"], ["#ffb3d1", "Rosa"], ["#8d6e63", "Braun"],
  ["#b8c0c8", "Silber"], ["#5b6b8c", "Grau"], ["#222428", "Schwarz"], ["#ffffff", "Weiß"]];
const colorSay = (k) => explainAll(k)
  ? `Hier suchst du dir deine Farbe aus, ${k.name}. Es gibt ganz viele: Rot, Orange, Gelb, Gold, drei Grüntöne, Türkis, drei Blautöne, Lila, Magenta, Pink, Rosa, Braun, Silber, Grau, Schwarz und Weiß. ` +
    "Tipp auf die Farbe, die du am schönsten findest. Dann ist hier alles in deiner Farbe. Der Pfeil oben bringt dich zurück, ohne etwas zu ändern."
  : "Such dir deine Farbe aus.";
async function chooseColor() {
  if (!kid) return;
  unlockAudio();
  const k = kid, cur = (k.color || "").toLowerCase();
  const c = await askChoice({ title: "Deine Farbe", hint: "Tipp auf die Farbe, die du am schönsten findest.",
    say: colorSay(k),
    options: KID_PALETTE.map(([color, name]) => ({ value: color, color, label: name, current: color === cur })) });
  if (!c || kid !== k) return;
  try {
    const r = await api("/api/kids/color", { method: "POST", body: { kidId: k.id, color: c } });
    k.color = r.color;
    paintKid($("#screen-talk"), k.color);
    setThemeColor(k.color);
    const name = KID_PALETTE.find(([x]) => x === c)?.[1] || "neu";
    speak(`Toll! Ab jetzt ist alles ${name}.`, idleIfDone, { fixed: true });
  } catch (e) { speak(e.message); }
}
$("#talk-color").onclick = chooseColor;
// Limit erreicht: Eltern verlängern direkt hier mit ihrem Passwort (Server sperrt nach Fehlversuchen)
$("#extend-open").onclick = () => {
  $("#extend-pw").value = "";
  $("#extend-error").textContent = "";
  $("#extend-for").textContent = kid ? "Für " + kid.name + ". Gilt nur heute." : "";
  $("#extend-dialog").showModal();
};
$("#extend-form").addEventListener("submit", async (e) => {
  const v = e.submitter?.value;
  if (!v || v === "cancel") return;
  e.preventDefault();
  if (!kid) return $("#extend-dialog").close();
  try {
    const r = await api("/api/extend", { method: "POST", body: { kidId: kid.id, password: $("#extend-pw").value, minutes: v === "today" ? "today" : Number(v) } });
    $("#extend-pw").value = "";
    $("#extend-dialog").close();
    $("#extend-open").hidden = true;
    setStatus("…", "speaking");
    speak(r.say, () => setStatus("Drück und halte mich!", "idle"));
  } catch (err) { $("#extend-error").textContent = err.message; $("#extend-pw").value = ""; }
});
$("#talk-back").onclick = () => {
  abortCtl?.abort();
  const young = explainAll(); // kleine Kinder hören auf der Namensseite wieder, was zu tun ist
  if (kid?.locked) api("/api/kids/relock", { method: "POST", body: { kidId: kid.id } }).catch(() => {});
  kid = null;
  convoId = null;
  goHome({ greet: young });
};

// Sprechtaste: Timing-Regeln, damit auch ein einzelnes „Ja“ und das letzte Wort ankommen.
// Die Spracherkennung braucht nach dem Drücken einen Moment, bis das Mikrofon wirklich läuft,
// und nach dem Loslassen einen Moment, bis die letzten Silben verarbeitet sind.
const PTT_TAIL_MS = 700;        // nach dem Loslassen noch so lange weiter zuhören
const PTT_MIN_AUDIO_MS = 700;   // so lange muss das Mikrofon mindestens wirklich gelaufen sein
const PTT_WAIT_START_MS = 2000; // so lange warten wir nach dem Loslassen höchstens auf den Mikrofon-Start
const PTT_FINAL_WAIT_MS = 2500; // spätestens dann zählt, was bis dahin erkannt wurde
const NOTHING_HEARD = "Ich hab nichts gehört. Halt mich fest, während du sprichst!";
// Android-Tablets liefern bei der Browser-Erkennung oft jedes Ergebnis kumulativ („ich“, „ich mag“,
// „ich mag Dinos“) oder mehrfach. Einfach aneinandergehängt ergibt das 30 Zeilen Text. Darum werden
// Teilstücke zusammengeführt statt angehängt, und Wiederholungen fallen weg.
const normWords = (t) => String(t || "").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter(Boolean);
function mergeSpeech(a, b) {
  a = String(a || "").trim(); b = String(b || "").trim();
  if (!a) return b;
  if (!b) return a;
  const A = normWords(a), B = normWords(b);
  // Y steckt schon in X: als Anfang, als Ende oder (ab 3 Wörtern) irgendwo mittendrin
  const has = (X, Y) => {
    const x = " " + X.join(" ") + " ", y = " " + Y.join(" ") + " ";
    return !!Y.length && (x.startsWith(y) || x.endsWith(y) || (Y.length >= 3 && x.includes(y)));
  };
  if (has(A, B)) return a;          // nichts Neues
  if (has(B, A)) return b;          // b ist die längere Fassung desselben Satzes
  // Überlappung: Ende von a = Anfang von b („ich mag Di“ + „mag Dinos“)
  const words = b.split(/\s+/);
  for (let n = Math.min(A.length, B.length); n > 0; n--) {
    if (A.slice(-n).join(" ") === B.slice(0, n).join(" ")) return (a + " " + words.slice(n).join(" ")).trim();
  }
  return a + " " + b;
}
// Wiederholte Wortgruppen direkt hintereinander auf eine reduzieren („ich mag Dinos ich mag Dinos“).
// Ein doppeltes einzelnes Wort („ja ja“) bleibt, ab dem dritten Mal wird gekürzt.
function cleanSpeech(text) {
  let w = String(text || "").replace(/\s+/g, " ").trim().split(" ").filter(Boolean);
  const key = (x) => normWords(x).join(" ");
  for (let n = Math.floor(w.length / 2); n >= 1; n--) {
    for (let i = 0; i + 2 * n <= w.length; ) {
      const g1 = key(w.slice(i, i + n).join(" ")), g2 = key(w.slice(i + n, i + 2 * n).join(" "));
      const same = g1 && g1 === g2 && (n > 1 || key(w[i + 2 * n] || "") === g1);
      if (same) w.splice(i + n, n); else i++;
    }
  }
  return w.join(" ").slice(0, 600);
}

// Anzeige „Gehörtes“: max. 3 Zeilen (CSS). Ist mehr da, oben sanft ausblenden, damit man sieht, dass es weitergeht.
{
  const h = typeof document !== "undefined" && document.getElementById("heard");
  // scrollHeight hilft hier nicht (Text ist unten angeschlagen und läuft nach oben über), darum die Texthöhe messen
  const fit = () => { const r = document.createRange(); r.selectNodeContents(h); h.classList.toggle("long", r.getBoundingClientRect().height > h.clientHeight + 2); };
  if (h) new MutationObserver(fit).observe(h, { childList: true, characterData: true, subtree: true });
}
let listen = null; // laufende Aufnahme (Browser-Erkennung oder Server-Aufnahme)

let micStream = null, recorder = null, chunks = [];
async function getMic() {
  if (micStream?.getAudioTracks().some((t) => t.readyState === "live")) return micStream;
  micStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  return micStream;
}
// Mikrofon vorwärmen (nur Server-Erkennung und nur, wenn es schon erlaubt ist): sonst geht beim
// ersten Drücken der Anfang verloren, weil das Mikrofon erst eingeschaltet wird.
async function prewarmMic() {
  if (!serverStt()) return;
  try {
    const p = await navigator.permissions?.query({ name: "microphone" });
    if (p?.state === "granted") await getMic();
  } catch {}
}
async function startRecording(l) {
  try { await getMic(); } catch {
    holding = false;
    listen = null;
    return setStatus("Ich darf das Mikrofon nicht benutzen. Eltern fragen!", "error");
  }
  if (l !== listen || l.finished) return;
  chunks = [];
  const r = new MediaRecorder(micStream);
  recorder = r;
  r.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  r.onstop = async () => {
    const blob = new Blob(chunks, { type: r.mimeType || "audio/webm" });
    if (recorder === r) recorder = null;
    const ms = Date.now() - (l.audioAt || Date.now());
    l.finished = true;
    if (listen === l) listen = null;
    // Nur echte Fehlgriffe verwerfen (kaum Ton). Ein kurzes „Ja“ ist gültig.
    if (ms < 250 || blob.size < 300) return setStatus(NOTHING_HEARD, "idle");
    setStatus("Ich höre genau hin …", "thinking");
    try {
      const res = await fetch("/api/stt", { method: "POST", credentials: "same-origin", headers: H({ "Content-Type": blob.type }), body: blob });
      const j = await res.json();
      if (!res.ok || !j.text) throw new Error(j.error || "leer");
      heard = cleanSpeech(j.text);
      $("#heard").textContent = heard;
      ask(heard);
    } catch {
      setStatus("Ich hab dich nicht verstanden. Versuch es nochmal!", "idle");
    }
  };
  r.onstart = () => { l.audioAt = Date.now(); if (holding) setStatus("Ich höre zu …", "listening"); };
  r.start();
}
function stopRecording(l) {
  if (recorder?.state === "recording") return recorder.stop();
  // Mikrofon lief noch gar nicht: nichts zu holen
  l.finished = true;
  if (listen === l) listen = null;
  setStatus(NOTHING_HEARD, "idle");
}

// Wann darf nach dem Loslassen gestoppt werden? Erst nach dem Nachlauf, und erst wenn das Mikrofon
// lange genug lief (sonst wird ein kurzes Wort mitten im Anlaufen abgeschnitten).
function stopDelay(l) {
  const now = Date.now();
  if (!l.server && !l.rec) return 0; // Erkennung läuft nicht (mehr)
  if (!l.audioAt) return now - l.pressAt > PTT_WAIT_START_MS + PTT_TAIL_MS ? 0 : 100; // Mikrofon startet noch
  return Math.max(PTT_TAIL_MS - (now - l.releasedAt), PTT_MIN_AUDIO_MS - (now - l.audioAt), 0);
}
function scheduleStop(l) {
  clearTimeout(l.tailTimer);
  const wait = stopDelay(l);
  if (wait > 0) { l.tailTimer = setTimeout(() => scheduleStop(l), wait); return; }
  l.tailTimer = null;
  if (l.server) return stopRecording(l);
  l.stopping = true;
  try { l.rec?.stop(); } catch {}
  if (!l.rec) return l.conclude();
  // Manche Browser melden das Ende nie: dann zählt, was bis hierher erkannt wurde
  l.guard = setTimeout(() => { try { l.rec?.abort(); } catch {} l.conclude(); }, PTT_FINAL_WAIT_MS);
}

function startBrowserRecognition(l) {
  const r = new SR();
  r.lang = "de-DE";
  r.continuous = true;
  r.interimResults = true;
  const startedAt = Date.now();
  r.onaudiostart = () => { if (!l.audioAt) l.audioAt = Date.now(); if (holding && listen === l) setStatus("Ich höre zu …", "listening"); };
  r.onresult = (e) => {
    // Immer alle Ergebnisse dieser Runde neu zusammensetzen (robuster als nur ab resultIndex)
    let text = "";
    for (let i = 0; i < e.results.length; i++) text = mergeSpeech(text, e.results[i][0].transcript);
    l.current = text;
    heard = cleanSpeech(mergeSpeech(l.done, l.current));
    $("#heard").textContent = heard;
  };
  r.onerror = (e) => {
    if (e.error === "not-allowed" || e.error === "service-not-allowed" || e.error === "audio-capture") l.fatal = "mic";
    else if (e.error === "network") l.fatal = "network";
  };
  r.onend = () => {
    if (l.rec !== r) return;
    l.rec = null;
    l.done = mergeSpeech(l.done, l.current); // Gehörtes dieser Runde behalten (ohne Doppelungen)
    l.current = "";
    // Erkennung hat von selbst aufgehört (z. B. kurze Pause), Taste ist aber noch gedrückt: weiter zuhören
    const quick = Date.now() - startedAt < 400;
    l.quickEnds = quick ? (l.quickEnds || 0) + 1 : 0;
    if (!l.fatal && !l.stopping && l.quickEnds < 3 && (holding || l.tailTimer)) {
      try { startBrowserRecognition(l); return; } catch {}
    }
    if (holding) return; // Auswertung folgt beim Loslassen
    l.conclude();
  };
  r.start();
  l.rec = r;
}

function startListening() {
  if (!canListen() || holding) return;
  holding = true;
  // Wieder gedrückt, während der Nachlauf noch läuft: dieselbe Aufnahme einfach fortsetzen
  if (listen && !listen.finished && !listen.stopping && (listen.tailTimer || listen.rec || recorder)) {
    clearTimeout(listen.tailTimer);
    listen.tailTimer = null;
    setStatus("Ich höre zu …", listen.audioAt ? "listening" : "warming");
    return;
  }
  abortCtl?.abort();
  stopSpeaking();
  unlockAudio();
  heard = "";
  $("#heard").textContent = "";
  const l = { pressAt: Date.now(), audioAt: 0, releasedAt: 0, done: "", current: "", server: serverStt() };
  listen = l;
  // Erst wenn das Mikrofon wirklich läuft, zeigt die Taste „Ich höre zu“ (Ring). Vorher: gedrückt, ohne Ring.
  setStatus("Moment …", "warming");
  if (l.server) { startRecording(l); return; }
  l.conclude = () => {
    if (l.finished) return;
    l.finished = true;
    clearTimeout(l.guard);
    clearTimeout(l.tailTimer);
    if (listen === l) listen = null;
    if (l.fatal === "mic") return setStatus("Ich darf das Mikrofon nicht benutzen. Eltern fragen!", "error");
    const text = cleanSpeech(mergeSpeech(l.done, l.current)) || heard;
    if (text) { heard = text; $("#heard").textContent = text; return ask(text); }
    if (l.fatal === "network") return setStatus("Ich hab dich nicht verstanden. Versuch es nochmal!", "idle");
    setStatus(NOTHING_HEARD, "idle");
  };
  try { startBrowserRecognition(l); } catch { l.rec = null; }
}
function stopListening() {
  if (!holding) return;
  holding = false;
  const l = listen;
  if (!l || l.finished) return;
  l.releasedAt = Date.now();
  // Taste ist los, aber wir hören noch kurz weiter, damit das Ende nicht abgeschnitten wird
  setStatus("Ich höre genau hin …", "thinking");
  scheduleStop(l);
}
const ptt = $("#ptt");
ptt.addEventListener("pointerdown", (e) => { e.preventDefault(); ptt.setPointerCapture?.(e.pointerId); startListening(); });
["pointerup", "pointercancel"].forEach((ev) => ptt.addEventListener(ev, stopListening));
ptt.addEventListener("contextmenu", (e) => e.preventDefault());
document.addEventListener("keydown", (e) => { if (e.code === "Space" && !e.repeat && !$("#screen-talk").hidden) { e.preventDefault(); startListening(); } });
document.addEventListener("keyup", (e) => { if (e.code === "Space" && !$("#screen-talk").hidden) { e.preventDefault(); stopListening(); } });
$("#text-fallback").addEventListener("submit", (e) => {
  e.preventDefault();
  const t = $("#text-input").value.trim();
  $("#text-input").value = "";
  if (t) { $("#heard").textContent = t; ask(t); }
});

async function ask(text, extra = {}) {
  if (!kid) return;
  busy = true;
  setStatus("Ich denke nach …", "thinking");
  abortCtl = new AbortController();
  const myCtl = abortCtl;
  let buffer = "", spokeAny = false, done = false, fixed = false; // fixed: Limit- und Fehleransagen (feste Texte)
  const askConvo0 = convoId;
  let askConvo = null;
  let newAvatar = null; // Server meldet Avatar-Änderungen: \u001eavatar:ID\u001e (neu gezeichnet) oder \u001eavatars\u001e
  const finish = () => { if (done && speakQueue === 0 && myCtl === abortCtl) { busy = false; setStatus("Drück und halte mich!", "idle"); } };
  const flush = (all) => {
    // Satzweise vorlesen, sobald ein Satz vollständig ist
    const re = /^[\s\S]*?[.!?…:](\s|$)/;
    let m;
    while ((m = buffer.match(re)) && m[0].trim().length > 1) {
      buffer = buffer.slice(m[0].length);
      spokeAny = true;
      setStatus("…", "speaking");
      speak(m[0], finish, { fixed });
    }
    if (all && buffer.trim()) { spokeAny = true; setStatus("…", "speaking"); speak(buffer, finish, { fixed }); buffer = ""; }
  };
  try {
    const r = await fetch("/api/talk", {
      method: "POST",
      credentials: "same-origin",
      headers: H({ "Content-Type": "application/json" }),
      body: JSON.stringify({ kidId: kid.id, text, convoId, mode, ...extra }),
      signal: myCtl.signal,
    });
    if (!r.ok) {
      let say = "Hoppla, da hat etwas nicht geklappt.";
      try { const j = await r.json(); say = j.say || say; } catch {}
      if (r.status === 401) say = "Dieses Gerät ist nicht mehr freigegeben. Frag Mama oder Papa.";
      buffer = say;
      fixed = true;
    } else {
      $("#extend-open").hidden = r.headers.get("X-LC-Limit") !== "1";
      fixed = r.headers.has("X-LC-Limit");
      const newId = r.headers.get("X-Convo-Id");
      if (newId && newId !== convoId) { convoId = newId; }
      askConvo = newId || askConvo0;
      setMode(r.headers.get("X-Convo-Mode"));
      const reader = r.body.getReader();
      const dec = new TextDecoder();
      for (;;) {
        const { value, done: end } = await reader.read();
        if (end) break;
        buffer += dec.decode(value, { stream: true });
        buffer = buffer.replace(/\u001eavatar:([a-f0-9]{16})\u001e/g, (_, id) => { newAvatar = id; return ""; })
          .replace(/\u001eavatars\u001e/g, () => { newAvatar = true; return ""; }); // per Sprache Profilbild gewählt oder gelöscht
        if (buffer.includes("\u001e")) continue; // Meldung noch unvollständig
        flush(false);
      }
    }
    flush(true);
  } catch (e) {
    if (e.name === "AbortError") return;
    buffer = "Ich habe gerade keine Verbindung. Versuch es gleich nochmal.";
    fixed = true;
    flush(true);
  }
  done = true;
  // Neuer oder umgestalteter Avatar fertig: die Blase dieses Gesprächs platzt (der Server hat sie schon zerplatzt)
  if (kid && typeof newAvatar === "string" && askConvo) avatarDonePop(askConvo);
  if (kid && newAvatar) { const k = kid; api("/api/avatars?kidId=" + encodeURIComponent(k.id)).then((l) => { if (kid === k) setProfileAvatar(l); }).catch(() => {}); }
  if (kid) { const k = kid; setTimeout(() => { if (kid === k) loadBubbles(); }, 5000); } // neue/aktualisierte Blase
  if (!spokeAny) finish();
  else finish();
}

// ------------------------------------------------------------------ Eltern-Bereich
let pv = null;
async function openParent() {
  show("parent");
  pv = await api("/api/parent");
  renderParent();
  api("/api/state").then((st) => { $("#app-version").textContent = st.version ? " Version " + st.version + "." : ""; }).catch(() => {});
}
function fmtUsd(n) { return "$" + Number(n || 0).toFixed(2); }
// Hinweis, wie andere Geräte den Server erreichen (häufigster Stolperstein: Tablet ohne Tailscale).
function renderReach(r, el = $("#reach")) {
  el.innerHTML = "";
  const p = (text, cls) => { const x = document.createElement("p"); x.className = cls || "hint"; x.textContent = text; el.append(x); return x; };
  if (r.url) {
    const x = p("Adresse für Tablets und Handys: ", "reach-url");
    const a = document.createElement("a");
    a.href = r.url; a.textContent = r.url; a.rel = "noopener";
    x.append(a);
    if (el.id === "reach") p("Auf jedem Gerät muss die Tailscale-App installiert und mit demselben Konto angemeldet sein. Dann diese Adresse im Browser öffnen, hier als Eltern anmelden und das Gerät freigeben.");
  } else if (r.tailscale === "fehlt" || r.tailscale === "aus") {
    p(r.tailscale === "fehlt" ? "Tailscale ist auf dem Server nicht installiert. Andere Geräte erreichen die App so nicht." : "Tailscale ist auf dem Server nicht angemeldet. Andere Geräte erreichen die App so nicht.", "hint warn");
    p("Lösung: Tailscale auf dem Server installieren und anmelden, dann in einer Admin-Konsole: tailscale serve --bg 8787. Danach auf jedem Tablet die Tailscale-App mit demselben Konto anmelden.");
  } else if (r.serve === false) {
    p("Tailscale läuft, aber die App ist noch nicht im Tailnet freigegeben. Andere Geräte erreichen sie so nicht.", "hint warn");
    p("Lösung: auf dem Server in einer Admin-Konsole: tailscale serve --bg 8787");
  }
  if (!r.url && !r.tailscale && !el.childElementCount) p("Die Adresse für die Tablets findest du in der Tailscale-App am Rechner. Sie endet auf .ts.net und beginnt mit https://.");
  if (r.via === "lokal am Server" && r.url) p("Du bist gerade direkt am Server. Diese Seite funktioniert hier, auf anderen Geräten nur über die Adresse oben.");
}

function renderParent() {
  if (!$("#kid-id").value && pv.nextKidColor) $("#kid-color").value = pv.nextKidColor;
  if (!$("#kid-id").value && !$("#kid-modes").childElementCount) renderModeChecks(null);
  $("#key-state").innerHTML = pv.keyConfigured
    ? `<span class="ok">● Schlüssel hinterlegt (endet auf …${pv.keyLast4}, ${pv.keySource === "env" ? "aus der .env-Datei" : "verschlüsselt gespeichert"})</span>`
    : `<span class="bad">● Noch kein API-Schlüssel hinterlegt.</span>`;
  $("#key-edit").hidden = pv.keySource === "env";
  $("#key-delete").hidden = pv.keySource !== "db";
  $("#backup-dir").textContent = pv.backupDir;
  document.querySelectorAll(".backup-days").forEach((e) => (e.textContent = pv.backupKeep || 30));
  const sel = $("#model");
  fillChoice(sel, false);
  sel.value = `${pv.settings.provider || "anthropic"}|${pv.settings.model}`;
  const km = $("#kid-model"), kmPrev = km.value;
  fillChoice(km, true);
  km.value = kmPrev;
  if (km.selectedIndex < 0) km.value = "";
  choiceWarning(sel, $("#model-warning"));
  choiceWarning(km, $("#kid-model-warning"));
  renderProviders();
  $("#global-usd").value = pv.settings.globalMonthlyUsd;
  $("#wake-min").value = pv.settings.wakeMinutes ?? 10;
  $("#wake-hint").textContent = WAKE_SUPPORTED
    ? "Dieses Gerät kann den Bildschirm wach halten."
    : "Dieses Gerät (oder dieser Browser) kann den Bildschirm nicht wach halten. Auf iPad/iPhone geht das erst ab iOS 16.4, als App vom Home-Bildschirm ab iOS 18.4. Sonst in den Einstellungen unter „Anzeige & Helligkeit“ › „Automatische Sperre“ eine längere Zeit wählen.";
  $("#tz-now").textContent = `Uhrzeit laut Server gerade: ${pv.time.now} Uhr (${pv.time.zone}). Erlaubte Uhrzeiten gelten in der Zeitzone des jeweiligen Tablets.`;
  $("#global-usage").textContent = `Diesen Monat verbraucht: ${fmtUsd(pv.globalMonthUsd)} (Schätzung aus den Token-Zahlen)`;
  $("#persona").value = pv.settings.persona || pv.personaDefault;
  $("#app-name").value = pv.settings.appName || "";
  $("#app-name").placeholder = pv.appNameDefault || "LittleChat";
  $("#persona-state").textContent = pv.settings.persona ? "Eigene Fassung aktiv." : "Standard aktiv.";

  const kids = $("#parent-kids");
  kids.innerHTML = "";
  for (const k of pv.kids) {
    const row = document.createElement("div");
    row.className = "pk";
    row.style.setProperty("--kid", k.color);
    const lim = (v, unit) => (v > 0 ? `${v} ${unit}` : "∞");
    row.innerHTML = `<div class="pk-main"><b></b> <span class="muted"></span><div class="pk-usage muted"></div></div>
      <div class="row"><button data-act="edit">Bearbeiten</button><button data-act="lock"></button></div>`;
    row.querySelector("b").textContent = k.name;
    row.querySelector(".muted").textContent = `${k.age} Jahre · ${k.from && k.to ? k.from + "–" + k.to + " Uhr" : "ohne Zeitsperre"} · ${k.provider && k.model ? choiceName(k.provider, k.model) : "Standard-Modell"}`;
    const km = (pv.modes || []).filter((m) => !Array.isArray(k.modes) || k.modes.includes(m.id));
    if (pv.modes?.length) row.querySelector(".muted").textContent += ` · Modi: ${km.length === pv.modes.length ? "alle" : km.map((m) => m.emoji + " " + m.name).join(", ")}`;
    row.querySelector(".pk-usage").textContent =
      `Heute: ${k.usage.minutes}/${lim(k.minutesPerDay, "Min.")} · ${k.usage.questions}/${lim(k.questionsPerDay, "Fragen")} · ${k.usage.tokens}/${lim(k.tokensPerDay, "Tokens")} · Monat: ${fmtUsd(k.usage.monthUsd)}/${k.monthlyUsd > 0 ? fmtUsd(k.monthlyUsd) : "∞"}`;
    if (k.extension) row.querySelector(".pk-usage").textContent += " · Verlängert " +
      (k.extension.allDay ? "für heute" : "bis " + new Date(k.extension.until).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) + " Uhr");
    row.querySelector('[data-act="edit"]').onclick = () => editKid(k);
    const lb = row.querySelector('[data-act="lock"]');
    if (k.lock) {
      row.querySelector(".pk-usage").textContent += ` · 🔒 Farbschloss an (${k.lock.by === "Kind" ? "vom Kind" : "von euch"} eingerichtet)`;
      lb.textContent = "Farbschloss zurücksetzen";
      lb.onclick = async () => {
        if (!confirm(`Farbschloss von ${k.name} entfernen? ${k.name} kann danach ein neues einrichten.`)) return;
        pv = await api(`/api/parent/kids/${k.id}/lock`, { method: "DELETE" });
        renderParent();
      };
    } else {
      lb.textContent = "Farbschloss festlegen";
      lb.onclick = async () => {
        const c1 = await askCombo({ title: `Farbschloss für ${k.name}`, hint: "Drei Farben in Reihenfolge. Sagt sie danach eurem Kind." });
        if (!c1) return;
        const c2 = await askCombo({ title: "Zur Sicherheit nochmal", hint: "Dieselben drei Farben." });
        if (!c2) return;
        if (c1.join() !== c2.join()) return alert("Die Farben waren verschieden. Bitte nochmal.");
        pv = await api(`/api/parent/kids/${k.id}/lock`, { method: "PUT", body: { combo: c1 } });
        renderParent();
      };
    }
    kids.append(row);
  }
  if (!pv.kids.length) kids.innerHTML = `<p class="muted">Noch kein Kind angelegt.</p>`;
  renderParentAvatars();

  const ext = pv.extensions || [];
  $("#ext-log-box").hidden = !ext.length;
  $("#ext-log").innerHTML = "";
  for (const e of ext) {
    const li = document.createElement("li");
    li.textContent = `${new Date(e.at).toLocaleString("de-DE", { dateStyle: "short", timeStyle: "short" })}: ${e.kidName} ${e.minutes === "today" ? "für heute" : "+" + e.minutes + " Min."} (Grund: ${e.reason}, Gerät: ${e.device})`;
    $("#ext-log").append(li);
  }

  renderReach(pv.reach || {});
  renderInstall($("#install-parent"));
  const dev = $("#devices");
  dev.innerHTML = "";
  if (!pv.devices.length) dev.innerHTML = `<p class="muted">Noch kein Gerät freigegeben.</p>`;
  const fmt = (t) => (t ? new Date(t).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" }) : "nie");
  for (const d of pv.devices) {
    const row = document.createElement("div");
    row.className = "pk";
    row.innerHTML = `<div class="pk-main"><b></b> <span class="tag"></span><div class="muted dev-kind"></div><div class="muted dev-use"></div><div class="muted dev-time"></div></div>
      <div class="row"><button data-act="rename">Umbenennen</button><button class="danger" data-act="del">Sperren</button></div>`;
    row.querySelector("b").textContent = d.name;
    const tag = row.querySelector(".tag");
    if (d.current) tag.textContent = "dieses Gerät"; else tag.remove();
    const ua = d.ua;
    row.querySelector(".dev-kind").textContent = ua ? `${ua.type} · ${ua.os} · ${ua.browser}` + (d.via ? (d.via === "lokal am Server" ? " · direkt am Server" : ` · über ${d.via}`) : "") : "Gerätetyp noch unbekannt (wird beim nächsten Öffnen erkannt)";
    row.querySelector(".dev-use").textContent = d.kids.length
      ? `Genutzt von ${d.kids.join(", ")} · ${d.convos} Gespräch${d.convos === 1 ? "" : "e"}` + (d.lastKid ? ` · zuletzt ${d.lastKid}` : "")
      : "Noch keine Gespräche";
    row.querySelector(".dev-time").textContent = `Freigegeben ${fmt(d.created)} · zuletzt aktiv ${fmt(d.lastSeen)}` + (d.tz ? ` · Zeitzone ${d.tz.replace(/_/g, " ")}` : "");
    row.querySelector('[data-act="rename"]').onclick = async () => {
      const name = prompt("Neuer Name für das Gerät:", d.name);
      if (!name || !name.trim() || name.trim() === d.name) return;
      pv = await api(`/api/parent/devices/${d.id}`, { method: "PATCH", body: { name: name.trim() } });
      renderParent();
    };
    row.querySelector('[data-act="del"]').onclick = async () => {
      if (!confirm(`${d.name} sperren? Das Gerät kann danach nicht mehr fragen.`)) return;
      pv = await api(`/api/parent/devices/${d.id}`, { method: "DELETE" });
      renderParent();
    };
    dev.append(row);
  }
  $("#rate").value = store.get("rate", 0.95);
  renderTts();
  renderKidVoiceSelect();
  $("#retention").value = pv.settings.retentionDays;
  const ck = $("#convo-kid"), prev = ck.value;
  ck.innerHTML = "";
  ck.add(new Option("Alle Kinder", ""));
  for (const k of pv.kids) ck.add(new Option(k.name, k.id));
  ck.value = [...ck.options].some((o) => o.value === prev) ? prev : "";
  loadConvos();
}

// Figuren (intern Avatare), die die Kinder mit „Meine Figur“ erfunden haben: ansehen, Beschreibung lesen, zurückholen, endgültig löschen.
// Vom Kind gelöschte bleiben (blass) und lassen sich zurückholen; das Kind hat dann evtl. mehr als 3.
function renderParentAvatars() {
  const root = $("#parent-avatars");
  root.innerHTML = "";
  const withAv = pv.kids.filter((k) => k.avatars?.length);
  if (!withAv.length) { root.innerHTML = `<p class="muted">Noch keine Figuren.</p>`; return; }
  for (const k of withAv) {
    const group = document.createElement("div");
    group.className = "av-group";
    group.style.setProperty("--kid", k.color);
    const h = document.createElement("h3");
    h.className = "sub";
    h.textContent = k.name;
    const box = document.createElement("div");
    box.className = "pk-avatars";
    for (const a of k.avatars) {
      const el = document.createElement("div");
      el.className = "pk-avatar" + (a.hiddenAt ? " hidden-by-kid" : "");
      el.title = a.desc || "";
      el.append(avatarImg(a.svg, ""));
      const info = document.createElement("div");
      info.className = "pk-avatar-info";
      info.innerHTML = "<b></b><small class=\"muted\"></small>";
      info.querySelector("b").textContent = a.name;
      info.querySelector("small").textContent = a.hiddenAt ? "vom Kind gelöscht am " + new Date(a.hiddenAt).toLocaleDateString("de-DE")
        : a.active ? "Profilbild" : "erfunden am " + new Date(a.created).toLocaleDateString("de-DE");
      el.append(info);
      const acts = document.createElement("div");
      acts.className = "pk-avatar-acts";
      if (a.hiddenAt) {
        const back = document.createElement("button");
        back.textContent = "Zurückholen";
        back.onclick = async () => { pv = await api(`/api/parent/avatars/${a.id}/restore`, { method: "POST" }); renderParent(); };
        acts.append(back);
      }
      const del = document.createElement("button");
      del.className = "danger";
      del.textContent = "Endgültig löschen";
      del.onclick = async () => {
        if (!confirm(`Figur „${a.name}“ von ${k.name} endgültig löschen? Das lässt sich nicht rückgängig machen.`)) return;
        pv = await api(`/api/parent/avatars/${a.id}`, { method: "DELETE" });
        renderParent();
      };
      acts.append(del);
      el.append(acts);
      box.append(el);
    }
    group.append(h, box);
    root.append(group);
  }
}

// ------------------------------------------------------------------ Gespräche (Eltern)
const TRASH_SVG = `<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const fmtDate = (iso) => new Date(iso).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" });
async function loadConvos() {
  const all = await api("/api/parent/convos" + ($("#convo-kid").value ? "?kidId=" + $("#convo-kid").value : ""));
  const f = $("#convo-filter").value;
  const list = all.filter((c) => (f === "popped" ? c.kidPoppedAt : f === "visible" ? !c.kidPoppedAt : true));
  const nPopped = all.filter((c) => c.kidPoppedAt).length;
  $("#convo-filter").options[2].textContent = `Nur vom Kind zerplatzte (${nPopped})`;
  $("#popped-legend").hidden = !list.some((c) => c.kidPoppedAt);
  const box = $("#convos");
  box.innerHTML = list.length ? "" : `<p class="muted">${!all.length ? "Noch keine Gespräche." : f === "popped" ? "Keine zerplatzten Seifenblasen." : "Keine Gespräche in dieser Auswahl."}</p>`;
  const names = Object.fromEntries(pv.kids.map((k) => [k.id, k]));
  $("#convos-delete-all").textContent = $("#convo-kid").value
    ? `Alle Gespräche von ${names[$("#convo-kid").value]?.name || "diesem Kind"} löschen (${list.length})`
    : `Alle Gespräche löschen (${list.length})`;
  $("#convos-delete-all").disabled = !list.length;
  for (const c of list) {
    const wrap = document.createElement("div");
    wrap.className = "convo-item" + (c.kidPoppedAt ? " popped" : "");
    const row = document.createElement("button");
    row.className = "convo-row";
    row.style.setProperty("--kid", names[c.kidId]?.color || "var(--line)");
    row.innerHTML = `<span class="convo-emoji"></span><span class="convo-main"><span class="convo-title"><b></b></span><span class="muted"></span></span>`;
    const del = document.createElement("button");
    del.className = "convo-del danger";
    del.title = del.ariaLabel = "Gespräch löschen";
    del.innerHTML = TRASH_SVG;
    del.onclick = () => deleteConvo(c.id, c.title);
    wrap.append(row, del);
    row.querySelector(".convo-emoji").textContent = c.emoji;
    row.querySelector("b").textContent = c.title;
    if (c.kidPoppedAt) {
      const bd = document.createElement("span");
      bd.className = "badge popped";
      bd.textContent = "💥 zerplatzt " + new Date(c.kidPoppedAt).toLocaleDateString("de-DE", { day: "numeric", month: "numeric" });
      bd.title = "Vom Kind zerplatzt am " + fmtDate(c.kidPoppedAt) + ". Das Kind sieht dieses Gespräch nicht mehr.";
      row.querySelector(".convo-title").append(bd);
    }
    if (c.flagged) {
      const bd = document.createElement("span");
      bd.className = "badge flagged";
      bd.textContent = "⚠ abgelehnte Frage";
      row.querySelector(".convo-title").append(bd);
    }
    const cm = (pv.modes || []).find((m) => m.id === c.mode);
    row.querySelector(".muted").textContent =
      `${names[c.kidId]?.name || "?"} · ${cm ? cm.emoji + " " + cm.name + " · " : ""}${fmtDate(c.updated)} · ${Math.ceil(c.count / 2)} ${Math.ceil(c.count / 2) === 1 ? "Frage" : "Fragen"}` +
      (c.parentSeenAt ? " · angesehen" : "") + (c.kidNotifiedAt ? " · Kind weiß Bescheid" : "");
    row.onclick = () => openConvo(c.id);
    box.append(wrap);
  }
}
$("#convo-kid").onchange = loadConvos;
$("#convo-filter").onchange = loadConvos;
let openConvoId = null;
async function openConvo(cid) {
  const c = await api("/api/parent/convos/" + cid);
  openConvoId = cid;
  const cmode = (pv.modes || []).find((m) => m.id === c.mode);
  $("#convo-title").textContent = `${c.emoji} ${c.title}` + (cmode ? ` · ${cmode.emoji} ${cmode.name}` : "");
  $("#convo-popped").hidden = !c.kidPoppedAt;
  if (c.kidPoppedAt) $("#convo-popped").textContent = `💥 ${pv.kids.find((k) => k.id === c.kidId)?.name || "Das Kind"} hat diese Seifenblase am ${fmtDate(c.kidPoppedAt)} zerplatzen lassen. Für das Kind ist das Gespräch weg, ihr könnt es hier noch lesen oder endgültig löschen.`;
  const body = $("#convo-body");
  body.innerHTML = "";
  if (c.memory) {
    const m = document.createElement("p");
    m.className = "hint";
    m.textContent = "Gedächtnis-Zusammenfassung: " + c.memory;
    body.append(m);
  }
  for (const msg of c.messages) {
    const d = document.createElement("div");
    d.className = "msg " + msg.role + (msg.refused ? " refused" : "");
    d.innerHTML = `<div class="msg-meta"></div><div class="msg-text"></div>`;
    d.querySelector(".msg-meta").textContent = (msg.role === "user" ? "Kind" : APP) + " · " + fmtDate(msg.at) + (msg.refused ? " · abgelehnt" : "");
    d.querySelector(".msg-text").textContent = msg.text;
    body.append(d);
  }
  $("#convo-dialog").showModal();
  loadConvos();
}
$("#convo-close").onclick = () => $("#convo-dialog").close();
const purgeQs = () => ($("#purge-backups").checked ? "?purgeBackups=1" : "");
async function deleteConvo(id, title) {
  if (!confirm(`„${title}“ endgültig löschen? Das lässt sich nicht rückgängig machen.`)) return false;
  await api("/api/parent/convos/" + id + purgeQs(), { method: "DELETE" });
  $("#delete-state").textContent = `„${title}“ gelöscht.` + ($("#purge-backups").checked ? " Sicherungen bereinigt." : "");
  loadConvos();
  return true;
}
$("#convo-delete").onclick = async () => {
  if (!openConvoId) return;
  if (await deleteConvo(openConvoId, $("#convo-title").textContent)) $("#convo-dialog").close();
};
$("#convos-delete-all").onclick = async () => {
  const kidId = $("#convo-kid").value;
  const who = kidId ? pv.kids.find((k) => k.id === kidId)?.name : null;
  const n = $("#convos").querySelectorAll(".convo-item").length;
  if (!confirm(`${n} Gespräch${n === 1 ? "" : "e"} ${who ? `von ${who} ` : ""}endgültig löschen? Das lässt sich nicht rückgängig machen.`)) return;
  const qs = new URLSearchParams();
  if (kidId) qs.set("kidId", kidId);
  if ($("#purge-backups").checked) qs.set("purgeBackups", "1");
  const r = await api("/api/parent/convos?" + qs, { method: "DELETE" });
  $("#delete-state").textContent = `${r.deleted} Gespräch${r.deleted === 1 ? "" : "e"} gelöscht.` + (r.backupsPurged ? ` ${r.backupsPurged} alte Sicherung(en) ersetzt.` : "");
  loadConvos();
};
$("#retention-save").onclick = async () => {
  pv = await api("/api/parent/settings", { method: "PUT", body: { retentionDays: $("#retention").value } });
  $("#retention-state").textContent = "Gespeichert. Ältere Gespräche wurden gelöscht.";
  renderParent();
}

const KID_FIELDS = { name: "#kid-name", birth: "#kid-birth", color: "#kid-color", from: "#kid-from", to: "#kid-to",
  minutesPerDay: "#kid-minutes", questionsPerDay: "#kid-questions", tokensPerDay: "#kid-tokens", monthlyUsd: "#kid-usd", model: "#kid-model", voice: "#kid-voice" };
function editKid(k) {
  $("#kid-birth").max = new Date().toLocaleDateString("en-CA");
  $("#kid-id").value = k.id;
  renderKidVoiceSelect(k.voice || "");
  for (const [f, s] of Object.entries(KID_FIELDS)) $(s).value = k[f] ?? "";
  if ($("#kid-voice").selectedIndex < 0) $("#kid-voice").value = "";
  $("#kid-model").value = k.provider && k.model ? `${k.provider}|${k.model}` : "";
  if ($("#kid-model").selectedIndex < 0) $("#kid-model").value = "";
  choiceWarning($("#kid-model"), $("#kid-model-warning"));
  $("#kid-notify").checked = k.notifySeen !== false;
  $("#kid-captions").checked = k.captions !== false;
  renderModeChecks(k.modes);
  notifyHint();
  $("#kid-form-title").textContent = `${k.name} bearbeiten`;
  $("#kid-submit").textContent = "Speichern";
  $("#kid-delete").hidden = false;
  $("#kid-delete").textContent = `${k.name} löschen`;
  showKidForm(true);
  kidFormReady();
  $("#kid-form").scrollIntoView({ behavior: "smooth" });
}
function resetKidForm() {
  $("#kid-form").reset();
  $("#kid-birth").max = new Date().toLocaleDateString("en-CA");
  if (pv?.nextKidColor) $("#kid-color").value = pv.nextKidColor;
  $("#kid-id").value = "";
  renderKidVoiceSelect("");
  $("#kid-form-title").textContent = "Kind hinzufügen";
  $("#kid-submit").textContent = "Kind hinzufügen";
  $("#kid-delete").hidden = true;
  showKidForm(false);
  $("#kid-error").textContent = "";
  renderModeChecks(null);
  notifyHint();
  kidFormReady();
}
$("#kid-cancel").onclick = resetKidForm;
function showKidForm(on) {
  $("#kid-form").hidden = !on;
  $("#kid-add-row").hidden = on;
}
$("#kid-add").onclick = () => {
  resetKidForm();
  showKidForm(true);
  $("#kid-name").focus();
};
$("#kid-delete").onclick = async () => {
  const k = pv.kids.find((x) => x.id === $("#kid-id").value);
  if (!k || !confirm(`${k.name} wirklich löschen? Einstellungen, Limits und Farbschloss von ${k.name} sind danach weg.`)) return;
  pv = await api(`/api/parent/kids/${k.id}`, { method: "DELETE" });
  resetKidForm();
  renderParent();
};

// Gesprächsmodi pro Kind freischalten (Standard: alle). Mindestens einer bleibt an.
function renderModeChecks(sel) {
  const box = $("#kid-modes");
  box.innerHTML = "";
  for (const m of pv?.modes || []) {
    const l = document.createElement("label");
    l.className = "check mode-check";
    l.innerHTML = `<input type="checkbox"> <span><b></b> <span class="muted"></span></span>`;
    const cb = l.querySelector("input");
    cb.value = m.id;
    cb.checked = !Array.isArray(sel) || sel.includes(m.id);
    cb.onchange = () => { if (!box.querySelector("input:checked")) { cb.checked = true; $("#kid-error").textContent = "Mindestens ein Modus muss an bleiben."; } };
    l.querySelector("b").textContent = `${m.emoji} ${m.name}`;
    l.querySelector(".muted").textContent = m.about;
    box.append(l);
  }
  $("#kid-modes-box").hidden = !(pv?.modes || []).length;
}

// Neutraler, altersabhängiger Hinweis am Schalter "Eltern haben geschaut"
function notifyHint() {
  const b = $("#kid-birth").value;
  let age = null;
  if (b) {
    const d = new Date(b + "T00:00:00"), n = new Date();
    age = n.getFullYear() - d.getFullYear() - (n < new Date(n.getFullYear(), d.getMonth(), d.getDate()) ? 1 : 0);
  }
  const base = "Bei kleinen Kindern ist es unproblematisch, den Hinweis auszuschalten. Ab dem Schulalter kann heimliches Mitlesen dem Vertrauen schaden, wenn das Kind es herausfindet. Transparenz wird daher empfohlen. Die Entscheidung liegt bei euch.";
  let extra = "";
  const ageEl = $("#kid-age");
  ageEl.textContent = age === null ? "" : age < 0 ? "Das Datum liegt in der Zukunft." : age > 18
    ? `${age} Jahre. LittleChat ist für Kinder gebaut und spricht ab 12 wie mit Jugendlichen. Für einen eigenen Test ist das in Ordnung.`
    : `${age} Jahre`;
  ageEl.classList.toggle("error", age !== null && age < 0);
  if (age !== null && age < 0) age = null;
  if (age !== null && age < 6) extra = ` Euer Kind ist ${age}: Hier spricht wenig gegen das Ausschalten.`;
  else if (age !== null && age < 10) extra = ` Euer Kind ist ${age} und im Schulalter: Wir empfehlen, den Hinweis eingeschaltet zu lassen.`;
  else if (age !== null) extra = ` Euer Kind ist ${age}: In diesem Alter ist Offenheit besonders wichtig. Wir empfehlen, den Hinweis eingeschaltet zu lassen und auch vorab darüber zu sprechen.`;
  $("#notify-hint").textContent = base + extra;
}
$("#kid-birth").addEventListener("input", notifyHint);
// Speichern erst, wenn Vorname und ein gültiges Geburtsdatum (nicht in der Zukunft) eingetragen sind
function kidFormReady() {
  const b = $("#kid-birth").value, today = new Date().toLocaleDateString("en-CA");
  $("#kid-submit").disabled = !$("#kid-name").value.trim() || !b || b > today || b < "1900-01-01";
}
for (const s of ["#kid-name", "#kid-birth"]) { $(s).addEventListener("input", kidFormReady); $(s).addEventListener("change", kidFormReady); }
kidFormReady();
$("#kid-notify").addEventListener("change", notifyHint);
notifyHint();
$("#kid-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = {};
  for (const [f, s] of Object.entries(KID_FIELDS)) body[f] = $(s).value;
  body.notifySeen = $("#kid-notify").checked;
  body.captions = $("#kid-captions").checked;
  const prevKid = pv.kids.find((k) => k.id === $("#kid-id").value);
  if (body.model && body.model !== `${prevKid?.provider}|${prevKid?.model}` && !confirmChoice(body.model)) return;
  if (body.voice.startsWith("elevenlabs:") && body.voice !== prevKid?.voice && !confirm("ElevenLabs ist der teuerste Stimmen-Dienst (etwa 2 bis 4 Dollar pro Stunde Vorlesen). Für dieses Kind übernehmen?")) return;
  if ((pv?.modes || []).length) body.modes = [...$("#kid-modes").querySelectorAll("input:checked")].map((x) => x.value);
  const idv = $("#kid-id").value;
  try {
    pv = await api(idv ? `/api/parent/kids/${idv}` : "/api/parent/kids", { method: idv ? "PUT" : "POST", body });
    resetKidForm();
    renderParent();
  } catch (err) { $("#kid-error").textContent = err.message; }
});

$("#settings-save").onclick = async () => {
  if ($("#model").value !== `${pv.settings.provider}|${pv.settings.model}` && !confirmChoice($("#model").value)) return;
  try {
    pv = await api("/api/parent/settings", { method: "PUT", body: { model: $("#model").value } });
    renderParent();
    $("#settings-state").textContent = "Gespeichert.";
  } catch (e) { $("#settings-state").textContent = e.message; }
};
$("#limits-save").onclick = async () => {
  try {
    pv = await api("/api/parent/settings", { method: "PUT", body: { globalMonthlyUsd: $("#global-usd").value, wakeMinutes: $("#wake-min").value } });
    renderParent();
    $("#limits-state").textContent = "Gespeichert.";
  } catch (e) { $("#limits-state").textContent = e.message; }
};
$("#key-test").onclick = async () => {
  $("#settings-state").textContent = "Teste …";
  try {
    const [provider, ...rest] = $("#model").value.split("|");
    const r = await api("/api/parent/test", { method: "POST", body: { provider, model: rest.join("|") } });
    $("#settings-state").textContent = `Funktioniert (${r.model}): „${r.text}“`;
  } catch (e) { $("#settings-state").textContent = "Fehler: " + e.message; }
};
$("#device-pair").onclick = async () => {
  pv = await api("/api/parent/devices", { method: "POST", body: { name: $("#device-name").value.trim(), touch: navigator.maxTouchPoints > 1 } });
  $("#device-name").value = "";
  renderParent();
};
$("#app-name-save").onclick = async () => {
  try {
    pv = await api("/api/parent/settings", { method: "PUT", body: { appName: $("#app-name").value } });
    APP = pv.settings.appName || pv.appNameDefault || "LittleChat";
    document.title = APP;
    document.querySelectorAll(".app-name").forEach((el) => (el.textContent = APP));
    renderParent();
    $("#app-name-state").textContent = `Gespeichert. Ab jetzt meldet sich der Assistent als „${APP}“.`;
  } catch (e) { $("#app-name-state").textContent = e.message; }
};
$("#persona-save").onclick = async () => {
  const text = $("#persona").value;
  pv = await api("/api/parent/settings", { method: "PUT", body: { persona: text.trim() === pv.personaDefault.trim() ? null : text } });
  renderParent();
};
$("#persona-reset").onclick = async () => {
  if (!confirm("Eigene Fassung verwerfen und Standard verwenden?")) return;
  pv = await api("/api/parent/settings", { method: "PUT", body: { persona: null } });
  renderParent();
};
function renderTts() {
  const t = pv.tts || { provider: "browser" };
  // Gewählt, aber gerade nicht nutzbar (z. B. Schlüssel entfernt): zeigen, was gewünscht war
  $("#tts-provider").value = pv.ttsWanted && pv.ttsWanted !== t.provider && pv.ttsServices?.[pv.ttsWanted] ? pv.ttsWanted : t.provider;
  if ($("#tts-provider").selectedIndex < 0) $("#tts-provider").value = t.provider;
  $("#tts-url").value = t.url || "";
  $("#tts-model").value = t.model || "";
  $("#tts-custom-voice").value = t.customVoice || "";
  $("#cloud-rate").value = t.cloudRate || 1;
  $("#cloud-region").value = t.azureRegion || "";
  renderPiper(t);
  showTtsFields();
  $("#voice-tip").textContent = isIos()
    ? "Tipp fürs iPad: Einstellungen › Bedienungshilfen › Gesprochene Inhalte › Stimmen › Deutsch › „Anna (Premium)“ oder „(Erweitert)“ laden. Danach hier auswählen. Die beste Stimme wird automatisch genommen."
    : /Android/.test(navigator.userAgent)
      ? "Tipp für Android: Einstellungen › Sprachausgabe › Google-Sprachausgabe › Sprachdaten installieren › Deutsch, dort die Stimme in hoher Qualität laden."
      : "Die beste installierte deutsche Stimme wird automatisch gewählt (★ = hohe Qualität).";
}
// Cloud-Stimmen (Google, Azure, ElevenLabs): ein gemeinsames Formular, Texte je Dienst
const CLOUD = {
  google: { field: "googleVoice", about: "Neue Google-Stimmen (Chirp 3 HD) klingen sehr natürlich. Du brauchst ein Google-Cloud-Konto mit Zahlungsmittel und einen API-Schlüssel.",
    key: "API-Schlüssel, beginnt meist mit AIza" },
  azure: { field: "azureVoice", about: "Neural-Stimmen von Microsoft, darunter Gisela, eine Kinderstimme. Mit der kostenlosen Stufe F0 kann es nichts kosten. Du brauchst Schlüssel und Region deiner Speech-Ressource.",
    key: "Schlüssel 1 der Speech-Ressource" },
  elevenlabs: { field: "elevenVoice", about: "Sehr ausdrucksstarke Stimmen. LittleChat zeigt die Stimmen aus deinem ElevenLabs-Konto (unter „Voices“ hinzufügen).",
    key: "API-Schlüssel, beginnt meist mit sk_" },
};
const usd = (n) => n.toLocaleString("de-DE", { maximumFractionDigits: 2 });
function renderCloud(svc) {
  const s = pv.ttsServices?.[svc], c = CLOUD[svc], t = pv.tts || {};
  if (!s || !c) return;
  document.querySelectorAll("#tts-cloud .cloud-name").forEach((el) => (el.textContent = s.label));
  $("#cloud-about").textContent = c.about + (s.models ? " Preise: Flash v2.5 ca. 40 $, Multilingual v2 ca. 80 $ pro Mio. Zeichen, Gratis-Credits nur im Abo" : " Preise je Stimmtyp: " + s.tiers.map((x) => `${x.label} ${usd(x.usdPerM)} $ pro Mio. Zeichen${x.freeM ? ` (${usd(x.freeM)} Mio. gratis im Monat)` : ""}`).join(", ")) +
    ". Eine Minute Vorlesen sind etwa 900 Zeichen. Die Kosten zählen mit vollem Preis in die Monatsbudgets.";
  $("#cloud-cost-warn").hidden = !s.expensive;
  $("#cloud-cost-warn").textContent = "Achtung, teuerster Stimmen-Dienst: Eine Stunde Vorlesen kostet etwa 2 Dollar (Flash) bis 4 Dollar (Multilingual). Setz ein niedriges Monatsbudget, schalte bei ElevenLabs die nutzungsbasierte Abrechnung aus, oder nutze ElevenLabs nur für ein Kind.";
  $("#cloud-guide").href = "/anleitung/" + s.guide;
  $("#cloud-key").value = "";
  $("#cloud-key").placeholder = s.keyLast4 ? (s.keySource === "env" ? `aus der .env-Datei …${s.keyLast4}` : `gespeichert …${s.keyLast4} (leer lassen = behalten)`) : c.key;
  $("#cloud-region-wrap").hidden = svc !== "azure";
  $("#cloud-model-wrap").hidden = !s.models;
  const ms = $("#cloud-model");
  ms.innerHTML = "";
  for (const m of s.models || []) ms.add(new Option(m.label, m.id));
  if (s.models) ms.value = t.elevenModel || s.models[0].id;
  fillCloudVoices(svc, s.voices, t[c.field] || s.defaultVoice);
  $("#cloud-usage").textContent = s.monthChars ? `Diesen Monat vorgelesen: ${s.monthChars.toLocaleString("de-DE")} Zeichen.` : "";
  $("#cloud-down").hidden = !s.down;
  if (s.down) $("#cloud-down").textContent = `Gerade nicht erreichbar, es spricht Piper (seit ${new Date(s.down.at).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })}): ${s.down.error}`;
  $("#cloud-remove").hidden = s.keySource !== "db";
}
function fillCloudVoices(svc, voices, current) {
  const sel = $("#cloud-voice");
  sel.innerHTML = "";
  if (!voices?.length) sel.add(new Option(svc === "elevenlabs" ? "Erst Schlüssel eintragen und „Stimmen laden“" : "Erst „Stimmen laden“", ""));
  // Google: nach Stimmtyp gruppiert (Chirp 3 HD, Neural2, WaveNet, Standard), Preis steht am Typ
  const groups = new Map();
  for (const v of voices || []) {
    const [g, ...rest] = svc === "google" ? v.label.split(" · ") : ["", v.label];
    if (!groups.has(g)) groups.set(g, []);
    groups.get(g).push(new Option(svc === "google" ? rest.join(" · ") : v.label, v.id));
  }
  for (const [g, opts] of groups) {
    if (!g) { opts.forEach((o) => sel.add(o)); continue; }
    const og = document.createElement("optgroup");
    og.label = g;
    og.append(...opts);
    sel.append(og);
  }
  if (current && ![...sel.options].some((o) => o.value === current)) sel.add(new Option(current, current));
  if (current) sel.value = current;
}
function cloudBody(svc) {
  const body = { provider: svc, cloudRate: Number($("#cloud-rate").value), [CLOUD[svc].field]: $("#cloud-voice").value };
  if (svc === "azure") body.azureRegion = $("#cloud-region").value;
  if (svc === "elevenlabs") body.elevenModel = $("#cloud-model").value;
  const key = $("#cloud-key").value.trim();
  if (key) body.key = key;
  return body;
}
$("#cloud-load").onclick = async () => {
  const svc = $("#tts-provider").value;
  $("#tts-state").textContent = "Lade Stimmen …";
  try {
    const r = await api("/api/parent/tts/voices", { method: "POST", body: cloudBody(svc) });
    fillCloudVoices(svc, r.voices, $("#cloud-voice").value || pv.ttsServices[svc].defaultVoice);
    $("#tts-state").textContent = `${r.voices.length} Stimmen gefunden. Der Schlüssel funktioniert. Zum Übernehmen „Speichern und testen“.`;
  } catch (e) { $("#tts-state").textContent = e.message; }
};
$("#cloud-preview").onclick = () => {
  const svc = $("#tts-provider").value;
  previewVoice(cloudBody(svc));
};
$("#cloud-remove").onclick = async () => {
  const svc = $("#tts-provider").value;
  if (!confirm(`Schlüssel von ${pv.ttsServices[svc].label} entfernen? Kinder mit dieser Stimme hören dann wieder die Stimme für alle.`)) return;
  try {
    pv = await api("/api/parent/tts", { method: "PUT", body: { provider: pv.tts.provider === svc ? "piper" : pv.tts.provider, removeKey: svc } });
    renderParent();
    $("#tts-state").textContent = "Schlüssel entfernt.";
  } catch (e) { $("#tts-state").textContent = e.message; }
};
const SPEAKER_DE = { neutral: "neutral", amused: "fröhlich", sleepy: "müde und ruhig", whisper: "flüsternd", surprised: "überrascht", angry: "wütend", disgusted: "angeekelt", drunk: "beschwipst" };
let piperPick = "";
function renderPiper(t) {
  const box = $("#piper-voices");
  box.innerHTML = "";
  $("#piper-missing").hidden = !!pv.piper?.length;
  $("#tts-provider").querySelector('[value="piper"]').disabled = !pv.piper?.length;
  piperPick = t.piperVoice || pv.piper?.[0]?.id || "";
  for (const v of pv.piper || []) {
    const row = document.createElement("label");
    row.className = "piper-voice";
    row.innerHTML = `<input type="radio" name="piper-voice"><span><b></b><br><span class="hint"></span></span><button type="button">▶ Probe</button>`;
    row.querySelector("input").checked = v.id === piperPick;
    row.querySelector("input").onchange = () => { piperPick = v.id; renderSpeakers(v, ""); };
    row.querySelector("b").textContent = v.label;
    row.querySelector(".hint").textContent = "Lizenz: " + v.license;
    row.querySelector("button").onclick = (e) => { e.preventDefault(); previewPiper(v.id); };
    box.append(row);
  }
  renderSpeakers((pv.piper || []).find((v) => v.id === piperPick), t.piperSpeaker);
  $("#piper-speed").value = t.piperSpeed || 1.1;
}
function renderSpeakers(v, current) {
  const sel = $("#piper-speaker");
  sel.innerHTML = "";
  $("#piper-speaker-wrap").hidden = !v?.speakers?.length;
  for (const sp of v?.speakers || []) sel.add(new Option(SPEAKER_DE[sp] || sp, sp));
  if (v?.speakers?.length) sel.value = current && v.speakers.includes(current) ? current : v.speakers.includes("amused") ? "amused" : v.speakers[0];
}
const PREVIEW_TEXT = () => `Hallo! Ich bin ${APP}. Wusstest du, dass Kraken drei Herzen haben? Was möchtest du heute wissen?`;
async function previewVoice(body) {
  stopSpeaking();
  $("#tts-state").textContent = "Erzeuge Probe …";
  try {
    const r = await fetch("/api/parent/tts/preview", { method: "POST", credentials: "same-origin", headers: H({ "Content-Type": "application/json" }), body: JSON.stringify({ text: PREVIEW_TEXT(), ...body }) });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "Fehler " + r.status);
    const url = URL.createObjectURL(await r.blob());
    player.src = url;
    await player.play();
    $("#tts-state").textContent = "";
  } catch (e) { $("#tts-state").textContent = e.message; }
}
const previewPiper = (id) => previewVoice({ provider: "piper", piperVoice: id, piperSpeaker: id === piperPick ? $("#piper-speaker").value : "", piperSpeed: Number($("#piper-speed").value) });
function showTtsFields() {
  const p = $("#tts-provider").value;
  $("#tts-piper").hidden = p !== "piper";
  $("#tts-cloud").hidden = !CLOUD[p];
  $("#tts-browser").hidden = p !== "browser";
  $("#tts-custom").hidden = p !== "custom";
  $("#browser-voice-box").open = p === "browser";
  if (CLOUD[p]) renderCloud(p);
}
$("#tts-provider").onchange = showTtsFields;
$("#tts-save").onclick = async () => {
  const provider = $("#tts-provider").value;
  let body = { provider, url: $("#tts-url").value, model: $("#tts-model").value, customVoice: $("#tts-custom-voice").value,
    piperVoice: piperPick, piperSpeaker: $("#piper-speaker").value, piperSpeed: Number($("#piper-speed").value) };
  if (CLOUD[provider]) body = { ...body, ...cloudBody(provider) };
  else if (provider === "custom" && $("#tts-custom-key").value.trim()) body.key = $("#tts-custom-key").value.trim();
  if (provider === "elevenlabs" && !confirm("ElevenLabs ist der teuerste Stimmen-Dienst (etwa 2 bis 4 Dollar pro Stunde Vorlesen). Hast du ein Monatsbudget gesetzt? Trotzdem für alle Kinder übernehmen?")) return;
  $("#tts-state").textContent = provider === "browser" ? "Speichere …" : "Teste die Stimme …";
  try {
    pv = await api("/api/parent/tts", { method: "PUT", body });
    state.tts = provider === "browser" ? "browser" : "server";
    $("#tts-custom-key").value = "";
    renderTts();
    renderKidVoiceSelect();
    $("#tts-state").textContent = provider === "browser"
      ? "Gespeichert: Jedes Gerät spricht mit seiner eigenen Stimme."
      : "Gespeichert und funktioniert. Alle Geräte sprechen jetzt mit dieser Stimme (außer Kinder mit eigener Stimme).";
  } catch (e) { $("#tts-state").textContent = e.message; }
};
// Stimme pro Kind: "wie für alle", Piper-Stimmen, eingerichtete Cloud-Stimmen, Gerätestimme
function renderKidVoiceSelect(current = $("#kid-voice").value) {
  const sel = $("#kid-voice");
  if (!sel || !pv) return;
  sel.innerHTML = "";
  const names = { piper: "Piper", google: "Google", azure: "Azure", elevenlabs: "ElevenLabs", browser: "Gerät", custom: "eigener Server" };
  sel.add(new Option(`Wie für alle (${names[pv.tts?.provider] || "Gerät"})`, ""));
  const group = (label, items) => {
    if (!items.length) return;
    const g = document.createElement("optgroup");
    g.label = label;
    for (const [v, l] of items) g.append(new Option(l, v));
    sel.append(g);
  };
  group("Piper (kostenlos, privat)", (pv.piper || []).map((v) => [`piper:${v.id}`, v.label]));
  for (const svc of ["google", "azure", "elevenlabs"]) {
    const s = pv.ttsServices?.[svc];
    if (!s?.keyLast4) continue;
    group(`${s.label}${s.expensive ? " (teuer)" : ""}`, (s.voices || []).map((v) => [`${svc}:${v.id}`, v.label]));
  }
  group("Gerät", [["browser", "Stimme des jeweiligen Geräts (Klang je nach Gerät)"]]);
  sel.value = current || "";
  if (sel.selectedIndex < 0) { if (current) sel.add(new Option(current + " (nicht mehr eingerichtet)", current)); sel.value = current || ""; }
}
$("#voice").onchange = () => store.set("voice", $("#voice").value);
$("#rate").oninput = () => store.set("rate", Number($("#rate").value));
$("#voice-test").onclick = () => { stopSpeaking(); unlockAudio(); speak(`Hallo! Ich bin ${APP}. Was möchtest du heute wissen? Wusstest du, dass Kraken drei Herzen haben?`); };
$("#pw-change").onclick = async () => {
  try {
    await api("/api/parent/password", { method: "POST", body: { old: $("#old-pw").value, password: $("#new-pw").value } });
    $("#pw-state").textContent = "Passwort geändert. Andere Eltern-Anmeldungen wurden beendet.";
    $("#old-pw").value = $("#new-pw").value = "";
  } catch (e) { $("#pw-state").textContent = e.message; }
};
async function logout() { sess.set(false); await api("/api/logout", { method: "POST" }).catch(() => {}); goHome(); }
$("#parent-close").onclick = logout; // "Fertig" meldet immer ab, damit Kinder nicht im Eltern-Bereich landen

// ------------------------------------------------------------------ PWA / Installation
const isStandalone = () => matchMedia("(display-mode: standalone)").matches || matchMedia("(display-mode: fullscreen)").matches || navigator.standalone === true;
const isIos = () => /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
let installPrompt = null;
addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); installPrompt = e; document.querySelectorAll(".install-box").forEach(renderInstall); });
addEventListener("appinstalled", () => { installPrompt = null; document.querySelectorAll(".install-box").forEach(renderInstall); });
// Zeigt je nach Browser einen Installieren-Knopf oder eine kurze Anleitung. In der installierten App: nichts.
function renderInstall(el) {
  el.innerHTML = "";
  el.hidden = isStandalone();
  if (el.hidden) return;
  const h = document.createElement("p");
  h.className = "install-title";
  h.textContent = `📲 ${APP} als App auf den Home-Bildschirm`;
  el.append(h);
  const p = document.createElement("p");
  p.className = "hint";
  if (installPrompt) {
    const b = document.createElement("button");
    b.className = "primary";
    b.textContent = "Als App installieren";
    b.onclick = async () => { const e = installPrompt; installPrompt = null; await e.prompt(); await e.userChoice.catch(() => {}); renderInstall(el); };
    el.append(b);
    p.textContent = "Danach startet die App mit eigenem Symbol im Vollbild, ohne Adressleiste.";
  } else if (isIos()) {
    p.textContent = /CriOS|FxiOS|EdgiOS/.test(navigator.userAgent)
      ? "Auf iPad und iPhone geht das am zuverlässigsten in Safari: Adresse in Safari öffnen, auf Teilen (Quadrat mit Pfeil) tippen, dann „Zum Home-Bildschirm“."
      : "In Safari auf Teilen (Quadrat mit Pfeil nach oben) tippen, dann „Zum Home-Bildschirm“ und „Hinzufügen“. Danach die App über das neue Symbol öffnen.";
  } else {
    p.textContent = "Im Browser-Menü (⋮) „App installieren“ oder „Zum Startbildschirm hinzufügen“ wählen. Danach die App über das neue Symbol öffnen.";
  }
  el.append(p);
}

$("#pair-go").onclick = async () => {
  $("#pair-error").textContent = "";
  try {
    await api("/api/pair", { method: "POST", body: { code: $("#pair-code").value, touch: navigator.maxTouchPoints > 1 } });
    $("#pair-code").value = "";
    goHome();
  } catch (e) { $("#pair-error").textContent = e.message; }
};
$("#pair-code").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#pair-go").click(); });

let codeTimer;
$("#device-code").onclick = async () => {
  const box = $("#pair-code-show");
  try {
    const r = await api("/api/parent/devices/code", { method: "POST", body: { name: $("#device-name").value.trim() } });
    $("#device-name").value = "";
    box.hidden = false;
    box.innerHTML = `<div class="pair-code"></div><p class="hint"></p>`;
    box.querySelector(".pair-code").textContent = r.code.slice(0, 3) + " " + r.code.slice(3);
    clearInterval(codeTimer);
    const tick = () => {
      const left = Math.max(0, Math.round((new Date(r.expires) - Date.now()) / 1000));
      box.querySelector(".hint").textContent = left
        ? `In der App auf dem Tablet eingeben. Gültig noch ${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")} Minuten, nur einmal.`
        : "Abgelaufen. Bitte einen neuen Code erzeugen.";
      if (!left) clearInterval(codeTimer);
    };
    tick();
    codeTimer = setInterval(tick, 1000);
    // Sobald das Tablet gekoppelt ist, taucht es in der Liste auf
    const known = new Set(pv.devices.map((d) => d.id));
    const poll = setInterval(async () => {
      if (box.hidden || !document.contains(box) || $("#screen-parent").hidden) return clearInterval(poll);
      const next = await api("/api/parent").catch(() => null);
      if (next && next.devices.some((d) => !known.has(d.id))) { clearInterval(poll); clearInterval(codeTimer); pv = next; box.hidden = true; renderParent(); }
    }, 3000);
    setTimeout(() => clearInterval(poll), 10 * 60_000);
  } catch (e) { box.hidden = false; box.textContent = e.message; }
};

if ("serviceWorker" in navigator) {
  // Nach einem Update übernimmt der neue Service Worker; dann einmal neu laden, damit Seite und Code zusammenpassen.
  const hadController = !!navigator.serviceWorker.controller;
  let reloaded = false;
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    // Nicht mitten im Sprechen und nicht im Eltern-Bereich (sonst wären Eingaben weg); später lädt die App ohnehin neu.
    if (!hadController || reloaded || holding || busy || parentOpen()) return;
    reloaded = true;
    reloadingForUpdate = true;
    location.reload();
  });
  navigator.serviceWorker.register("sw.js", { updateViaCache: "none" }).then((r) => r.update()).catch(() => {});
}
boot().catch((e) => { show("home"); $("#home-msg").hidden = false; $("#home-msg").textContent = "Server nicht erreichbar: " + e.message; });

// ------------------------------------------------------------------ KI-Anbieter (Eltern-Bereich)
// Auswahl "anbieter|modell", gruppiert nach Anbieter. Nur eingerichtete und freigegebene Anbieter.
function choiceName(pid, model) {
  const p = pv.providers.find((x) => x.id === pid);
  return p ? `${p.label} · ${(p.models[model] || model).split(" · ")[0]}` : model;
}
function fillChoice(sel, withDefault) {
  sel.innerHTML = "";
  if (withDefault) sel.add(new Option(`Standard (${pv.choice ? choiceName(pv.choice.provider, pv.choice.model) : "wie oben"})`, ""));
  for (const p of pv.providers) {
    if (!p.usable) continue;
    const g = document.createElement("optgroup");
    g.label = p.label + (p.untested ? " (ungetestet)" : "") + (p.warning ? " ⚠" : "");
    for (const [id, label] of Object.entries(p.models)) g.append(new Option(label, `${p.id}|${id}`));
    sel.append(g);
  }
  // Noch kein Anbieter nutzbar: Claude-Modelle trotzdem zeigen, damit die gespeicherte Wahl sichtbar bleibt
  if (!sel.querySelector("optgroup")) {
    const p = pv.providers.find((x) => x.id === "anthropic");
    for (const [id, label] of Object.entries(p.models)) sel.add(new Option(label, `anthropic|${id}`));
  }
}
// Grok und Ollama: vor dem Speichern einmal ausdrücklich bestätigen
function confirmChoice(value) {
  const p = pv?.providers.find((x) => x.id === (value || "").split("|")[0]);
  return !p?.warning || confirm(`${p.label}: ${p.warning}\n\nTrotzdem verwenden? Die Verantwortung liegt bei euch Eltern.`);
}
function choiceWarning(sel, box) {
  const pid = (sel.value || "").split("|")[0];
  const p = pv?.providers.find((x) => x.id === pid);
  const text = p?.warning ? "⚠ " + p.warning : p?.untested ? `${p.label} ist mit der Persona von LittleChat ungetestet. Antworten können weniger kindgerecht sein als bei Claude. Bitte die Gespräche anfangs mitlesen.` : "";
  box.hidden = !text;
  box.textContent = text;
}
$("#model").addEventListener("change", () => choiceWarning($("#model"), $("#model-warning")));
$("#kid-model").addEventListener("change", () => choiceWarning($("#kid-model"), $("#kid-model-warning")));

const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
const openProv = new Set();
function renderProviders() {
  const box = $("#providers");
  box.innerHTML = "";
  for (const p of pv.providers) {
    if (p.id === "anthropic") continue;
    const d = el("details", "prov" + (p.warning ? " prov-risky" : ""));
    d.open = openProv.has(p.id);
    d.ontoggle = () => (d.open ? openProv.add(p.id) : openProv.delete(p.id));
    const sum = el("summary");
    sum.append(el("b", "", p.label), " ", el("span", p.usable ? "ok" : "muted",
      p.usable ? "● wählbar · ungetestet" : p.configured ? "● eingerichtet · Bestätigung fehlt" : "nicht eingerichtet · ungetestet"));
    d.append(sum);
    if (p.warning) d.append(el("div", "prov-warn", "⚠ " + p.warning));
    const info = el("p", "hint", p.safety + " ");
    const a = el("a", "guide", "Anleitung: Schlüssel anlegen, Ausgabenlimit setzen, hier eintragen");
    a.href = "/anleitung/" + p.guide; a.target = "_blank"; a.rel = "noopener";
    info.append(a);
    d.append(info);

    // Schlüssel bzw. Adresse
    const row = el("div", "row");
    const inp = el("input");
    if (p.local) { inp.value = p.url || "http://127.0.0.1:11434"; inp.placeholder = "http://127.0.0.1:11434"; }
    else { inp.type = "password"; inp.autocomplete = "off"; inp.placeholder = p.configured ? `gespeichert …${p.last4} (neuen einfügen zum Ersetzen)` : p.keyHint; }
    const save = el("button", "", p.local ? "Verbinden & Modelle suchen" : "Prüfen & speichern");
    const del = el("button", "danger", p.local ? "Trennen" : "Entfernen");
    del.hidden = !p.configured || p.source === "env";
    const msg = el("p", "hint");
    if (p.source === "env") msg.textContent = "Schlüssel kommt aus der .env-Datei.";
    else row.append(inp, save, del);
    d.append(row, msg);
    save.onclick = async () => {
      msg.textContent = "Prüfe …";
      try { pv = await api(`/api/parent/providers/${p.id}`, { method: "PUT", body: p.local ? { url: inp.value } : { key: inp.value } }); openProv.add(p.id); renderParent(); }
      catch (e) { msg.textContent = e.message; }
    };
    del.onclick = async () => {
      if (!confirm(`${p.label} wirklich entfernen? Kinder, die ihn nutzen, wechseln auf den Standard.`)) return;
      pv = await api(`/api/parent/providers/${p.id}`, { method: "DELETE" });
      renderParent();
    };
    if (p.degraded) d.append(el("p", "hint warn", `Zusatzschutz vom Anbieter abgelehnt (${p.degraded.params.join(", ")}, ${fmtDate(p.degraded.at)}). Es gilt nur die Persona. Bitte den Kinderfragen-Test wiederholen.`));

    if (p.configured) {
      // Bewusste Bestätigung, bevor der Anbieter wählbar wird
      const lab = el("label", "check ack");
      const cb = el("input"); cb.type = "checkbox"; cb.checked = !!p.ack;
      lab.append(cb, ` Ich habe verstanden: ${p.label} ist mit ${APP} ungetestet. Antworten können weniger kindgerecht sein. Wir Eltern tragen die Verantwortung und behalten die Gespräche im Blick.`);
      d.append(lab);
      cb.onchange = async () => {
        if (!cb.checked && !confirm(`${p.label} wieder sperren? Kinder, die ihn nutzen, wechseln auf den Standard.`)) { cb.checked = true; return; }
        pv = await api(`/api/parent/providers/${p.id}/ack`, { method: "POST", body: { ack: cb.checked } });
        openProv.add(p.id); renderParent();
      };
      // Kinderfragen-Test
      d.append(el("h4", "", "Optional: Kinderfragen-Test"));
      d.append(el("p", "hint", "Nicht nötig, um den Anbieter zu nutzen. Stellt " + (p.check?.total || 11) + " heikle Kinderfragen (Feuer, Putzmittel, Pilze, Traurigkeit, Geheimnisse mit Erwachsenen, Adresse, Schimpfwörter, Horror …) mit der echten Persona für ein 7-jähriges Testkind. Die automatische Prüfung sucht nur nach Stichworten: Bitte jede Antwort selbst lesen." + (p.local ? " Lokal dauert das einige Minuten." : " Kostet wenige Cent.")));
      const trow = el("div", "row");
      const msel = el("select");
      for (const [id, label] of Object.entries(p.models)) msel.add(new Option(label, id));
      msel.value = p.check?.model || p.defaultModel;
      const run = el("button", "", "Jetzt testen");
      trow.append(msel, run);
      const tmsg = el("p", "hint");
      d.append(trow, tmsg);
      run.onclick = async () => {
        run.disabled = true; tmsg.textContent = "Test läuft …";
        try { pv = await api(`/api/parent/providers/${p.id}/check`, { method: "POST", body: { model: msel.value } }); openProv.add(p.id); renderParent(); }
        catch (e) { tmsg.textContent = e.message; run.disabled = false; }
      };
      if (p.check) {
        const c = p.check;
        d.append(el("p", c.passed === c.total ? "ok" : "bad", `${c.passed} von ${c.total} unauffällig · ${fmtDate(c.at)} · Modell ${c.model}${c.usd ? " · " + fmtUsd(c.usd) : ""}`));
        const det = el("details", "ck");
        det.append(el("summary", "", "Fragen und Antworten lesen"));
        for (const r of c.results) {
          const item = el("div", "ck-item" + (r.ok ? "" : " ck-bad"));
          item.append(el("div", "ck-q", `${r.ok ? "✓" : "✗"} ${r.topic}: „${r.q}“`));
          item.append(el("div", "ck-a", r.error ? "Fehler: " + r.error : r.answer || (r.refused ? "(vom Anbieter blockiert, das Kind hört: „Darüber kann ich leider nicht sprechen.“)" : "(leer)")));
          if (r.problems?.length) item.append(el("div", "hint warn", r.problems.join(" · ")));
          det.append(item);
        }
        if (c.passed < c.total) det.open = true;
        d.append(det);
      }
    }
    box.append(d);
  }
}

// ------------------------------------------------------------------ API-Schlüssel (Eltern-Bereich)
async function saveKey(input, out) {
  out.textContent = "Prüfe den Schlüssel …";
  try {
    pv = await api("/api/parent/apikey", { method: "PUT", body: { key: input.value } });
    input.value = "";
    out.textContent = "Gespeichert und funktioniert.";
    return true;
  } catch (e) { out.textContent = e.message; return false; }
}
$("#key-save").onclick = async () => { if (await saveKey($("#key-input"), $("#key-msg"))) renderParent(); };
$("#key-delete").onclick = async () => {
  if (!confirm("Schlüssel wirklich entfernen? Danach können die Kinder nicht mehr fragen.")) return;
  pv = await api("/api/parent/apikey", { method: "DELETE" });
  renderParent();
};

// ------------------------------------------------------------------ Sicherung
function downloadText(name, text) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  a.download = name;
  document.body.append(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
const recoveryText = (k) => `${APP} – Wiederherstellungsschlüssel\n\n${k}\n\nDamit lassen sich Datenbank und Backups entschlüsseln.\nSicher aufbewahren (z. B. Passwort-Manager oder ausgedruckt). Nicht weitergeben.\n`;
$("#recovery-show").onclick = async () => {
  const { key } = await api("/api/parent/recovery-key");
  $("#recovery-out").textContent = key;
  $("#recovery-out").hidden = false;
  $("#recovery-download").hidden = false;
  $("#recovery-download").onclick = () => downloadText(`${APP}-Wiederherstellungsschluessel.txt`, recoveryText(key));
};
$("#backup-now").onclick = async () => {
  const r = await api("/api/parent/backup", { method: "POST" });
  $("#backup-msg").textContent = "Sicherung erstellt: " + r.file;
};

// ------------------------------------------------------------------ Einrichtungs-Assistent
let wizStep = 1;
async function openWizard() {
  show("wizard");
  pv = await api("/api/parent");
  wizGo(pv.keySource === "env" ? 2 : 1);
}
function wizGo(n) {
  wizStep = n;
  if (n === 3) renderReach(pv.reach || {}, $("#wiz-reach"));
  document.querySelectorAll("#screen-wizard .step").forEach((el) => (el.hidden = Number(el.dataset.step) !== n));
  document.querySelectorAll("#wiz-dots span").forEach((el, i) => el.classList.toggle("on", i < n));
  if (n === 2) api("/api/parent/recovery-key").then(({ key }) => {
    $("#wiz-recovery").textContent = key;
    $("#wiz-recovery-download").onclick = () => downloadText(`${APP}-Wiederherstellungsschluessel.txt`, recoveryText(key));
  });
}
$("#wiz-key-save").onclick = async () => { if (await saveKey($("#wiz-key"), $("#wiz-key-msg"))) wizGo(2); };
$("#wiz-skip-key").onclick = () => wizGo(2);
$("#wiz-saved").onchange = () => ($("#wiz-next-2").disabled = !$("#wiz-saved").checked);
$("#wiz-next-2").onclick = () => wizGo(3);
$("#wiz-done").onclick = () => openParent();
