# Grok (xAI) einrichten

LittleChat kann die Grok-Modelle von xAI nutzen. Persona und Kinderschutz-Regeln wurden mit Claude entwickelt, darum ist Grok mit LittleChat **ungetestet**. Lies die Gespräche anfangs mit.

## Schlüssel anlegen

1. Öffne [console.x.ai](https://console.x.ai) und lege ein Konto an.
2. Guthaben aufladen (Prepaid), automatisches Aufladen aus. Wenn angeboten, ein Ausgabenlimit setzen.
3. Unter **API Keys** einen neuen Schlüssel erstellen. Er beginnt mit `xai-`. Wenn möglich nur Chat-Modelle erlauben.

## In LittleChat eintragen

1. Eltern-Bereich › **KI-Anbieter** › **Grok (xAI)**.
2. Schlüssel einfügen, **Prüfen & speichern** (kostenlos).
3. Häkchen setzen: **„Ich habe verstanden, ungetestet“**. Erst dann ist Grok wählbar.
4. Grok als Standard für alle Kinder oder nur für einzelne Kinder wählen.
5. Optional: **Jetzt testen** (Kinderfragen-Test) und die Antworten lesen.

Tipp: Teste Grok erst mit einem Kind und lies in den ersten Tagen die Gespräche mit (Eltern-Bereich › Gespräche).

> **Verantwortung:** Eltern tragen die Verantwortung für die Nutzung durch ihre Kinder und haften im Rahmen ihrer Aufsichtspflicht. Behaltet Themen und Gespräche im Blick. Nutzung auf eigene Gefahr.
