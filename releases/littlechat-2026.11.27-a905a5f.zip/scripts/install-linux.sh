#!/usr/bin/env bash
# LittleChat – Installation als systemd-Dienst (Raspberry Pi OS, Debian, Ubuntu).
# Aufruf im Programmordner: sudo ./scripts/install-linux.sh
# Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, nicht mit Anthropic verbunden.
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${PORT:-8787}"
[ "$(id -u)" -eq 0 ] || { echo "Bitte mit sudo starten."; exit 1; }

if ! command -v node >/dev/null || [ "$(node -v | sed 's/v\([0-9]*\).*/\1/')" -lt 20 ]; then
  echo "==> Installiere Node.js 22"
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi

id littlechat >/dev/null 2>&1 || useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin littlechat
cd "$APP_DIR"
sudo -u "$(stat -c %U "$APP_DIR")" npm ci --omit=dev --no-audit --no-fund
# Kostenlose, lokale Stimmen (Piper). Bei Fehler bleibt die Stimme des Tablets.
sudo -u "$(stat -c %U "$APP_DIR")" node scripts/setup-piper.mjs || echo "Hinweis: Piper nicht eingerichtet, später: node scripts/setup-piper.mjs"
[ -f .env ] || { cp .env.example .env; sed -i "s/^PORT=.*/PORT=$PORT/" .env; }
mkdir -p data logs
# Der Dienst spielt Updates selbst ein und braucht dafür Schreibrecht auf den Programmordner
chown -R littlechat:littlechat "$APP_DIR"
chmod 700 data; chmod 600 .env

cat > /etc/systemd/system/littlechat.service <<UNIT
[Unit]
Description=LittleChat (inoffiziell, nicht mit Anthropic verbunden)
After=network-online.target
Wants=network-online.target

[Service]
User=littlechat
WorkingDirectory=$APP_DIR
ExecStart=$(command -v node) scripts/supervisor.js
Restart=always
RestartSec=5
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=$APP_DIR
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now littlechat
sleep 3
echo
cat data/EINRICHTUNGSCODE.txt 2>/dev/null || journalctl -u littlechat -n 20 --no-pager
echo
echo "HTTPS für Tablets: Tailscale installieren (curl -fsSL https://tailscale.com/install.sh | sh), 'tailscale up', dann 'tailscale serve --bg $PORT'."
