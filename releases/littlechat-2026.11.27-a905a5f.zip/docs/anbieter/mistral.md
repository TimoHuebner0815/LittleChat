# Mistral (Europa) einrichten

Mistral ist ein französischer Anbieter. Die Daten bleiben in der EU, das ist gut für den Datenschutz. Die Modelle sind weniger auf Kinder abgestimmt als Claude, und mit LittleChat **ungetestet**. Lies die Gespräche anfangs mit. LittleChat schaltet zusätzlich Mistrals eigenen Sicherheits-Hinweis ein.

## Schlüssel anlegen

1. Öffne [console.mistral.ai](https://console.mistral.ai) und lege ein Konto an.
2. Einen Workspace anlegen und unter **Billing** einen bezahlten Tarif mit Guthaben oder Kreditkarte einrichten. Wenn angeboten, ein **monatliches Ausgabenlimit** setzen.
3. Unter **API Keys** einen neuen Schlüssel erstellen und kopieren.

## In LittleChat eintragen

1. Eltern-Bereich › **KI-Anbieter** › **Mistral (Europa)**.
2. Schlüssel einfügen, **Prüfen & speichern** (kostenlos).
3. Häkchen setzen: **„Ich habe verstanden, ungetestet“**. Erst dann ist Mistral wählbar.
4. Mistral als Standard für alle Kinder oder nur für einzelne Kinder wählen.
5. Optional: **Jetzt testen** (Kinderfragen-Test) und die Antworten lesen.

> Meldet der Eltern-Bereich „Zusatzschutz vom Anbieter abgelehnt“, hat Mistral den Sicherheits-Hinweis nicht angenommen. Dann gilt nur die Persona von LittleChat. Lies die Gespräche dann besonders aufmerksam mit.

> **Verantwortung:** Eltern tragen die Verantwortung für die Nutzung durch ihre Kinder und haften im Rahmen ihrer Aufsichtspflicht. Behaltet Themen und Gespräche im Blick. Nutzung auf eigene Gefahr.
