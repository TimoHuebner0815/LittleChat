﻿<#
  LittleChat entfernen (Windows). Am einfachsten: doppelt auf „LittleChat-entfernen.cmd“ klicken.
  Oder als Administrator: powershell -ExecutionPolicy Bypass -File .\scripts\uninstall-windows.ps1 [-DeleteData]

  Entfernt Autostart und HTTPS-Freigabe. Fragt, ob auch der Programmordner mit allen Daten
  (Kinder, Gespräche, Backups, Schlüssel) gelöscht werden soll. Standard: Daten bleiben.
  Node.js und Tailscale bleiben installiert (werden evtl. auch anders genutzt); entfernen über
  Windows-Einstellungen › Apps.
  Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, nicht mit Anthropic verbunden.
#>
param([switch]$DeleteData)
$TaskName = "LittleChat"
$AppDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Start-Process powershell -Verb RunAs -ArgumentList ("-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" + $(if ($DeleteData) { " -DeleteData" } else { "" }))
  exit
}

if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
  Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
  Write-Host "Autostart entfernt."
} else { Write-Host "Keine Aufgabe '$TaskName' gefunden." }
# Server-Prozesse aus diesem Ordner beenden (überleben das Stoppen der Aufgabe manchmal)
Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -and ($_.CommandLine.Contains($AppDir) -or $_.CommandLine -match "scripts.supervisor\.js") } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

$ts = "C:\Program Files\Tailscale\tailscale.exe"
if (Test-Path $ts) {
  $ans = Read-Host "HTTPS-Freigabe von LittleChat in Tailscale beenden? (J/n)"
  if ($ans -notmatch "^[nN]") { & $ts serve reset | Out-Host; Write-Host "HTTPS-Freigabe beendet. Tailscale selbst bleibt installiert." }
}

if (-not $DeleteData) {
  Write-Host "`nSollen auch alle Daten gelöscht werden? Das sind Kinder, Gespräche, Figuren, Backups und Schlüssel in:"
  Write-Host "  $AppDir" -ForegroundColor Yellow
  Write-Host "Das lässt sich NICHT rückgängig machen. Wer später neu installieren will, wählt Nein."
  $DeleteData = (Read-Host "Zum Löschen LÖSCHEN eintippen, sonst Enter") -ceq "LÖSCHEN"
}
if ($DeleteData) {
  Set-Location $env:SystemRoot
  # Läuft dieses Skript selbst aus dem Ordner, löscht ein kurzer Nachlauf den Rest
  Start-Process cmd.exe -WindowStyle Hidden -ArgumentList "/c timeout /t 3 >nul & rmdir /s /q `"$AppDir`""
  Write-Host "LittleChat und alle Daten werden gelöscht."
} else {
  Write-Host "`nLittleChat startet nicht mehr. Der Ordner $AppDir mit deinen Daten bleibt erhalten."
  Write-Host "Neu einrichten: LittleChat-installieren.cmd im Ordner doppelt anklicken."
}
Read-Host "`nZum Schließen Enter drücken" | Out-Null
