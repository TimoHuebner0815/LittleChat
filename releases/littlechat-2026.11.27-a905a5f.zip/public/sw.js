// Speichert nur die App-Hülle. API-Aufrufe gehen immer direkt an den Server und werden nie zwischengespeichert.
const CACHE = "littlechat-v7";
const SHELL = ["./", "index.html", "style.css", "app.js", "manifest.webmanifest", "icons/icon.svg", "icons/icon-192.png", "icons/apple-touch-icon.png"];
self.addEventListener("install", (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL.map((u) => new Request(u, { cache: "reload" }))))); self.skipWaiting(); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin || url.pathname.includes("/api/")) return;
  // Netz zuerst (damit Updates sofort ankommen), Cache nur als Rückfall
  // Start aus dem Home-Bildschirm (?app=1) liefert dieselbe Seite wie "./"
  // cache: "no-cache" umgeht den HTTP-Cache des Browsers, damit nach einem Update nie alter Code läuft
  const req = new Request(url.pathname.endsWith("/") && url.search ? url.pathname : e.request.url, { cache: "no-cache" });
  e.respondWith(fetch(req).then((r) => {
    const copy = r.clone();
    if (r.ok) caches.open(CACHE).then((c) => c.put(req, copy));
    return r;
  }).catch(() => caches.match(req)));
});
