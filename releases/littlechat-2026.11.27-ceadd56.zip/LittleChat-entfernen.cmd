@echo off
rem LittleChat entfernen: doppelt anklicken. Fragt, ob die Daten bleiben sollen.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\uninstall-windows.ps1"
