﻿<#
  LittleChat – Installation unter Windows 10/11
  Aufruf (im Programmordner, PowerShell als Administrator):
    powershell -ExecutionPolicy Bypass -File .\scripts\install-windows.ps1

  Was passiert:
    1. Node.js LTS wird installiert, falls nötig (über winget).
    2. Abhängigkeiten werden installiert (npm ci).
    3. Ein Windows-Dienst (geplante Aufgabe "LittleChat") startet den Server bei jedem Systemstart automatisch,
       über scripts\supervisor.js mit Auto-Update (Deploy-Schlüssel: scripts\enable-autoupdate-windows.ps1).
    4. Der Datenordner wird so geschützt, dass nur SYSTEM und Administratoren ihn lesen können.
    5. Optional: Tailscale für HTTPS im Heimnetz (nötig, damit Tablets das Mikrofon nutzen dürfen).
    6. Der Einrichtungscode wird angezeigt und der Browser geöffnet.
  Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, nicht mit Anthropic verbunden.
#>
param(
  [switch]$NoTailscale,
  [int]$Port = 8787
)
$ErrorActionPreference = "Stop"
$TaskName = "LittleChat"
$AppDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$DataDir = Join-Path $AppDir "data"

function Say($t) { Write-Host "`n==> $t" -ForegroundColor Cyan }
function Refresh-Path { $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User") }

# Als Administrator neu starten, falls nötig
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "Starte als Administrator neu ..."
  $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Port $Port" + $(if ($NoTailscale) { " -NoTailscale" } else { "" })
  Start-Process powershell -Verb RunAs -ArgumentList $argList
  exit
}

Say "Prüfe Node.js"
Refresh-Path
$node = Get-Command node -ErrorAction SilentlyContinue
$needNode = $true
if ($node) { $v = (& node -v) -replace "v",""; if ([int]($v.Split(".")[0]) -ge 20) { $needNode = $false } }
if ($needNode) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw "winget fehlt. Bitte Node.js 20+ von https://nodejs.org installieren und das Skript erneut starten." }
  Say "Installiere Node.js LTS"
  winget install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements
  Refresh-Path
}
$NodeExe = (Get-Command node).Source
Write-Host "Node: $(& node -v) ($NodeExe)"

Say "Installiere Abhängigkeiten"
Push-Location $AppDir
try { & npm ci --omit=dev --no-audit --no-fund; if ($LASTEXITCODE -ne 0) { throw "npm ci fehlgeschlagen" } } finally { Pop-Location }

Say "Kostenlose Stimmen (Piper)"
Write-Host "Piper erzeugt die Stimme auf diesem Rechner: kostenlos, privat und auf jedem Tablet gleich (ca. 200 MB)."
if (-not (Test-Path "$env:SystemRoot\System32\vcruntime140_1.dll")) {
  Write-Host "Installiere die Microsoft Visual-C++-Laufzeit (braucht Piper) ..."
  winget install --id Microsoft.VCRedist.2015+.x64 -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
}
Push-Location $AppDir
try { & node scripts\setup-piper.mjs; if ($LASTEXITCODE -ne 0) { Write-Warning "Piper konnte nicht eingerichtet werden. LittleChat nutzt dann die Stimme des Tablets. Später nachholen: node scripts\setup-piper.mjs" } } finally { Pop-Location }

Say "Konfiguration"
$envFile = Join-Path $AppDir ".env"
if (-not (Test-Path $envFile)) {
  Copy-Item (Join-Path $AppDir ".env.example") $envFile
  (Get-Content $envFile) -replace "^PORT=.*", "PORT=$Port" | Set-Content $envFile -Encoding UTF8
  Write-Host ".env angelegt. Den API-Schlüssel trägst du später bequem im Browser-Assistenten ein."
}

Say "Datenordner schützen"
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
& icacls $DataDir /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
& icacls $envFile /inheritance:r /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" | Out-Null

Say "Autostart einrichten (geplante Aufgabe '$TaskName')"
# Der Aufpasser startet den Server, startet ihn nach Abstürzen neu und spielt freigegebene Updates ein
$cmd = "/c cd /d `"$AppDir`" && `"$NodeExe`" scripts\supervisor.js >> `"$DataDir\server.log`" 2>&1"
$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument $cmd -WorkingDirectory $AppDir
$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
  -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
$taskPrincipal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
  Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $taskPrincipal `
  -Description "LittleChat-Server (inoffiziell, nicht mit Anthropic verbunden)" | Out-Null
Start-ScheduledTask -TaskName $TaskName

Say "Warte auf den Server"
$ok = $false
for ($i = 0; $i -lt 30; $i++) {
  Start-Sleep -Seconds 1
  try { Invoke-WebRequest -UseBasicParsing "http://127.0.0.1:$Port/api/state" -TimeoutSec 2 | Out-Null; $ok = $true; break } catch {}
}
if (-not $ok) { Write-Warning "Server antwortet nicht. Log: $DataDir\server.log"; Get-Content "$DataDir\server.log" -Tail 20 -ErrorAction SilentlyContinue; exit 1 }
Write-Host "Server läuft auf http://127.0.0.1:$Port" -ForegroundColor Green

$url = "http://localhost:$Port"
if (-not $NoTailscale) {
  Say "HTTPS im Heimnetz mit Tailscale"
  Write-Host "Tablets dürfen das Mikrofon nur über HTTPS nutzen. Tailscale ist für Privatleute kostenlos und öffnet nichts ins Internet."
  $answer = Read-Host "Tailscale jetzt einrichten? (J/n)"
  if ($answer -notmatch "^[nN]") {
    $ts = "C:\Program Files\Tailscale\tailscale.exe"
    if (-not (Test-Path $ts)) {
      winget install --id Tailscale.Tailscale -e --silent --accept-package-agreements --accept-source-agreements
      Start-Sleep -Seconds 5
    }
    Write-Host "Melde dich im Browserfenster bei Tailscale an (falls es sich öffnet) ..."
    & $ts up | Out-Host
    Write-Host "Falls Tailscale nach 'HTTPS certificates' fragt: den angezeigten Link öffnen und HTTPS einschalten."
    & $ts serve --bg $Port | Out-Host
    try {
      $dns = ((& $ts status --json) | ConvertFrom-Json).Self.DNSName.TrimEnd(".")
      if ($dns) { $url = "https://$dns" }
    } catch {}
    Write-Host "Installiere Tailscale auch auf den Tablets (App-Store) und melde dich mit demselben Konto an." -ForegroundColor Yellow
  }
}

$codeFile = Join-Path $DataDir "EINRICHTUNGSCODE.txt"
if (Test-Path $codeFile) {
  Say "Einrichtungscode"
  Get-Content $codeFile | Write-Host -ForegroundColor Green
}
Say "Fertig. Öffne $url und folge dem Assistenten."
Start-Process $url
