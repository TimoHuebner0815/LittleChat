#!/usr/bin/env node
// Lädt Piper (lokale, kostenlose Sprachausgabe) und deutsche Stimmen nach ./piper herunter.
// Läuft unter Windows, Linux und macOS; braucht nur Node 20+ und "tar" (in Windows 10/11 enthalten).
//
//   node scripts/setup-piper.mjs                       Standard-Stimmen (thorsten-high, kerstin-low)
//   node scripts/setup-piper.mjs --voices=all          alle frei lizenzierten Stimmen aus der Liste unten
//   node scripts/setup-piper.mjs --voices=thorsten-medium,kerstin-low
//
// Piper: https://github.com/rhasspy/piper (MIT; enthält espeak-ng, GPL-3.0). Wird nicht mit LittleChat
// verteilt, sondern hier direkt vom Original heruntergeladen und per SHA-256 geprüft.
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const DIR = process.env.LC_PIPER_DIR || path.join(ROOT, "piper");
const RELEASE = "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/";
const BUILDS = {
  "win32-x64": ["piper_windows_amd64.zip", "f3c58906402b24f3a96d92145f58acba6d86c9b5db896d207f78dc80811efcea"],
  "linux-x64": ["piper_linux_x86_64.tar.gz", "a50cb45f355b7af1f6d758c1b360717877ba0a398cc8cbe6d2a7a3a26e225992"],
  "linux-arm64": ["piper_linux_aarch64.tar.gz", "fea0fd2d87c54dbc7078d0f878289f404bd4d6eea6e7444a77835d1537ab88eb"],
  "linux-arm": ["piper_linux_armv7l.tar.gz", "c6946fcd57c705ed1d4666ea880f80ba0bbbd14de62ecbdd13460baf3bac8e37"],
  "darwin-arm64": ["piper_macos_aarch64.tar.gz", "6b1eb03b3735946cb35216e063e7eebcc33a6bbf5dd96ec0217959bf1cdcb0cc"],
  "darwin-x64": ["piper_macos_x64.tar.gz", "ced85c0a3df13945b1e623b878a48fdc2854d5c485b4b67f62857cf551deaf8b"],
};
// Nur Stimmen, deren MODEL_CARD eine freie Lizenz nennt (Stand 11/2026). Nicht enthalten:
// pavoque (CC BY-NC-SA, nicht kommerziell), eva_k/ramona/karlsson (Lizenz in der Karte nicht angegeben).
const HF = "https://huggingface.co/rhasspy/piper-voices/resolve/main/de/de_DE/";
export const VOICES = {
  "thorsten-high": { file: "de_DE-thorsten-high", path: "thorsten/high/", license: "CC0", label: "Thorsten · männlich · beste Qualität" },
  "thorsten-medium": { file: "de_DE-thorsten-medium", path: "thorsten/medium/", license: "CC0", label: "Thorsten · männlich · schneller" },
  "kerstin-low": { file: "de_DE-kerstin-low", path: "kerstin/low/", license: "CC0", label: "Kerstin · weiblich" },
  "thorsten_emotional-medium": { file: "de_DE-thorsten_emotional-medium", path: "thorsten_emotional/medium/", license: "CC0", label: "Thorsten · mit Gefühl (fröhlich, flüsternd …)" },
  "mls-medium": { file: "de_DE-mls-medium", path: "mls/medium/", license: "CC BY 4.0 (Namensnennung: Multilingual LibriSpeech, openslr.org/94)", label: "MLS · viele Sprecherinnen und Sprecher" },
};
const DEFAULT_VOICES = ["thorsten-high", "kerstin-low"];

async function download(url, dest, sha) {
  const r = await fetch(url, { redirect: "follow" });
  if (!r.ok) throw new Error(`${url}: HTTP ${r.status}`);
  const buf = Buffer.from(await r.arrayBuffer());
  if (sha) {
    const got = crypto.createHash("sha256").update(buf).digest("hex");
    if (got !== sha) throw new Error(`Prüfsumme falsch für ${path.basename(dest)} (erwartet ${sha}, bekommen ${got})`);
  }
  await fsp.writeFile(dest + ".part", buf);
  await fsp.rename(dest + ".part", dest);
  return buf.length;
}

async function main() {
  const arg = process.argv.find((a) => a.startsWith("--voices="))?.split("=")[1];
  const wanted = !arg ? DEFAULT_VOICES : arg === "all" ? Object.keys(VOICES) : arg.split(",").map((s) => s.trim()).filter(Boolean);
  for (const v of wanted) if (!VOICES[v]) throw new Error(`Unbekannte Stimme "${v}". Möglich: ${Object.keys(VOICES).join(", ")}`);

  await fsp.mkdir(path.join(DIR, "voices"), { recursive: true });
  const exe = path.join(DIR, "piper", process.platform === "win32" ? "piper.exe" : "piper");
  if (!fs.existsSync(exe)) {
    const build = BUILDS[`${process.platform}-${process.arch}`];
    if (!build) throw new Error(`Für ${process.platform}-${process.arch} gibt es kein fertiges Piper. Siehe https://github.com/rhasspy/piper`);
    const [asset, sha] = build;
    const archive = path.join(DIR, asset);
    console.log(`Lade Piper (${asset}) …`);
    await download(RELEASE + asset, archive, sha);
    execFileSync("tar", ["-xf", archive, "-C", DIR], { stdio: "inherit" });
    await fsp.rm(archive, { force: true });
    if (!fs.existsSync(exe)) throw new Error("Piper wurde entpackt, aber " + exe + " fehlt.");
  } else console.log("Piper ist schon da.");

  for (const id of wanted) {
    const v = VOICES[id];
    const onnx = path.join(DIR, "voices", v.file + ".onnx");
    if (fs.existsSync(onnx) && fs.existsSync(onnx + ".json")) { console.log(`Stimme ${id} ist schon da.`); continue; }
    console.log(`Lade Stimme ${id} (${v.license}) …`);
    await download(HF + v.path + v.file + ".onnx.json", onnx + ".json");
    const size = await download(HF + v.path + v.file + ".onnx", onnx);
    console.log(`  ${(size / 1e6).toFixed(0)} MB`);
  }
  // Kurzer Funktionstest
  const out = path.join(DIR, "test.wav");
  const first = path.join(DIR, "voices", VOICES[wanted[0]].file + ".onnx");
  try {
    execFileSync(exe, ["--model", first, "--output_file", out, "--quiet"], { input: "Hallo, ich bin bereit.", stdio: ["pipe", "ignore", "inherit"] });
  } catch (e) {
    // 0xC0000135 = DLL fehlt: unter Windows fast immer die Visual-C++-Laufzeit
    if (process.platform === "win32" && (e.status === 3221225781 || e.status === -1073741515))
      throw new Error("Piper braucht die Microsoft Visual-C++-Laufzeit. Installieren mit:\n  winget install --id Microsoft.VCRedist.2015+.x64 -e\nund dieses Skript danach nochmal starten.");
    throw e;
  }
  const ok = fs.existsSync(out) && fs.statSync(out).size > 1000;
  await fsp.rm(out, { force: true });
  if (!ok) throw new Error("Piper hat keine Audiodatei erzeugt.");
  console.log("Piper funktioniert. Im Eltern-Bereich unter „Stimme“ ist es jetzt auswählbar.");
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((e) => { console.error("Piper-Einrichtung fehlgeschlagen: " + e.message); process.exit(1); });
}
