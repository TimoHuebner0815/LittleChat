# Bestandteile Dritter

LittleChat selbst ist urheberrechtlich geschützt (siehe [LICENSE](LICENSE)). Folgende fremde Bestandteile stehen unter ihren eigenen Lizenzen:

| Bestandteil | Lizenz | Wie eingebunden |
|---|---|---|
| [@anthropic-ai/sdk](https://github.com/anthropics/anthropic-sdk-typescript) und seine Abhängigkeiten | MIT bzw. Apache-2.0 (siehe `package-lock.json`) | npm-Abhängigkeit |
| [Piper](https://github.com/rhasspy/piper) | MIT, enthält espeak-ng (GPL-3.0) | wird nicht mitgeliefert; `scripts/setup-piper.mjs` lädt es vom Original herunter |
| Piper-Stimmen Thorsten, Kerstin, Thorsten emotional | CC0 | Download vom Original (Hugging Face, rhasspy/piper-voices) |
| Piper-Stimme MLS (optional) | CC BY 4.0, Namensnennung: Multilingual LibriSpeech, openslr.org/94 | Download vom Original |
| [Node.js](https://nodejs.org) | MIT (enthält weitere freie Lizenzen) | wird nicht mitgeliefert; der Installer lädt es per winget bzw. von nodejs.org (Prüfsumme geprüft) |
| Microsoft Visual C++ Redistributable (nur Windows, für Piper) | Microsoft-Software-Lizenzbedingungen | wird nicht mitgeliefert; Installation per winget bzw. von Microsoft |
| [Tailscale](https://tailscale.com) (optional) | Client teils BSD-3-Clause, Nutzung nach den Tailscale-Bedingungen | wird nicht mitgeliefert; Installation per winget, pkgs.tailscale.com bzw. tailscale.com/install.sh |
