# Altersstufen

Jede Datei hier beschreibt, wie die KI mit einer Altersgruppe spricht: Ton, Wortschatz, Länge und Tiefe der
Antworten, Beispiele und Spiele. Die App setzt den passenden Block an der Stelle `{{AGE_GUIDE}}` in die
Persönlichkeit (`kid_persona.md`) ein. Fehlt der Platzhalter in einer eigenen Persönlichkeit, hängt die App den
Block automatisch an.

Welche Stufe gilt, ergibt sich nur aus dem Geburtsdatum, das die Eltern hinter dem Passwort eintragen, oder aus
einer Stufe, die die Eltern beim Kind fest gewählt haben. Was das Kind im Gespräch über sein Alter sagt, ändert
die Stufe nie. Die Kinderschutz-Regeln (`kid_safety.md`) gelten für jede Stufe und gehen immer vor.

Kopf jeder Datei:

```
---
name: 6 bis 9 Jahre        Anzeige im Eltern-Bereich
von: 6                     ab diesem Alter (Jahre, einschließlich)
bis: 9                     bis zu diesem Alter (einschließlich); leer = nach oben offen
---
```

Der Dateiname (ohne `.md`) ist die feste Kennung; nicht umbenennen, sonst verlieren fest gewählte Stufen ihre
Zuordnung. Eltern können jeden Block im Eltern-Bereich anpassen; Updates ändern eigene Fassungen nie.
