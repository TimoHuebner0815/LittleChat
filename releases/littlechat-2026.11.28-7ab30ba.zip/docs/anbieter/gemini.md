# Gemini (Google) einrichten

LittleChat kann Googles Gemini-Modelle nutzen. Die Schutzfilter von Google laufen dabei auf der strengsten Stufe. Persona und Kinderschutz-Regeln wurden mit Claude entwickelt, darum ist Gemini mit LittleChat **ungetestet**. Lies die Gespräche anfangs mit.

> **Wichtig:** Im kostenlosen Tarif darf Google Eingaben zur Verbesserung seiner Produkte nutzen und Menschen können sie lesen. Für Kinder-Gespräche nur mit **aktivierter Abrechnung** (bezahlter Tarif) verwenden.

## Schlüssel anlegen

1. Öffne [aistudio.google.com](https://aistudio.google.com) und melde dich mit einem Google-Konto an.
2. Links **Get API key** › **API-Schlüssel erstellen**. Der Schlüssel beginnt meist mit `AIza`.
3. Beim Schlüssel **Abrechnung einrichten** (verknüpft ein Google-Cloud-Rechnungskonto).
4. Ausgaben begrenzen: In der [Google Cloud Console](https://console.cloud.google.com) unter **Abrechnung › Budgets & Benachrichtigungen** ein Budget anlegen, z. B. 10 Dollar.

> Google-Budgets **warnen** nur per E-Mail, sie stoppen nicht hart. Ein hartes Limit setzt du in der Console unter **APIs und Dienste › Kontingente** (Anfragen bzw. Zeichen pro Minute oder Tag niedrig stellen).

## In LittleChat eintragen

1. Eltern-Bereich › **KI-Anbieter** › **Gemini (Google)**.
2. Schlüssel einfügen, **Prüfen & speichern** (kostenlos, fragt nur die Modelle ab).
3. Häkchen setzen: **„Ich habe verstanden, ungetestet“**. Erst dann ist Gemini wählbar.
4. Gemini als Standard für alle Kinder oder nur für einzelne Kinder wählen.
5. Optional: **Jetzt testen** (Kinderfragen-Test) und die Antworten lesen.

Was gesendet wird: der Text der Frage, die Persona mit Vorname und Alter des Kindes und der Gesprächsverlauf.

> **Verantwortung:** Eltern tragen die Verantwortung für die Nutzung durch ihre Kinder und haften im Rahmen ihrer Aufsichtspflicht. Behaltet Themen und Gespräche im Blick. Nutzung auf eigene Gefahr.
