@echo off
rem LittleChat installieren: doppelt anklicken. Fragt nach Administratorrechten.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-windows.ps1"
