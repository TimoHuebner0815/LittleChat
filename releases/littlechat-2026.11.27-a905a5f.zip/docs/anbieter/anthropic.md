# Claude (Anthropic) einrichten

Claude ist der Standard in LittleChat. Persona, Gesprächsmodi und Kinderschutz-Regeln wurden mit Claude entwickelt und getestet. Ein Claude-Abo (Pro/Max) funktioniert hier nicht, du brauchst einen API-Schlüssel.

## Schlüssel anlegen

1. Öffne [console.anthropic.com](https://console.anthropic.com) und lege ein Konto an.
2. Unter **Billing** Guthaben aufladen, z. B. 5 bis 10 Dollar. **Automatisches Aufladen ausgeschaltet lassen.** So kann nie mehr verbraucht werden, als aufgeladen ist.
3. Unter **Settings › Workspaces** einen Workspace „Kinder“ anlegen und dort ein **monatliches Ausgabenlimit** setzen, z. B. 10 Dollar.
4. Im Workspace „Kinder“ unter **API Keys** einen neuen Schlüssel erstellen. Er beginnt mit `sk-ant-`.

## In LittleChat eintragen

1. Eltern-Bereich › **KI-Anbieter** › Feld „Claude-Verbindung“.
2. Schlüssel einfügen, **Prüfen & speichern**.
3. Unter **Standard für alle Kinder** das Modell wählen. Haiku 5.5 reicht für Kinderfragen und ist am günstigsten.

> Der Schlüssel liegt verschlüsselt nur auf deinem Server und wird nie an ein Tablet geschickt.

> **Verantwortung:** Eltern tragen die Verantwortung für die Nutzung durch ihre Kinder und haften im Rahmen ihrer Aufsichtspflicht. Behaltet Themen und Gespräche im Blick. Nutzung auf eigene Gefahr.
