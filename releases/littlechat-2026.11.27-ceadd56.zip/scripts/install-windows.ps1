﻿<#
  LittleChat – Installation unter Windows 10/11
  Am einfachsten: im entpackten Ordner doppelt auf „LittleChat-installieren.cmd“ klicken.
  Oder in einer PowerShell:
    powershell -ExecutionPolicy Bypass -File .\scripts\install-windows.ps1

  Was passiert (alles, was LittleChat braucht, wird vom jeweiligen Original geladen und eingerichtet):
    1. Liegt der Ordner in „Downloads“, auf dem Desktop oder in OneDrive, wird LittleChat nach C:\LittleChat kopiert.
    2. Node.js LTS (über winget, sonst direkt von nodejs.org mit Prüfsumme).
    3. Abhängigkeiten (npm ci) und die kostenlosen Piper-Stimmen samt Visual-C++-Laufzeit.
    4. Autostart als geplante Aufgabe "LittleChat" (SYSTEM) mit dem Aufpasser scripts\supervisor.js:
       Neustart nach Absturz und automatische, signierte Updates aus dem Repo LittleChat.
    5. Datenordner und .env so geschützt, dass nur SYSTEM und Administratoren sie lesen können.
    6. Auf Wunsch: Tailscale für HTTPS (nötig, damit Tablets das Mikrofon nutzen dürfen), auch ohne Anmeldung am Rechner.
    7. Auf Wunsch: Ruhezustand am Netzteil abschalten, damit LittleChat erreichbar bleibt.
    8. Einrichtungscode anzeigen und den Browser öffnen.
  Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, nicht mit Anthropic verbunden.
#>
param(
  [switch]$NoTailscale,
  [int]$Port = 8787,
  [string]$InstallDir = "C:\LittleChat",
  [switch]$Quiet # keine Rückfragen (Tailscale und Ruhezustand: ja), Fenster schließt sich am Ende
)
$ErrorActionPreference = "Stop"
$TaskName = "LittleChat"
$AppDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$DataDir = Join-Path $AppDir "data"
$Summary = [ordered]@{}

function Say($t) { Write-Host "`n==> $t" -ForegroundColor Cyan }
function Ask($q) { if ($Quiet) { return $true }; return ((Read-Host "$q (J/n)") -notmatch "^[nN]") }
function Done { if (-not $Quiet) { Read-Host "`nZum Schließen Enter drücken" | Out-Null } }
function Refresh-Path { $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User") }
$Arch = if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") { "arm64" } else { "x64" }
$HasWinget = [bool](Get-Command winget -ErrorAction SilentlyContinue)
function Winget($id) {
  if (-not $HasWinget) { return $false }
  & winget install --id $id -e --silent --accept-package-agreements --accept-source-agreements | Out-Host
  return ($LASTEXITCODE -eq 0 -or $LASTEXITCODE -eq -1978335189) # 0x8A15002B: bereits installiert
}
function Download($url, $file) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $ProgressPreference = "SilentlyContinue"
  Invoke-WebRequest -UseBasicParsing $url -OutFile $file
}
function Run-Msi($file) {
  $p = Start-Process msiexec.exe -ArgumentList "/i `"$file`" /qn /norestart" -Wait -PassThru
  if ($p.ExitCode -notin 0, 3010) { throw "Installation von $(Split-Path $file -Leaf) fehlgeschlagen (Code $($p.ExitCode))" }
}

# Als Administrator neu starten, falls nötig
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "Starte als Administrator neu ..."
  $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Port $Port -InstallDir `"$InstallDir`"" +
    $(if ($NoTailscale) { " -NoTailscale" } else { "" }) + $(if ($Quiet) { " -Quiet" } else { "" })
  Start-Process powershell -Verb RunAs -ArgumentList $argList
  exit
}

try {
  # Aus dem Internet geladene Dateien sind markiert; ohne Freigabe fragt Windows bei jedem Skript nach
  Get-ChildItem $AppDir -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue

  # Downloads, Desktop und OneDrive sind kein guter Ort für einen Dienst: dorthin kopieren, wo er dauerhaft bleibt
  $userDirs = @($env:USERPROFILE, $env:OneDrive, $env:OneDriveConsumer) | Where-Object { $_ }
  $inUserDir = $userDirs | Where-Object { $AppDir.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) }
  $target = [IO.Path]::GetFullPath($InstallDir)
  if ($inUserDir -and -not $AppDir.Equals($target, [StringComparison]::OrdinalIgnoreCase)) {
    if (Test-Path (Join-Path $target "server.js")) {
      Say "LittleChat ist schon in $target installiert. Ich richte es dort neu ein (Daten bleiben erhalten)."
    } else {
      Say "Kopiere LittleChat nach $target"
      New-Item -ItemType Directory -Force -Path $target | Out-Null
      Copy-Item -Path (Join-Path $AppDir "*") -Destination $target -Recurse -Force
    }
    $next = Join-Path $target "scripts\install-windows.ps1"
    & $next -Port $Port -InstallDir $InstallDir -NoTailscale:$NoTailscale -Quiet:$Quiet
    exit $LASTEXITCODE
  }

  Say "Prüfe Node.js"
  Refresh-Path
  $needNode = $true
  if (Get-Command node -ErrorAction SilentlyContinue) { $v = (& node -v) -replace "v",""; if ([int]($v.Split(".")[0]) -ge 20) { $needNode = $false } }
  if ($needNode) {
    Say "Installiere Node.js LTS"
    if (-not (Winget "OpenJS.NodeJS.LTS")) {
      # Ohne winget (ältere Windows-10-Versionen): offizielles Installationspaket, Prüfsumme von nodejs.org
      $rel = (Invoke-RestMethod "https://nodejs.org/dist/index.json") | Where-Object { $_.lts -and $_.files -contains "win-$Arch-msi" } | Select-Object -First 1
      if (-not $rel) { throw "Keine passende Node.js-Version gefunden. Bitte Node.js LTS von https://nodejs.org installieren und erneut starten." }
      $name = "node-$($rel.version)-$Arch.msi"
      $msi = Join-Path $env:TEMP $name
      Download "https://nodejs.org/dist/$($rel.version)/$name" $msi
      $sums = (Invoke-WebRequest -UseBasicParsing "https://nodejs.org/dist/$($rel.version)/SHASUMS256.txt").Content
      $want = ($sums -split "`n" | Where-Object { $_ -match "\s$([regex]::Escape($name))$" }) -replace "\s.*$", ""
      if (-not $want -or (Get-FileHash $msi -Algorithm SHA256).Hash -ne $want.Trim().ToUpper()) { throw "Prüfsumme von $name stimmt nicht. Abgebrochen." }
      Run-Msi $msi
    }
    Refresh-Path
  }
  $NodeExe = (Get-Command node).Source
  Write-Host "Node: $(& node -v) ($NodeExe)"
  $Summary["Node.js"] = (& node -v)

  Say "Installiere Abhängigkeiten"
  Push-Location $AppDir
  try { & npm ci --omit=dev --no-audit --no-fund; if ($LASTEXITCODE -ne 0) { throw "npm ci fehlgeschlagen" } } finally { Pop-Location }

  Say "Kostenlose Stimmen (Piper)"
  Write-Host "Piper erzeugt die Stimme auf diesem Rechner: kostenlos, privat und auf jedem Tablet gleich (ca. 200 MB)."
  if (-not (Test-Path "$env:SystemRoot\System32\vcruntime140_1.dll")) {
    Write-Host "Installiere die Microsoft Visual-C++-Laufzeit (braucht Piper) ..."
    if (-not (Winget "Microsoft.VCRedist.2015+.x64")) {
      $vc = Join-Path $env:TEMP "vc_redist.x64.exe"
      try { Download "https://aka.ms/vs/17/release/vc_redist.x64.exe" $vc; Start-Process $vc -ArgumentList "/install /quiet /norestart" -Wait } catch { Write-Warning "Visual-C++-Laufzeit: $($_.Exception.Message)" }
    }
  }
  Push-Location $AppDir
  try {
    & node scripts\setup-piper.mjs
    if ($LASTEXITCODE -eq 0) { $Summary["Stimme"] = "Piper (kostenlos, lokal)" }
    else { $Summary["Stimme"] = "Stimme des Tablets (Piper fehlt, später: node scripts\setup-piper.mjs)"; Write-Warning "Piper konnte nicht eingerichtet werden. LittleChat nutzt dann die Stimme des Tablets." }
  } finally { Pop-Location }

  Say "Konfiguration"
  $envFile = Join-Path $AppDir ".env"
  if (-not (Test-Path $envFile)) {
    Copy-Item (Join-Path $AppDir ".env.example") $envFile
    (Get-Content $envFile) -replace "^PORT=.*", "PORT=$Port" | Set-Content $envFile -Encoding UTF8
    Write-Host ".env angelegt. Den API-Schlüssel trägst du gleich bequem im Browser-Assistenten ein."
  } else {
    $m = Select-String -Path $envFile -Pattern "^\s*PORT\s*=\s*(\d+)" | Select-Object -First 1
    if ($m) { $Port = [int]$m.Matches[0].Groups[1].Value }
  }

  Say "Datenordner schützen"
  New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
  & icacls $DataDir /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
  & icacls $envFile /inheritance:r /grant:r "*S-1-5-18:F" "*S-1-5-32-544:F" | Out-Null

  Say "Autostart und automatische Updates einrichten (geplante Aufgabe '$TaskName')"
  # Der Aufpasser startet den Server, startet ihn nach Abstürzen neu und spielt signierte Updates ein
  $cmd = "/c cd /d `"$AppDir`" && `"$NodeExe`" scripts\supervisor.js >> `"$DataDir\server.log`" 2>&1"
  $action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument $cmd -WorkingDirectory $AppDir
  $trigger = New-ScheduledTaskTrigger -AtStartup
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
  $taskPrincipal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
  if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
  }
  # Falls ein alter Server den Port noch hält (Kindprozess überlebt das Stoppen der Aufgabe)
  Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    $pr = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
    if ($pr -and $pr.ProcessName -eq "node") { Stop-Process -Id $pr.Id -Force -ErrorAction SilentlyContinue }
  }
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $taskPrincipal `
    -Description "LittleChat-Server mit automatischen Updates (inoffiziell, nicht mit Anthropic verbunden)" | Out-Null
  Start-ScheduledTask -TaskName $TaskName

  Say "Warte auf den Server"
  $ok = $false
  for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Seconds 1
    try { Invoke-WebRequest -UseBasicParsing "http://127.0.0.1:$Port/api/state" -TimeoutSec 2 | Out-Null; $ok = $true; break } catch {}
  }
  if (-not $ok) { Get-Content "$DataDir\server.log" -Tail 20 -ErrorAction SilentlyContinue; throw "Der Server antwortet nicht. Protokoll: $DataDir\server.log" }
  Write-Host "Server läuft auf http://127.0.0.1:$Port" -ForegroundColor Green
  $Summary["Autostart"] = "an (startet mit Windows, auch ohne Anmeldung)"
  $Summary["Updates"] = "automatisch, signiert, mit Rückfall auf die alte Version"

  $url = "http://localhost:$Port"
  $Summary["Tablets (HTTPS)"] = "nicht eingerichtet (später erneut installieren oder Anleitung INSTALLATION.md)"
  if (-not $NoTailscale) {
    Say "HTTPS im Heimnetz mit Tailscale"
    Write-Host "Tablets dürfen das Mikrofon nur über HTTPS nutzen. Tailscale ist für Privatleute kostenlos und öffnet nichts ins Internet."
    if (Ask "Tailscale jetzt einrichten?") {
      $ts = "C:\Program Files\Tailscale\tailscale.exe"
      if (-not (Test-Path $ts)) {
        if (-not (Winget "Tailscale.Tailscale")) {
          $msi = Join-Path $env:TEMP "tailscale-setup.msi"
          Download "https://pkgs.tailscale.com/stable/tailscale-setup-latest-$(if ($Arch -eq 'arm64') { 'arm64' } else { 'amd64' }).msi" $msi
          Run-Msi $msi
        }
        for ($i = 0; $i -lt 20 -and -not (Test-Path $ts); $i++) { Start-Sleep -Seconds 1 }
        Start-Sleep -Seconds 3
      }
      Write-Host "Gleich öffnet sich ein Browserfenster: dort bei Tailscale anmelden (z. B. mit Google, Microsoft oder Apple)."
      Write-Host "Merke dir das Konto: Auf den Tablets meldest du dich später mit DEMSELBEN Konto an." -ForegroundColor Yellow
      & $ts up | Out-Host
      # Ohne diese Einstellung trennt Tailscale, sobald sich niemand am Rechner anmeldet (z. B. nach einem Neustart)
      & $ts set --unattended=true | Out-Host
      Write-Host "Falls Tailscale jetzt nach 'HTTPS' fragt: den angezeigten Link öffnen, HTTPS einschalten und hier warten."
      & $ts serve --bg $Port | Out-Host
      try {
        $dns = ((& $ts status --json) | ConvertFrom-Json).Self.DNSName.TrimEnd(".")
        if ($dns) { $url = "https://$dns"; $Summary["Tablets (HTTPS)"] = $url }
      } catch {}
      Write-Host "Installiere Tailscale auch auf jedem Tablet (App Store / Google Play) und melde dich mit demselben Konto an." -ForegroundColor Yellow
    }
  }

  # Ein schlafender Rechner ist für die Tablets nicht erreichbar
  & {
    Say "Ruhezustand"
    Write-Host "Schläft dieser Rechner ein, erreichen die Tablets LittleChat nicht mehr."
    if (Ask "Am Netzteil nie in den Energiesparmodus wechseln? (Bildschirm darf aus gehen)") {
      & powercfg /change standby-timeout-ac 0
      & powercfg /change hibernate-timeout-ac 0
      $Summary["Energiesparen"] = "am Netzteil aus (Bildschirm geht weiter aus)"
    }
  }

  Say "Zusammenfassung"
  foreach ($k in $Summary.Keys) { Write-Host ("  {0,-16} {1}" -f $k, $Summary[$k]) }
  Write-Host ("  {0,-16} {1}" -f "Programmordner", $AppDir)
  $codeFile = Join-Path $DataDir "EINRICHTUNGSCODE.txt"
  if (Test-Path $codeFile) {
    Say "Einrichtungscode (brauchst du gleich im Browser)"
    Get-Content $codeFile | Write-Host -ForegroundColor Green
  }
  Say "Fertig. Öffne $url und folge dem Assistenten."
  Start-Process $url
  Done
} catch {
  Write-Host "`nFEHLER: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "Die Installation lässt sich gefahrlos noch einmal starten. Hilfe: INSTALLATION.md im Programmordner."
  Done
  exit 1
}
