#!/usr/bin/env bash
# LittleChat – Installation als systemd-Dienst (Raspberry Pi OS 64 Bit, Debian, Ubuntu und andere mit systemd).
# Aufruf im entpackten Ordner:  sudo bash scripts/install-linux.sh
#   Optionen: --no-tailscale   kein Tailscale (HTTPS dann selbst lösen)
#             --yes            keine Rückfragen
# Was passiert (alles, was LittleChat braucht, wird vom jeweiligen Original geladen):
#   1. Node.js LTS von nodejs.org (Prüfsumme geprüft) nach /opt/littlechat-node, falls kein Node 20+ da ist.
#   2. Abhängigkeiten (npm ci) und die kostenlosen Piper-Stimmen.
#   3. Dienst „littlechat“ (eigener Benutzer, Autostart, Neustart nach Absturz, signierte Updates).
#   4. Auf Wunsch Tailscale für HTTPS (nötig, damit Tablets das Mikrofon nutzen dürfen).
#   5. Einrichtungscode anzeigen.
# Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, nicht mit Anthropic verbunden.
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${PORT:-8787}"
NODE_DIR=/opt/littlechat-node
TAILSCALE=1; YES=0
for a in "$@"; do case "$a" in --no-tailscale) TAILSCALE=0;; --yes|-y) YES=1;; esac; done
say() { printf '\n\033[36m==> %s\033[0m\n' "$*"; }
ask() { [ "$YES" = 1 ] && return 0; read -r -p "$1 (J/n) " r </dev/tty || true; [[ ! "${r:-}" =~ ^[nN] ]]; }
fail() { printf '\n\033[31mFEHLER: %s\033[0m\nDie Installation lässt sich gefahrlos noch einmal starten. Hilfe: INSTALLATION.md\n' "$*"; exit 1; }
[ "$(id -u)" -eq 0 ] || fail "Bitte mit sudo starten: sudo bash scripts/install-linux.sh"
command -v systemctl >/dev/null && [ -d /run/systemd/system ] || fail "Dieses System nutzt kein systemd. Bitte Docker nehmen (siehe INSTALLATION.md)."
command -v curl >/dev/null || { command -v apt-get >/dev/null && apt-get install -y curl; } || fail "curl fehlt"
[ -f "$APP_DIR/server.js" ] || fail "server.js fehlt. Bitte das ZIP vollständig entpacken."
SUMMARY=()

say "Prüfe Node.js"
NODE=""
for n in "$NODE_DIR/bin/node" "$(command -v node || true)"; do
  [ -n "$n" ] && [ -x "$n" ] && [ "$("$n" -p 'process.versions.node.split(".")[0]')" -ge 20 ] 2>/dev/null && { NODE="$n"; break; }
done
if [ -z "$NODE" ]; then
  case "$(uname -m)" in x86_64) ARCH=x64;; aarch64|arm64) ARCH=arm64;; armv7l) ARCH=armv7l;; *) fail "Prozessor $(uname -m) wird nicht unterstützt";; esac
  # neueste LTS-Version, die es für diesen Prozessor gibt (32-Bit-Raspberry: Node 22, läuft bis April 2027)
  VER="$(curl -fsSL https://nodejs.org/dist/index.tab | awk -F'\t' -v a="linux-$ARCH" 'NR>1 && $10!="-" && ("," $3 ",") ~ ("," a ",") {print $1; exit}')"
  [ -n "$VER" ] || fail "Keine Node.js-Version für $ARCH gefunden"
  say "Installiere Node.js $VER nach $NODE_DIR"
  TMP="$(mktemp -d)"; FILE="node-$VER-linux-$ARCH.tar.xz"
  curl -fsSL -o "$TMP/$FILE" "https://nodejs.org/dist/$VER/$FILE"
  curl -fsSL -o "$TMP/SHASUMS256.txt" "https://nodejs.org/dist/$VER/SHASUMS256.txt"
  (cd "$TMP" && grep " $FILE\$" SHASUMS256.txt | sha256sum -c --quiet -) || fail "Prüfsumme von $FILE stimmt nicht"
  rm -rf "$NODE_DIR"; mkdir -p "$NODE_DIR"
  tar -xJf "$TMP/$FILE" -C "$NODE_DIR" --strip-components=1
  rm -rf "$TMP"
  NODE="$NODE_DIR/bin/node"
  [ "$ARCH" = armv7l ] && echo "Hinweis: 32-Bit-System. Node 22 wird bis April 2027 gepflegt. Für die Zukunft Raspberry Pi OS 64 Bit nehmen."
fi
NODE_BIN="$(dirname "$NODE")"
export PATH="$NODE_BIN:$PATH"
echo "Node: $("$NODE" -v) ($NODE)"
SUMMARY+=("Node.js        $("$NODE" -v)")

id littlechat >/dev/null 2>&1 || useradd --system --home-dir "$APP_DIR" --no-create-home --shell /usr/sbin/nologin littlechat
mkdir -p "$APP_DIR/data" "$APP_DIR/logs"
chown -R littlechat:littlechat "$APP_DIR"   # der Dienst spielt Updates selbst ein und braucht Schreibrecht
cd "$APP_DIR"
asapp() { runuser -u littlechat -- env HOME="$APP_DIR" PATH="$PATH" "$@"; }

say "Installiere Abhängigkeiten"
asapp npm ci --omit=dev --no-audit --no-fund || fail "npm ci fehlgeschlagen"

say "Kostenlose Stimmen (Piper, ca. 200 MB)"
if asapp "$NODE" scripts/setup-piper.mjs; then SUMMARY+=("Stimme         Piper (kostenlos, lokal)")
else SUMMARY+=("Stimme         Stimme des Tablets (Piper fehlt, später: node scripts/setup-piper.mjs)"); fi

if [ ! -f .env ]; then cp .env.example .env; sed -i "s/^PORT=.*/PORT=$PORT/" .env; chown littlechat:littlechat .env
else PORT="$(sed -n 's/^\s*PORT\s*=\s*\([0-9]*\).*/\1/p' .env | head -1)"; PORT="${PORT:-8787}"; fi
chmod 700 data; chmod 600 .env

say "Dienst einrichten (Autostart und automatische Updates)"
cat > /etc/systemd/system/littlechat.service <<UNIT
[Unit]
Description=LittleChat (inoffiziell, nicht mit Anthropic verbunden)
After=network-online.target
Wants=network-online.target

[Service]
User=littlechat
WorkingDirectory=$APP_DIR
Environment=PATH=$NODE_BIN:/usr/local/bin:/usr/bin:/bin
Environment=HOME=$APP_DIR
ExecStart=$NODE scripts/supervisor.js
Restart=always
RestartSec=5
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=$APP_DIR
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable littlechat >/dev/null
systemctl restart littlechat
ok=0
for _ in $(seq 60); do sleep 1; curl -fs "http://127.0.0.1:$PORT/api/state" >/dev/null && { ok=1; break; }; done
[ "$ok" = 1 ] || { journalctl -u littlechat -n 20 --no-pager; fail "Der Server antwortet nicht (Protokoll: journalctl -u littlechat)"; }
echo "Server läuft auf http://127.0.0.1:$PORT"
SUMMARY+=("Autostart      an (Dienst littlechat)" "Updates        automatisch, signiert, mit Rückfall auf die alte Version")

URL="http://localhost:$PORT"; TS_RES="nicht eingerichtet"
if [ "$TAILSCALE" = 1 ]; then
  say "HTTPS im Heimnetz mit Tailscale"
  echo "Tablets dürfen das Mikrofon nur über HTTPS nutzen. Tailscale ist für Privatleute kostenlos und öffnet nichts ins Internet."
  if ask "Tailscale jetzt einrichten?"; then
    command -v tailscale >/dev/null || curl -fsSL https://tailscale.com/install.sh | sh
    echo "Gleich erscheint ein Link: im Browser öffnen und bei Tailscale anmelden."
    echo "Merke dir das Konto: Auf den Tablets meldest du dich später mit DEMSELBEN Konto an."
    tailscale up || true
    echo "Falls Tailscale jetzt nach HTTPS fragt: den Link öffnen, HTTPS einschalten und hier warten."
    tailscale serve --bg "$PORT" || true
    DNS="$(tailscale status --json 2>/dev/null | "$NODE" -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{console.log(JSON.parse(s).Self.DNSName.replace(/\.$/,""))}catch{}})')"
    [ -n "$DNS" ] && { URL="https://$DNS"; TS_RES="$URL"; }
    echo "Installiere Tailscale auch auf jedem Tablet (App Store / Google Play) und melde dich mit demselben Konto an."
  fi
fi
SUMMARY+=("Tablets        $TS_RES")

say "Zusammenfassung"
printf '  %s\n' "${SUMMARY[@]}" "Programmordner $APP_DIR"
say "Einrichtungscode (brauchst du gleich im Browser)"
cat data/EINRICHTUNGSCODE.txt 2>/dev/null || echo "(schon eingerichtet)"
say "Fertig. Öffne $URL und folge dem Assistenten."
