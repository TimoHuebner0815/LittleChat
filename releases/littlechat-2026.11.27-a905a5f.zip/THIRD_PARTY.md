# Bestandteile Dritter

LittleChat selbst ist urheberrechtlich geschützt (siehe [LICENSE](LICENSE)). Folgende fremde Bestandteile stehen unter ihren eigenen Lizenzen:

| Bestandteil | Lizenz | Wie eingebunden |
|---|---|---|
| [@anthropic-ai/sdk](https://github.com/anthropics/anthropic-sdk-typescript) und seine Abhängigkeiten | MIT bzw. Apache-2.0 (siehe `package-lock.json`) | npm-Abhängigkeit |
| [Piper](https://github.com/rhasspy/piper) | MIT, enthält espeak-ng (GPL-3.0) | wird nicht mitgeliefert; `scripts/setup-piper.mjs` lädt es vom Original herunter |
| Piper-Stimmen Thorsten, Kerstin, Thorsten emotional | CC0 | Download vom Original (Hugging Face, rhasspy/piper-voices) |
| Piper-Stimme MLS (optional) | CC BY 4.0, Namensnennung: Multilingual LibriSpeech, openslr.org/94 | Download vom Original |
