# Gesprächsmodi

Jede `.md`-Datei in diesem Ordner ist ein Modus, den das Kind auf dem Walkie-Talkie per Symbol wählt.
Der Text unter dem Kopf wird an die Standard-Persona (`kid_persona.md`) angehängt. Die Sicherheitsregeln
der Persona gelten in jedem Modus und gehen immer vor.

Kopf (zwischen den `---`-Zeilen):

| Feld     | Bedeutung |
|----------|-----------|
| `name`   | Anzeigename (Kind und Eltern) |
| `emoji`  | Symbol auf dem Knopf |
| `farbe`  | Knopffarbe (#rrggbb) |
| `reihe`  | Reihenfolge der Knöpfe |
| `ansage` | Wird vorgelesen, wenn das Kind den Modus antippt |
| `eltern` | Kurze Beschreibung im Eltern-Bereich |
| `avatare` | `ja`: In diesem Modus (ab Werk: „Avatar“) kann das Kind Avatare (Profilbilder) erfinden, höchstens 3 pro Kind |
| `figur-tipp` | `ja`: Hat das Kind noch keine Figur, schlägt die KI in diesem Modus vor, eine zu erfinden, und erklärt den Knopf (ab Werk: Langeweile) |

Platzhalter wie in der Persona: `{{NAME}}`, `{{AGE}}`, `{{APP}}` (Name des Assistenten, von Eltern änderbar).
Der Dateiname (ohne `.md`) ist die feste Kennung; nicht umbenennen, sonst verlieren Kinder die Freigabe.
Neue Dateien sind für alle Kinder automatisch freigeschaltet, außer die Eltern haben die Modi des Kindes
schon einmal eingeschränkt.
