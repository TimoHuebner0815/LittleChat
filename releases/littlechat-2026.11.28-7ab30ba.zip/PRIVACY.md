# Datenschutz-Hinweise für Eltern

LittleChat ist ein **privates, inoffizielles Projekt** und **mit keinem KI-Anbieter verbunden** (weder Anthropic noch OpenAI, Google, Mistral AI, xAI oder Ollama). Es gibt keinen Betreiber, keine Cloud und kein Konto bei uns. Du betreibst die App selbst, auf deinem eigenen Rechner. Diese Seite erklärt, welche Daten wohin gehen.

Kurz gesagt: Kinderdaten bleiben auf deinem Rechner. Was dein Kind sagt, geht zur Spracherkennung an Google bzw. Apple, als Text an den gewählten KI-Anbieter (Standard: Anthropic; bei Ollama bleibt alles im Haus). Du kannst alles einsehen und löschen.

## Wo liegen welche Daten?

| Daten | Wo | Wie lange |
|---|---|---|
| Vorname, Geburtsdatum, Farbe, Limits und Einstellungen der Kinder (Modi, KI-Anbieter, Stimme, Untertitel) | Auf deinem Server, `data/db.enc`, verschlüsselt (AES-256-GCM) | Bis du sie löschst |
| Gespräche (Abschrift, Seifenblasen-Titel, Zusammenfassung) | Auf deinem Server, verschlüsselt | Standard 30 Tage, einstellbar, danach automatisch gelöscht |
| Avatare (Name, Beschreibung, Bild) | Auf deinem Server, verschlüsselt | Bis Eltern sie löschen (oder das Kind gelöscht wird). Löscht das Kind einen Avatar, ist er nur für das Kind weg. |
| Dein API-Schlüssel | Auf deinem Server, verschlüsselt | Bis du ihn entfernst |
| Eltern-Passwort | Nur als scrypt-Hash | Bis du es änderst |
| Backups | `data/backups` oder der Ordner aus `LC_BACKUP_DIR`, verschlüsselt | 30 Tage |
| Freigegebene Geräte: Name, grober Gerätetyp (z. B. „Tablet · iPadOS 17 · Safari“), Zugangsweg, Freigabe- und letzte Aktivitätszeit | Auf deinem Server, verschlüsselt. Keine IP-Adressen, kein Fingerprinting | Bis du das Gerät sperrst |
| Gewählte Server- oder Cloud-Stimme | Auf deinem Server, verschlüsselt | Bis du sie änderst |
| Auswahl und Tempo der Gerätestimme | Im Browser des Tablets | Bis zum Löschen der Browserdaten |

Den **Wiederherstellungsschlüssel** zeigt der Einrichtungs-Assistent einmal an. Bewahre ihn sicher auf. Er schützt deine Backups: Wer ein Backup ohne den Schlüssel findet, kann nichts lesen. Auf dem Server selbst liegt der Schlüssel als `data/master.key`, damit der Server ohne Eingabe neu starten kann. **Wer vollen Zugriff auf den Server-Rechner hat, kann die Daten lesen.** Schütze den Rechner entsprechend, zum Beispiel mit Benutzerkonto-Passwort und BitLocker bzw. Festplattenverschlüsselung.

**Löschen:** Im Eltern-Bereich unter „Gespräche“ löschst du einzelne Gespräche oder alle eines Kindes endgültig. Die verschlüsselten Sicherungen werden dabei nicht verändert: Gelöschte Gespräche stecken dort noch bis zu 30 Tage und lassen sich so lange unter „Sicherung → Aus einer Sicherung zurückholen“ wiederholen. Danach laufen die Sicherungen ab und die Gespräche sind ganz weg. Kopien, die außerhalb von LittleChat entstanden sind (z. B. OneDrive-Versionsverlauf eines `LC_BACKUP_DIR`), erreicht LittleChat nicht.

## Was verlässt dein Zuhause?

1. **Spracherkennung (Standard): Browser-Anbieter.** Die Spracherkennung im Browser schickt die Aufnahme je nach Gerät an Google (Chrome, Android) oder verarbeitet sie über Apple (Safari, iPad, iPhone). LittleChat hat darauf keinen Einfluss.
   **Alternative: lokal mit Whisper.** Wenn du in `.env` die Variable `LC_STT_URL` auf einen Whisper-Server in deinem Heimnetz setzt, nimmt das Tablet die Stimme selbst auf. Die Aufnahme geht dann nur an deinen Server und von dort an deinen Whisper-Server. Sie verlässt dein Zuhause nicht. Unterstützt wird jeder OpenAI-kompatible Transkriptions-Endpunkt (`/v1/audio/transcriptions`).
2. **Der gewählte KI-Anbieter** (Standard: Claude von Anthropic; wahlweise OpenAI, Google, Mistral AI, xAI oder lokal Ollama, global oder pro Kind). Der erkannte **Text** der Frage geht an diesen Anbieter, bei Ollama bleibt er auf deinem Rechner. Mit ihm gehen die Persönlichkeit samt Vorname und Alter des Kindes, eine kurze Zusammenfassung des bisherigen Gesprächs und die letzten Nachrichten. Es werden keine Audiodaten, kein Nachname, kein Geburtsdatum und keine Geräte-Kennungen übertragen. Wie Anthropic API-Daten verarbeitet und wie lange es sie speichert, steht in den Bedingungen und Datenschutzhinweisen von Anthropic. Prüfe sie selbst auf [anthropic.com/legal](https://www.anthropic.com/legal).

   **Andere Anbieter (wenn du sie im Eltern-Bereich wählst):** Genau dieselben Daten gehen dann an OpenAI (USA), Google (Gemini), Mistral AI (Frankreich, EU) oder xAI (USA), und zwar nur an den Anbieter, der für das jeweilige Kind eingestellt ist. Auch Seifenblasen-Titel, Zusammenfassungen und den Tagesrückblick für die Eltern erstellt derselbe Anbieter, es wandert also nichts zu einem zweiten. Den Tagesrückblick (Eltern-Bereich › Heute) könnt ihr dort abschalten. Bei **Gemini** nur mit bezahltem Tarif: Im kostenlosen Tarif darf Google Eingaben zur Produktverbesserung nutzen und von Menschen prüfen lassen. Bei **Ollama** läuft das Modell auf deinem Rechner, die Texte verlassen dein Zuhause nicht. Für jeden Anbieter gelten dessen eigene Bedingungen und Datenschutzhinweise, prüfe sie selbst.
3. **Sprachausgabe.** Standard ist die eigene Stimme (Piper) auf deinem Server, oder ohne Piper die Systemstimme des Tablets. In beiden Fällen verlässt nichts dein Zuhause. Wählst du im Eltern-Bereich (für alle oder für ein Kind) eine Cloud-Stimme von **Google**, **Microsoft Azure** oder **ElevenLabs**, geht der **Text, der vorgelesen wird** (Antworten und Ansagen, kann den Vornamen des Kindes enthalten), an diesen Dienst, nicht die Stimme des Kindes. Feste Ansagen speichert LittleChat dafür verschlüsselt auf deinem Server. Die **Stimme des jeweiligen Geräts** läuft auf dem Tablet; manche Geräte nutzen dafür einen Online-Dienst ihres Herstellers. Mit einem eigenen Sprach-Server wie Piper bleibt alles im Haus.
4. **Tailscale (optional, für HTTPS).** Tailscale vermittelt verschlüsselte Verbindungen zwischen deinen Geräten. Die Inhalte laufen Ende-zu-Ende verschlüsselt. Tailscale sieht Geräte-Namen und Verbindungsdaten.

## Was du als Elternteil tun solltest

- **Sprich mit deinem Kind darüber**, dass es mit einer KI spricht, nicht mit einem Menschen. LittleChat sagt das auch selbst in der Startansage und wenn das Kind fragt.
- **Lies ab und zu mit.** Im Eltern-Bereich stehen alle Gespräche. Gespräche mit abgelehnten Fragen sind mit ⚠ markiert.
- **Entscheide bewusst über den Hinweis „Mama oder Papa haben geschaut“.** Bei kleinen Kindern ist es unproblematisch, ihn auszuschalten. Ab dem Schulalter empfehlen wir Transparenz.
- **Setz ein Ausgabenlimit** bei Anthropic (Prepaid-Guthaben ohne automatisches Aufladen und ein Workspace-Limit) und bei jedem weiteren Anbieter. Die Anleitungen im Eltern-Bereich erklären die Schritte.

## Regeln der KI-Anbieter für Produkte, die Minderjährige nutzen

Die Tabelle folgt den Anthropic-Richtlinien (Standard-Anbieter). Die anderen Anbieter haben eigene Nutzungsbedingungen mit ähnlichen Anforderungen; prüfe sie, bevor du einen anderen Anbieter für deine Kinder wählst.

Die API ist für Erwachsene gedacht. Wenn Kinder direkt mit Claude sprechen, erwartet Anthropic zusätzliche Schutzmaßnahmen. Siehe die [Richtlinien für Organisationen, die Minderjährige betreuen](https://support.claude.com/en/articles/9307344-responsible-use-of-anthropic-s-models-guidelines-for-organizations-serving-minors) und die [Child-Safety-Hinweise für Entwickler](https://support.claude.com/en/articles/15591275-child-safety-guidance-for-developers). Genannt werden unter anderem:

| Anthropic erwartet | So setzt LittleChat es um |
|---|---|
| Zugang nur für vorgesehene Nutzer | Nur von Eltern freigegebene Geräte, Eltern-Passwort, Gerätesperre |
| Inhalte moderieren und filtern | Kinderschutz-Regeln (`kid_safety.md`, getrennt von der Persönlichkeit, gelten immer), Claudes eigene Schutzregeln, freundliche Ablehnung |
| Überwachung und Meldewege | Abschriften für Eltern, ⚠-Markierung bei abgelehnten Fragen, Limits |
| Hinweise zur sicheren Nutzung für Kinder | Startansage, Persona verweist bei Sorgen an Eltern und die Nummer gegen Kummer (116 111) |
| Offenlegen, dass es eine KI ist | Startansage und Persona sagen es ausdrücklich |
| Kinderschutz- und Datenschutzgesetze einhalten | Daten bleiben lokal, Löschfristen, kein Profiling. Die rechtliche Verantwortung für den Betrieb liegt bei dir. |

**Andere KI-Anbieter** haben eigene Regeln zu Minderjährigen, teils mit Mindestalter oder nur mit Zustimmung der Eltern. LittleChat kann nicht prüfen, ob deine Nutzung dort erlaubt ist. Lies die Nutzungsbedingungen des Anbieters, bevor du ihn für ein Kind einschaltest. Der Kinderfragen-Test im Eltern-Bereich zeigt dir vorher, wie der Anbieter mit der LittleChat-Persona auf heikle Fragen antwortet.

Anthropic prüft die Einhaltung der Nutzungsrichtlinien. Bei Verstößen kann es dein API-Konto sperren. Die [Nutzungsrichtlinie](https://www.anthropic.com/legal/aup) gilt für jede Nutzung.

*Dies ist keine Rechtsberatung. Bei rein privater Nutzung in der Familie greift in der EU in der Regel die Haushaltsausnahme der DSGVO (Art. 2 Abs. 2 lit. c). Wenn du LittleChat für andere Kinder betreibst, zum Beispiel in Kita, Schule oder Verein, gelten weitergehende Pflichten.*
