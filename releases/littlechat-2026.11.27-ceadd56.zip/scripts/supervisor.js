// Aufpasser für den LittleChat-Server: startet server.js, startet ihn nach einem Absturz neu
// und spielt freigegebene Updates selbst ein, ohne Windows-Abfrage und ohne dass jemand am Rechner sitzt.
//
// Ablauf alle LC_UPDATE_EVERY_MIN Minuten (und sofort, wenn die Datei „update-now“ im Programmordner liegt;
// „publish-now“ veröffentlicht auf dem Prüf-NUC den laufenden Stand sofort, „rollback-now“ geht bei
// Release-Installationen von Hand auf die vorige Version zurück):
//   1. Freigegebenen Stand holen: mit Deploy-Schlüssel (data/deploy_key, nur Lesen) direkt von GitHub,
//      sonst gilt der Stand, den jemand per „git pull“ in den Ordner geholt hat.
//   2. Nur einspielen, wenn seit LC_UPDATE_IDLE_MIN Minuten kein Kind spricht (nachts 2–5 Uhr immer).
//   3. Nur Vorspulen (fast-forward), nie fremde Änderungen überschreiben. Abhängigkeiten nur bei Bedarf.
//   4. Server sauber beenden (Speichern wird abgeschlossen), neuen starten, 60 s auf „bereit“ warten
//      und prüfen, dass er danach weiterläuft. Sonst: alter Stand zurück, neuer Stand gesperrt.
// Zwei Quellen:
//   - Git (Prüf-NUC, Entwicklung): Ordner ist ein Git-Klon, siehe oben.
//   - Release (alle anderen Familien, Ordner ohne .git): signiertes ZIP aus dem öffentlichen Repo LittleChat.
//     Manifest-Signatur (Ed25519) und SHA-256 werden geprüft, nur neuere Stände (seq) werden genommen.
// Der Prüf-NUC veröffentlicht einen Stand erst, wenn er dort LC_PUBLISH_AFTER_H Stunden (Standard 3) ohne
// Rückfall lief: ZIP bauen, signieren, ins öffentliche Repo schieben (data/publish_key mit Schreibrecht).
// Startet sich selbst neu, wenn ein Update den Aufpasser selbst ändert (oberer Prozess = kleiner Starter).
// Protokoll: logs/update.log, Zustand: logs/update-status.json (beides ohne Geheimnisse, für Eltern lesbar).
// Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, nicht mit Anthropic verbunden.

import fs from "node:fs";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import * as rel from "./release.js";

const SELF = fileURLToPath(import.meta.url);
// ------------------------------------------------------------------ Starter
// Der Prozess, den Windows-Aufgabe oder systemd startet, ist nur ein kleiner Starter. Er startet den eigentlichen
// Aufpasser und startet ihn neu, wenn der sich nach einem Update selbst beendet (Code 75). So greift ein neuer
// Aufpasser sofort, ohne Adminrechte und ohne Neustart des Rechners.
if (!process.env.LC_SUPERVISOR_CHILD) {
  let kid = null, quitting = false;
  const run = () => {
    kid = spawn(process.execPath, [SELF], { stdio: ["ignore", "inherit", "inherit", "ipc"], windowsHide: true, env: { ...process.env, LC_SUPERVISOR_CHILD: "1" } });
    kid.on("exit", (code) => { if (!quitting) setTimeout(run, code === 75 ? 200 : 5000); });
  };
  run();
  for (const sig of ["SIGINT", "SIGTERM"]) process.once(sig, () => {
    quitting = true;
    try { kid.send({ t: "shutdown" }); } catch {}
    setTimeout(() => process.exit(0), 20_000).unref();
    kid.once("exit", () => process.exit(0));
  });
} else {

const ROOT = process.env.LC_APP_DIR || path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
loadDotEnv(path.join(ROOT, ".env"));
const DATA_DIR = process.env.LC_DATA_DIR || path.join(ROOT, "data");
const LOG_DIR = path.join(ROOT, "logs");
const KEY_FILE = path.join(DATA_DIR, "deploy_key");
const STATE_FILE = path.join(DATA_DIR, "update-state.json");
const STATUS_FILE = path.join(LOG_DIR, "update-status.json");
const FLAG_FILE = path.join(ROOT, "update-now");
const ROLLBACK_FLAG = path.join(ROOT, "rollback-now"); // Familien: zurück auf die vorige Version
const PUBLISH_FLAG = path.join(ROOT, "publish-now"); // Prüf-NUC: laufenden Stand sofort veröffentlichen, ohne Probelauf-Frist
const ENABLED = (process.env.LC_AUTOUPDATE || "on") !== "off";
const BRANCH = process.env.LC_UPDATE_BRANCH || "main";
const EVERY_MS = Number(process.env.LC_UPDATE_EVERY_MIN || 10) * 60_000;
const IDLE_MS = Number(process.env.LC_UPDATE_IDLE_MIN || 5) * 60_000;
const READY_MS = Number(process.env.LC_UPDATE_READY_SEC || 60) * 1000;
const ALIVE_MS = Number(process.env.LC_UPDATE_ALIVE_SEC || 20) * 1000;
const FLAG_POLL_MS = Number(process.env.LC_UPDATE_FLAG_SEC || 15) * 1000;
const PUBLISH_AFTER_MS = Number(process.env.LC_PUBLISH_AFTER_H ?? 3) * 3600_000;
const PUBLISH = (process.env.LC_PUBLISH || "on") !== "off";
const PUBLISH_KEY = path.join(DATA_DIR, "publish_key");
const SIGNING_KEY = path.join(DATA_DIR, "release_signing.pem");
const UPDATE_DIR = path.join(ROOT, ".update");
const PUBLISH_DIR = path.join(ROOT, ".publish");
const MODE = fs.existsSync(path.join(ROOT, ".git")) ? "git" : "release";
const SELF_FILES = ["scripts/supervisor.js", "scripts/release.js"];

fs.mkdirSync(LOG_DIR, { recursive: true });
fs.mkdirSync(DATA_DIR, { recursive: true });

function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}
const stamp = () => new Date().toLocaleString("sv-SE").slice(0, 19);
function log(msg) {
  const line = `${stamp()}  ${msg}`;
  console.log("[update] " + msg);
  try {
    const f = path.join(LOG_DIR, "update.log");
    if (fs.existsSync(f) && fs.statSync(f).size > 512 * 1024) fs.renameSync(f, f + ".1");
    fs.appendFileSync(f, line + "\n");
  } catch {}
}
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };
const saved = readJson(STATE_FILE, { bad: [] });
const status = { running: "", mode: MODE, branch: BRANCH, autoupdate: ENABLED, source: "", lastCheck: "", lastResult: "", lastUpdate: "", publish: "" };
function save() {
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(saved, null, 1)); } catch {}
  try { fs.writeFileSync(STATUS_FILE, JSON.stringify(status, null, 1)); } catch {}
}

// ------------------------------------------------------------------ git
function findGit() {
  if (process.platform !== "win32") return "git";
  if (!spawnSync("git", ["--version"], { windowsHide: true }).error) return "git";
  for (const p of ["C:\\Program Files\\Git\\cmd\\git.exe", "C:\\Program Files (x86)\\Git\\cmd\\git.exe"]) if (fs.existsSync(p)) return p;
  return "git";
}
const GIT = findGit();
const slash = (p) => p.replace(/\\/g, "/");
function git(args, opts = {}) {
  // safe.directory: der Ordner gehört dem Benutzer, der Aufpasser läuft als SYSTEM
  const r = spawnSync(GIT, ["-c", "safe.directory=*", ...args], {
    cwd: opts.cwd || ROOT, encoding: "utf8", windowsHide: true, timeout: 120_000,
    env: { ...process.env, GIT_TERMINAL_PROMPT: "0", ...(opts.env || {}) },
  });
  if (r.error) throw new Error(`git ${args[0]}: ${r.error.message}`);
  if (r.status !== 0 && !opts.allowFail) throw new Error(`git ${args[0]}: ${(r.stderr || r.stdout || "").trim().split("\n").slice(-2).join(" ")}`);
  return r.status === 0 ? (r.stdout || "").trim() : null;
}
const short = (sha) => (sha || "").slice(0, 7);
// GitHub-Adresse über SSH, damit der Deploy-Schlüssel greift (origin zeigt meist auf https)
function releaseRemote() {
  if (process.env.LC_UPDATE_REMOTE) return { url: process.env.LC_UPDATE_REMOTE, env: {} };
  if (!fs.existsSync(KEY_FILE)) return null;
  const origin = git(["remote", "get-url", "origin"], { allowFail: true }) || "";
  const m = origin.match(/github\.com[:/]([^/]+\/[^/]+?)(\.git)?\/?$/i);
  if (!m) return null;
  return { url: `git@github.com:${m[1]}.git`, env: sshEnv(KEY_FILE) };
}
const sshEnv = (key) => ({ GIT_SSH_COMMAND: `ssh -i "${slash(key)}" -o IdentitiesOnly=yes -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile="${slash(path.join(DATA_DIR, "known_hosts"))}"` });
const head = () => git(["rev-parse", "HEAD"]);
const isAncestor = (a, b) => git(["merge-base", "--is-ancestor", a, b], { allowFail: true }) !== null;
const changed = (a, b, file) => git(["diff", "--quiet", a, b, "--", file], { allowFail: true }) === null;

function npmCi() {
  // Windows: neben node.exe; Linux-Tarball (/opt/littlechat-node): bin/../lib/node_modules
  const bin = path.dirname(process.execPath);
  const cli = [path.join(bin, "node_modules", "npm", "bin", "npm-cli.js"), path.join(bin, "..", "lib", "node_modules", "npm", "bin", "npm-cli.js")].find((f) => fs.existsSync(f)) || "";
  const [cmd, args] = fs.existsSync(cli) ? [process.execPath, [cli]] : [process.platform === "win32" ? "npm.cmd" : "npm", []];
  log("Abhängigkeiten haben sich geändert: npm ci");
  const r = spawnSync(cmd, [...args, "ci", "--omit=dev", "--no-audit", "--no-fund"], { cwd: ROOT, encoding: "utf8", windowsHide: true, timeout: 600_000, shell: !fs.existsSync(cli) && process.platform === "win32" });
  if (r.status !== 0) throw new Error("npm ci fehlgeschlagen: " + (r.stderr || r.error?.message || "").trim().split("\n").slice(-2).join(" "));
}

// ------------------------------------------------------------------ Server
let child = null, expecting = false, lastBusy = 0, crashes = 0, restartTimer = null, stopping = false;
function startServer() {
  clearTimeout(restartTimer);
  const version = MODE === "git"
    ? (() => { try { return short(head()) + " · " + git(["log", "-1", "--format=%cs"]); } catch { return ""; } })()
    : installedVersion().version || "";
  status.running = version;
  const c = spawn(process.execPath, [path.join(ROOT, "server.js")], {
    cwd: ROOT, stdio: ["ignore", "inherit", "inherit", "ipc"], windowsHide: true, env: { ...process.env, LC_VERSION: version },
  });
  child = c;
  c.readyAt = 0; c.startedAt = Date.now();
  c.on("message", (m) => {
    if (m?.t === "ready") { c.readyAt = Date.now(); c.emit("lc-ready"); }
    if (m?.t === "busy") lastBusy = Date.now();
  });
  c.on("exit", (code, sig) => {
    c.exited = true;
    const planned = expecting || stopping; // vor lc-exit lesen: stopServer setzt expecting dort zurück
    c.emit("lc-exit");
    if (child !== c) return;
    child = null;
    if (planned) return;
    // Absturz: mit wachsender Pause neu starten
    crashes = Date.now() - c.startedAt > 5 * 60_000 ? 1 : crashes + 1;
    const wait = [2, 5, 15, 60][Math.min(crashes - 1, 3)] * 1000;
    log(`Server beendet (${code ?? sig}). Neustart in ${wait / 1000} s.`);
    restartTimer = setTimeout(startServer, wait);
  });
  save();
  return c;
}
function stopServer() {
  const c = child;
  if (!c || c.exited) return Promise.resolve();
  expecting = true;
  return new Promise((res) => {
    const t = setTimeout(() => { try { c.kill(); } catch {} }, 15_000);
    c.once("lc-exit", () => { clearTimeout(t); expecting = false; res(); });
    try { c.send({ t: "shutdown" }); } catch { c.kill(); }
  });
}
// Neuer Server muss „bereit“ melden und danach eine Weile laufen
function healthy(c) {
  return new Promise((res) => {
    let done = false;
    const end = (ok) => { if (!done) { done = true; clearTimeout(t1); res(ok); } };
    const t1 = setTimeout(() => end(false), READY_MS);
    c.once("lc-exit", () => end(false));
    const alive = () => { clearTimeout(t1); setTimeout(() => end(!c.exited), ALIVE_MS); };
    if (c.readyAt) alive(); else c.once("lc-ready", alive);
  });
}

// ------------------------------------------------------------------ Update
let updating = false, lastFetchError = "", lastPublishError = "";
let running = "";
function nightTime() { const h = new Date().getHours(); return h >= 2 && h < 5; }
function installedVersion() { return readJson(path.join(ROOT, "VERSION"), { version: "", seq: 0, commit: "" }); }
const markBad = (id) => { saved.bad.push(id); saved.bad = saved.bad.slice(-20); };
const readOr = (f) => { try { return fs.readFileSync(f); } catch { return null; } };
const read = (f) => { try { return fs.readFileSync(f, "utf8"); } catch { return ""; } };
const sameBuf = (a, b) => (a && b ? a.equals(b) : a === b);

async function check(force) {
  if (updating || stopping) return;
  updating = true;
  try {
    status.lastCheck = stamp();
    if (MODE === "git") await checkGit(force); else await checkRelease(force);
  } catch (e) {
    log("Fehler: " + e.message);
    status.lastResult = "Fehler: " + e.message;
  } finally {
    updating = false;
    save();
  }
  if (MODE === "git") await maybePublish().catch(() => {});
}
const mayApplyNow = (force) => force || Date.now() - lastBusy > IDLE_MS || nightTime();

async function checkGit(force) {
  const current = head();
  let target = current, source = "Ordner", fetchFailed = "";
  const remote = ENABLED ? releaseRemote() : null;
  if (remote) {
    try {
      git(["fetch", "--quiet", "--no-tags", remote.url, BRANCH], { env: remote.env });
      target = git(["rev-parse", "FETCH_HEAD"]);
      source = "GitHub";
      if (lastFetchError) { log("Verbindung zu GitHub wieder in Ordnung."); lastFetchError = ""; }
    } catch (e) {
      if (e.message !== lastFetchError) log("Abholen fehlgeschlagen: " + e.message);
      lastFetchError = e.message;
      fetchFailed = "GitHub nicht erreichbar oder Schlüssel fehlt: " + e.message;
    }
  }
  status.source = source;
  if (target === running) { status.lastResult = fetchFailed || "aktuell"; return; }
  if (saved.bad.includes(target)) { status.lastResult = `Stand ${short(target)} ist gesperrt (startete nicht)`; return; }
  if (!mayApplyNow(force)) { status.lastResult = `neuer Stand ${short(target)} wartet, bis niemand spricht`; return; }
  await applyGit(running, current, target);
}

async function applyGit(old, current, target) {
  if (current !== target) {
    if (!isAncestor(current, target)) {
      log(`Stand ${short(target)} ist kein Vorspulen von ${short(current)}. Übersprungen.`);
      markBad(target);
      status.lastResult = "übersprungen (kein Vorspulen)";
      return;
    }
    // scheitert absichtlich, wenn im Ordner etwas von Hand geändert wurde
    git(["merge", "--ff-only", "--quiet", target]);
  }
  log(`Update ${short(old)} → ${short(target)}`);
  const lockChanged = changed(old, target, "package-lock.json");
  try { if (lockChanged) npmCi(); }
  catch (e) { // der alte Server läuft noch: Ordner wieder auf seinen Stand, neuen Stand sperren
    git(["reset", "--hard", "--quiet", old]);
    markBad(target);
    throw e;
  }
  const selfChanged = SELF_FILES.some((f) => changed(old, target, f));
  await restartChecked(short(target), () => {
    git(["reset", "--hard", "--quiet", old]);
    if (lockChanged) { try { npmCi(); } catch (e) { log(e.message); } }
  }, target, selfChanged);
}

async function checkRelease(force) {
  if (!ENABLED) return;
  status.source = "Release";
  let m;
  try {
    const r = await fetch(rel.RELEASE_BASE + "latest.json", { cache: "no-store", signal: AbortSignal.timeout(30_000) });
    if (!r.ok) throw new Error("HTTP " + r.status);
    m = rel.verifyManifest(await r.json());
    if (lastFetchError) { log("Update-Kanal wieder erreichbar."); lastFetchError = ""; }
  } catch (e) {
    if (e.message !== lastFetchError) log("Update-Kanal: " + e.message);
    lastFetchError = e.message;
    status.lastResult = "Update-Kanal nicht erreichbar oder ungültig: " + e.message;
    return;
  }
  const have = installedVersion();
  if (m.seq <= (have.seq || 0)) { status.lastResult = "aktuell"; return; }
  if (saved.bad.includes(m.commit)) { status.lastResult = `Version ${m.version} ist gesperrt (startete nicht)`; return; }
  if (!mayApplyNow(force)) { status.lastResult = `Version ${m.version} wartet, bis niemand spricht`; return; }

  const r = await fetch(rel.RELEASE_BASE + m.file, { signal: AbortSignal.timeout(120_000) });
  if (!r.ok) throw new Error("Paket: HTTP " + r.status);
  const zip = Buffer.from(await r.arrayBuffer());
  if (zip.length !== m.size || rel.sha256(zip) !== m.sha256) throw new Error("Paket passt nicht zur Signatur (Größe/SHA-256)");
  const entries = rel.readZip(zip);
  const ver = JSON.parse(entries.find((e) => e.name === "VERSION")?.data || "{}");
  if (ver.commit !== m.commit || !entries.some((e) => e.name === "server.js")) throw new Error("Paket unvollständig");

  log(`Update ${have.version || "?"} → ${m.version}`);
  const before = Object.fromEntries(["package-lock.json", ...SELF_FILES].map((f) => [f, readOr(path.join(ROOT, f))]));
  fs.mkdirSync(UPDATE_DIR, { recursive: true });
  const restore = rel.installFiles(ROOT, entries, UPDATE_DIR);
  const lockChanged = !sameBuf(before["package-lock.json"], readOr(path.join(ROOT, "package-lock.json")));
  try { if (lockChanged) npmCi(); }
  catch (e) { restore(); markBad(m.commit); throw e; }
  const selfChanged = SELF_FILES.some((f) => !sameBuf(before[f], readOr(path.join(ROOT, f))));
  await restartChecked(m.version, () => {
    restore();
    if (lockChanged) { try { npmCi(); } catch (e) { log(e.message); } }
  }, m.commit, selfChanged);
}

// Server neu starten und prüfen; bei Fehler zurück. Hat sich der Aufpasser selbst geändert, startet er neu.
async function restartChecked(label, rollback, id, selfChanged) {
  const old = running;
  await stopServer();
  const ok = await healthy(startServer());
  if (ok) {
    running = MODE === "git" ? id : label;
    saved.runningCommit = MODE === "git" ? id : ""; saved.since = Date.now();
    status.lastUpdate = stamp();
    status.lastResult = `aktualisiert auf ${label}`;
    log(`Läuft: ${label}`);
    if (selfChanged) {
      log("Aufpasser selbst wurde aktualisiert: Neustart des Aufpassers.");
      save();
      stopping = true;
      await stopServer();
      process.exit(75);
    }
    return;
  }
  log(`Neuer Stand ${label} startet nicht. Zurück auf ${MODE === "git" ? short(old) : old || "vorher"}.`);
  markBad(id);
  rollback();
  await stopServer();
  startServer();
  status.lastResult = `zurückgerollt (${label} startete nicht)`;
}

// Von Hand zurück auf die vorige Version (Datei „rollback-now“, nur Release-Installationen).
// Die aktuelle Version wird gesperrt, die nächste neuere kommt wieder automatisch.
async function rollbackManual() {
  if (MODE !== "release") { log("Zurück auf die vorige Version gibt es nur bei Installationen aus dem ZIP (Git: git reset)."); return; }
  if (updating || stopping) return;
  updating = true;
  try {
    const bj = path.join(UPDATE_DIR, "backup.json");
    if (!fs.existsSync(bj)) { log("Zurück nicht möglich: Es ist keine vorige Version gespeichert."); status.lastResult = "Zurück nicht möglich: keine vorige Version gespeichert"; return; }
    const cur = installedVersion();
    const before = Object.fromEntries(["package-lock.json", ...SELF_FILES].map((f) => [f, readOr(path.join(ROOT, f))]));
    await stopServer();
    rel.restoreFiles(ROOT, UPDATE_DIR);
    fs.rmSync(bj, { force: true });
    fs.rmSync(path.join(UPDATE_DIR, "backup"), { recursive: true, force: true });
    if (cur.commit) markBad(cur.commit);
    if (!sameBuf(before["package-lock.json"], readOr(path.join(ROOT, "package-lock.json")))) { try { npmCi(); } catch (e) { log(e.message); } }
    running = installedVersion().version || "?";
    status.lastUpdate = stamp();
    status.lastResult = `von Hand zurück auf ${running}, ${cur.version || "?"} gesperrt`;
    log(`Zurück auf ${running}. Version ${cur.version || "?"} ist gesperrt, die nächste neuere kommt wieder automatisch.`);
    if (SELF_FILES.some((f) => !sameBuf(before[f], readOr(path.join(ROOT, f))))) { save(); stopping = true; process.exit(75); }
    startServer();
  } catch (e) {
    log("Zurück fehlgeschlagen: " + e.message);
    status.lastResult = "Zurück fehlgeschlagen: " + e.message;
    if (!child) startServer();
  } finally {
    updating = false;
    save();
  }
}

// ------------------------------------------------------------------ Veröffentlichen (nur Prüf-NUC)
function ensurePublishKeys() {
  if (MODE !== "git" || !PUBLISH) return;
  try {
    if (!fs.existsSync(SIGNING_KEY)) fs.writeFileSync(SIGNING_KEY, rel.newSigningKey().pem);
    fs.writeFileSync(path.join(LOG_DIR, "release_signing.pub"), rel.pubFromPem(fs.readFileSync(SIGNING_KEY, "utf8")) + "\n");
  } catch (e) { log("Signierschlüssel: " + e.message); }
  if (process.env.LC_PUBLISH_REMOTE) return;
  try { fs.writeFileSync(path.join(LOG_DIR, "publish_key.pub"), rel.sshKeygen(PUBLISH_KEY, "littlechat-publish") + "\n"); }
  catch (e) { log("Schlüssel für Veröffentlichung: " + e.message); }
}

async function maybePublish(now = false) {
  const skip = (why) => { if (now) { log("Nicht veröffentlicht: " + why); status.publish = "nicht veröffentlicht: " + why; save(); } };
  if (MODE !== "git") return;
  if (!PUBLISH) return skip("Veröffentlichen ist abgeschaltet (LC_PUBLISH)");
  if (!fs.existsSync(SIGNING_KEY)) return skip("Signierschlüssel fehlt (data/release_signing.pem)");
  if (!(process.env.LC_PUBLISH_REMOTE || fs.existsSync(PUBLISH_KEY))) return skip("Upload-Schlüssel fehlt (data/publish_key)");
  if (!running || running !== head()) return skip("Ordner und laufender Stand passen nicht zusammen");
  if (saved.published === running) return skip(`${short(running)} ist bereits veröffentlicht`);
  const waited = Date.now() - (saved.since || Date.now());
  if (!now && waited < PUBLISH_AFTER_MS) { status.publish = `${short(running)} wird nach ${Math.ceil((PUBLISH_AFTER_MS - waited) / 3600_000)} h Probelauf veröffentlicht`; save(); return; }
  // Nur veröffentlichen, wenn der Prüfschlüssel dieses NUC im Paket steckt, sonst könnten Familien es nicht prüfen
  const myPub = rel.pubFromPem(fs.readFileSync(SIGNING_KEY, "utf8"));
  if (!process.env.LC_PUBLISH_REMOTE && !read(path.join(ROOT, "scripts", "release.js")).includes(myPub)) {
    status.publish = "wartet: öffentlicher Signierschlüssel ist noch nicht in scripts/release.js eingetragen (logs/release_signing.pub)";
    save();
    return;
  }
  try {
    const seq = Number(git(["log", "-1", "--format=%ct", running]));
    const version = git(["log", "-1", "--format=%cd", "--date=format:%Y.%m.%d", running]) + "-" + short(running);
    // Was nie im Paket stehen darf: eigener Programmpfad und eigene Adresse
    const forbidden = [ROOT, slash(ROOT), process.env.LC_PUBLIC_URL?.replace(/^https?:\/\//, "").replace(/\/$/, "")].filter(Boolean);
    const pkg = rel.buildPackage(ROOT, git(["ls-files"]).split("\n").filter(Boolean), { version, seq, commit: running, forbidden });
    const file = `releases/littlechat-${version}.zip`;
    const payload = { app: "LittleChat", version, seq, commit: running, file, size: pkg.zip.length, sha256: rel.sha256(pkg.zip), published: new Date().toISOString() };
    const signed = rel.signManifest(payload, fs.readFileSync(SIGNING_KEY, "utf8"));
    const remote = process.env.LC_PUBLISH_REMOTE || `git@github.com:${rel.RELEASE_REPO}.git`;
    const env = process.env.LC_PUBLISH_REMOTE ? {} : sshEnv(PUBLISH_KEY);
    if (!fs.existsSync(path.join(PUBLISH_DIR, ".git"))) {
      fs.rmSync(PUBLISH_DIR, { recursive: true, force: true });
      git(["clone", "--quiet", "--depth", "1", remote, PUBLISH_DIR], { env });
    }
    const pg = (args, o = {}) => git(args, { cwd: PUBLISH_DIR, env, ...o });
    if (pg(["fetch", "--quiet", "--depth", "1", "origin", "main"], { allowFail: true }) !== null) pg(["reset", "--hard", "--quiet", "FETCH_HEAD"]);
    else pg(["checkout", "--quiet", "-B", "main"]); // leeres Repo
    const out = (f, data) => { const p = path.join(PUBLISH_DIR, f); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, data); };
    out(file, pkg.zip);
    out("releases/littlechat-latest.zip", pkg.zip);
    out("latest.json", JSON.stringify(signed, null, 1) + "\n");
    for (const f of ["README.md", "LICENSE.txt"]) { const src = path.join(ROOT, "release", f); if (fs.existsSync(src)) out(f, fs.readFileSync(src)); }
    // nur die letzten 5 Pakete behalten (die Git-Historie hat ältere)
    const idxFile = path.join(PUBLISH_DIR, "releases", "index.json");
    const idx = readJson(idxFile, []).filter((x) => x.commit !== running);
    idx.push({ version, seq, commit: running, file, sha256: payload.sha256 });
    idx.sort((a, b) => b.seq - a.seq);
    for (const old of idx.slice(5)) fs.rmSync(path.join(PUBLISH_DIR, old.file), { force: true });
    out("releases/index.json", JSON.stringify(idx.slice(0, 5), null, 1) + "\n");
    pg(["add", "-A"]);
    pg(["-c", "user.name=LittleChat Prüf-NUC", "-c", "user.email=littlechat@users.noreply.github.com", "commit", "--quiet", "-m", `LittleChat ${version}`]);
    pg(["push", "--quiet", "origin", "HEAD:main"]);
    saved.published = running;
    status.publish = `veröffentlicht: ${version}`;
    lastPublishError = "";
    log(`Veröffentlicht: ${version}`);
  } catch (e) {
    if (e.message !== lastPublishError) log("Veröffentlichen fehlgeschlagen: " + e.message);
    lastPublishError = e.message;
    status.publish = "Veröffentlichen fehlgeschlagen: " + e.message;
    fs.rmSync(PUBLISH_DIR, { recursive: true, force: true }); // beim nächsten Mal frisch klonen
  }
  save();
}

// ------------------------------------------------------------------ Start
if (MODE === "git") {
  try { running = head(); } catch (e) { log("Git-Ordner nicht lesbar, Auto-Update aus: " + e.message); }
  if (running && saved.runningCommit !== running) { saved.runningCommit = running; saved.since = Date.now(); }
  ensurePublishKeys();
} else running = installedVersion().version || "?";
const canUpdate = MODE === "git" ? !!running : !!rel.RELEASE_PUBKEY;
log(`Aufpasser gestartet (${MODE === "git" ? short(running) : running}, Quelle ${MODE === "git" ? "Git" : "Release"}, Auto-Update ${ENABLED && canUpdate ? "an" : "aus"}` +
  (MODE === "git" && fs.existsSync(KEY_FILE) ? ", Deploy-Schlüssel vorhanden" : "") + (MODE === "release" && !rel.RELEASE_PUBKEY ? ", kein Prüfschlüssel eingebaut" : "") + ")");
startServer();
if (canUpdate) {
  if (ENABLED) {
    setTimeout(() => check(false), Math.min(30_000, EVERY_MS));
    setInterval(() => check(false), EVERY_MS);
  }
  setInterval(() => { // „update-now“ wirkt auch bei abgeschaltetem Auto-Update
    if (!fs.existsSync(FLAG_FILE)) return;
    try { fs.unlinkSync(FLAG_FILE); } catch {}
    log("Sofort-Update angefordert.");
    check(true);
  }, FLAG_POLL_MS);
  if (MODE === "release") setInterval(() => {
    if (!fs.existsSync(ROLLBACK_FLAG) || updating) return;
    try { fs.unlinkSync(ROLLBACK_FLAG); } catch {}
    log("Zurück auf die vorige Version angefordert.");
    rollbackManual();
  }, FLAG_POLL_MS);
  if (MODE === "git") setInterval(() => {
    if (!fs.existsSync(PUBLISH_FLAG) || updating) return;
    try { fs.unlinkSync(PUBLISH_FLAG); } catch {}
    log("Sofort-Veröffentlichung angefordert.");
    maybePublish(true).catch((e) => log("Veröffentlichen: " + e.message));
  }, FLAG_POLL_MS);
}
const quit = async () => { stopping = true; await stopServer(); process.exit(0); };
for (const sig of ["SIGINT", "SIGTERM"]) process.once(sig, quit);
process.on("message", (m) => { if (m?.t === "shutdown") quit(); });
process.on("disconnect", quit); // Starter beendet (Aufgabe gestoppt)
}
