// Server: hält die API-Schlüssel der KI-Anbieter, prüft Eltern-Login und Geräte-Freigaben,
// setzt Limits pro Kind durch und leitet Fragen an Claude (oder einen anderen gewählten Anbieter) weiter.
// Schlüssel verlassen diesen Prozess nie. Die Datenbank ist mit AES-256-GCM verschlüsselt.
// Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, mit keinem KI-Anbieter verbunden.

import http from "node:http";
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { execFile, spawn } from "node:child_process";
import { AsyncLocalStorage } from "node:async_hooks";
import { VOICES as PIPER_CATALOG } from "./scripts/setup-piper.mjs";
import * as AI from "./lib/providers.js";
import * as VOICES from "./lib/voices.js";
import * as AV from "./lib/avatars.js";
import * as TX from "./lib/texts.js";
import * as TOPIC from "./lib/topics.js";
import { QUESTIONS as KIDS_QUESTIONS, judge as judgeAnswer, testKid } from "./lib/kinderfragen.js";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
loadDotEnv(path.join(ROOT, ".env"));

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || "127.0.0.1";
const DATA_DIR = process.env.LC_DATA_DIR || path.join(ROOT, "data");
const APP_NAME = process.env.LC_APP_NAME || "LittleChat"; // Standard-Name, Eltern können ihn ändern
// Name, mit dem sich der Assistent meldet (Persona {{APP}}, Ansagen, Begrüßung). Eltern stellen ihn global ein.
const appName = () => db?.settings?.appName || APP_NAME;
const DB_FILE = path.join(DATA_DIR, "db.enc");
const LEGACY_DB_FILE = path.join(DATA_DIR, "db.json");
const KEY_FILE = path.join(DATA_DIR, "master.key");
const SETUP_CODE_FILE = path.join(DATA_DIR, "EINRICHTUNGSCODE.txt");
const BACKUP_DIR = process.env.LC_BACKUP_DIR || path.join(DATA_DIR, "backups");
const BACKUP_KEEP = Math.max(1, Number(process.env.LC_BACKUP_KEEP) || 30); // Tage (Timo 27.11.: 30 statt 14)
// Optionale lokale Spracherkennung: OpenAI-kompatibler Transkriptions-Endpunkt (z. B. ein lokaler Whisper-Server)
const STT_URL = process.env.LC_STT_URL || "";
const STT_MODEL = process.env.LC_STT_MODEL || "whisper-1";
const PUBLIC_DIR = path.join(ROOT, "public");
const PERSONA_FILE = path.join(ROOT, "kid_persona.md");
const KID_SAFETY_FILE = path.join(ROOT, "kid_safety.md");
const MODES_DIR = path.join(ROOT, "modes");
const SECURE_COOKIES = process.env.LC_INSECURE_COOKIES !== "1"; // nur für lokale Tests abschalten
const TRUST_PROXY = process.env.LC_TRUST_PROXY === "1";

// Schlüssel: entweder aus .env (ANTHROPIC_API_KEY) oder über den Einrichtungs-Assistenten,
// dann verschlüsselt in der Datenbank. Aus der Prozess-Umgebung entfernen, damit Kindprozesse ihn nicht erben.
// Weitere Anbieter: LC_OPENAI_API_KEY, LC_GEMINI_API_KEY, LC_MISTRAL_API_KEY, LC_XAI_API_KEY (oder im Eltern-Bereich).
const ENV_API_KEY = process.env.ANTHROPIC_API_KEY || "";
delete process.env.ANTHROPIC_API_KEY;
const ENV_KEYS = { anthropic: ENV_API_KEY };
for (const pid of ["openai", "gemini", "mistral", "xai"]) {
  const v = `LC_${pid.toUpperCase()}_API_KEY`;
  ENV_KEYS[pid] = process.env[v] || "";
  delete process.env[v];
}
// Anthropic-Schlüssel wie bisher (db.secrets.apiKey); keyInfo bleibt für die bestehende Anzeige
let anthropicKey = "";
let keyInfo = { source: null, last4: "" };
function useKey(key, source) {
  anthropicKey = key || "";
  keyInfo = key ? { source, last4: key.slice(-4) } : { source: null, last4: "" };
}

// Anbieter, Modelle und Preise: providers.json (pflegbar), überlagert von data/providers.json
const CATALOG = AI.loadCatalog(ROOT, DATA_DIR);
const DEFAULT_PROVIDER = "anthropic";
const DEFAULT_MODEL = "claude-haiku-5-5";
// Gelistete Modelle eines Schlüssels: nur Text-Chat-Modelle zeigen
const NON_CHAT = /(embed|tts|whisper|audio|realtime|transcribe|image|dall-e|moderation|search|vision-preview|ocr|live|codestral|devstral|veo|imagen|aqa|guard)/i;

function providerKey(pid) {
  if (pid === "anthropic") return anthropicKey;
  if (pid === "ollama") return "";
  return ENV_KEYS[pid] || db.secrets?.providers?.[pid]?.key || "";
}
function providerKeySource(pid) {
  if (pid === "anthropic") return keyInfo.source;
  if (pid === "ollama") return db.settings.ollama?.enabled ? "db" : null;
  return ENV_KEYS[pid] ? "env" : db.secrets?.providers?.[pid]?.key ? "db" : null;
}
const providerConfigured = (pid) => !!CATALOG.providers[pid] && (pid === "ollama" ? !!db.settings.ollama?.enabled : !!providerKey(pid));
// Claude ist sofort nutzbar. Andere Anbieter sind ohne Pflichttest wählbar, aber erst, wenn Eltern
// ausdrücklich bestätigt haben: "Ich habe verstanden, ungetestet" (Timo, 2026-11-26). Verantwortung: siehe README.
const providerAcked = (pid) => pid === "anthropic" || !!db.settings.providerAck?.[pid]?.at;
const providerUsable = (pid) => providerConfigured(pid) && providerAcked(pid);
const anyProvider = () => AI.PROVIDER_IDS.some(providerUsable);

// Wählbare Modelle eines Anbieters: Katalog plus die mit dem Schlüssel gefundenen (unbekannter Preis = hoch geschätzt)
function providerModels(pid) {
  const cat = CATALOG.providers[pid]?.models || {};
  const out = {};
  for (const [id, m] of Object.entries(cat)) out[id] = { label: m.label, known: true, default: !!m.default };
  for (const id of db.settings.discoveredModels?.[pid] || []) {
    if (out[id]) continue;
    if (pid !== "ollama" && NON_CHAT.test(id)) continue;
    out[id] = { label: pid === "ollama" ? `${id} · lokal · kostenlos` : `${id} · Preis unbekannt, wird hoch geschätzt`, known: pid === "ollama" };
  }
  return out;
}
const defaultModel = (pid) => {
  const ms = providerModels(pid);
  return Object.keys(ms).find((id) => ms[id].default) || Object.keys(ms)[0] || "";
};
const validChoice = (pid, model) => !!CATALOG.providers[pid] && !!model && !!providerModels(pid)[model];
const modelLabel = (pid, model) => `${CATALOG.providers[pid]?.label || pid} · ${(providerModels(pid)[model]?.label || model).split(" · ")[0]}`;

// Welcher Anbieter und welches Modell gilt für dieses Kind? Pro Kind abweichend, sonst global.
// Ist die Wahl nicht (mehr) nutzbar (Schlüssel entfernt), gilt global, dann Claude.
function choiceFor(kid) {
  const tries = [];
  if (kid?.provider && kid.model) tries.push([kid.provider, kid.model]);
  tries.push([db.settings.provider || DEFAULT_PROVIDER, db.settings.model]);
  tries.push([DEFAULT_PROVIDER, DEFAULT_MODEL]);
  for (const [provider, model] of tries) if (providerUsable(provider) && validChoice(provider, model)) return { provider, model };
  return null;
}
function costUsd(provider, model, usage) { return AI.costUsd(CATALOG, provider, model, usage); }
// Ein Aufruf beim gewählten Anbieter, mit dessen Schlüssel (nur hier im Server)
function aiChat(choice, opts) {
  return AI.chat({ catalog: CATALOG, provider: choice.provider, model: choice.model, key: providerKey(choice.provider), url: db.settings.ollama?.url, ...opts });
}
// Günstigstes Modell eines Anbieters für Titel und Zusammenfassungen (bleibt beim selben Anbieter, Datenschutz)
function summaryChoice(choice) {
  if (choice.provider === "ollama") return choice;
  const m = Object.entries(CATALOG.providers[choice.provider]?.models || {}).find(([, v]) => v.summary);
  return { provider: choice.provider, model: m ? m[0] : choice.model };
}

const MAX_TEXT = 600;              // Zeichen pro Frage
// Kontext-Steuerung: Claude bekommt die Persona (gecacht), eine laufende Zusammenfassung älterer Teile
// und nur ein Fenster der letzten Nachrichten. Ältere Nachrichten werden in die Zusammenfassung gefaltet.
const WINDOW_MIN = 12;             // so viele letzte Nachrichten bleiben immer wörtlich im Kontext
const WINDOW_MAX = 20;             // nie mehr als so viele wörtliche Nachrichten
const CONTEXT_CHAR_CAP = 16000;    // harte Obergrenze für den wörtlichen Verlauf (Zeichen)
const MEMORY_CHAR_CAP = 1500;      // harte Obergrenze für die Zusammenfassung
const MAX_CONVO_MESSAGES = 400;    // harte Obergrenze pro Gespräch
const TALK_PER_MIN = Number(process.env.LC_TALK_PER_MIN || 8); // Fragen pro Gerät und Minute
// Eltern-Anmeldung: läuft nach 3 Minuten ohne Aktion ab (LC_PARENT_IDLE_MIN), spätestens nach 8 Stunden.
// Das Cookie ist ein reines Sitzungs-Cookie (ohne Max-Age): App oder Browser schließen = abgemeldet.
const PARENT_IDLE_MS = Math.max(0.01, Number(process.env.LC_PARENT_IDLE_MIN) || 3) * 60_000;
const PARENT_MAX_MS = 8 * 3600_000;
const DEVICE_COOKIE_DAYS = 365;

// ---------------------------------------------------------------- Datenbank
const DEFAULT_DB = {
  parent: null,
  settings: { provider: "anthropic", model: "claude-haiku-5-5", globalMonthlyUsd: 20, persona: null, retentionDays: 0, wakeMinutes: 10, trashDays: 30 },
  kids: [],
  devices: [],
  convos: [],
  // Papierkorb: was Eltern gelöscht haben (Gespräche, Avatare, Kinder samt allem), bis trashDays alt.
  // Was das Kind gelöscht hat (zerplatzte Blasen, gelöschte Avatare), bleibt mit Markierung an seinem Platz
  // und zählt ebenfalls als Papierkorb.
  trash: [],
  avatars: [],
  usage: {},
  global: {},
  ttsUsage: {},
};
let db = structuredClone(DEFAULT_DB);
let writing = Promise.resolve();

// ---------------------------------------------------------------- Verschlüsselung
// Hauptschlüssel: LC_MASTER_KEY (Wiederherstellungsschlüssel) oder Datei data/master.key (wird beim ersten Start erzeugt).
// Er schützt Datenbank und Backups, z. B. wenn Backups in einer Cloud oder auf einem USB-Stick liegen.
const MAGIC = Buffer.from("LCDB1");
let masterKey = null;
const formatRecovery = (buf) => buf.toString("hex").toUpperCase().match(/.{4}/g).join("-");
function parseRecovery(s) {
  const hex = String(s).replace(/[^0-9a-f]/gi, "");
  if (hex.length !== 64) throw new Error("Wiederherstellungsschlüssel muss 64 Hex-Zeichen haben");
  return Buffer.from(hex, "hex");
}
async function loadMasterKey() {
  if (process.env.LC_MASTER_KEY) { masterKey = parseRecovery(process.env.LC_MASTER_KEY); delete process.env.LC_MASTER_KEY; return; }
  try { masterKey = parseRecovery(await fsp.readFile(KEY_FILE, "utf8")); }
  catch (e) {
    if (e.code !== "ENOENT") throw e;
    masterKey = crypto.randomBytes(32);
    await fsp.writeFile(KEY_FILE, formatRecovery(masterKey) + "\n", { mode: 0o600, flag: "wx" });
  }
}
function encryptBuf(plain, key = masterKey) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", key, iv);
  c.setAAD(MAGIC);
  const ct = Buffer.concat([c.update(plain), c.final()]);
  return Buffer.concat([MAGIC, iv, c.getAuthTag(), ct]);
}
function decryptBuf(buf, key = masterKey) {
  if (!buf.subarray(0, MAGIC.length).equals(MAGIC)) throw new Error("Keine verschlüsselte Datenbank");
  const iv = buf.subarray(5, 17), tag = buf.subarray(17, 33), ct = buf.subarray(33);
  const d = crypto.createDecipheriv("aes-256-gcm", key, iv);
  d.setAAD(MAGIC);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(ct), d.final()]);
}

async function loadDb() {
  await fsp.mkdir(DATA_DIR, { recursive: true, mode: 0o700 });
  await loadMasterKey();
  let raw = null;
  try { raw = JSON.parse(decryptBuf(await fsp.readFile(DB_FILE)).toString("utf8")); }
  catch (e) {
    if (e.code !== "ENOENT") throw new Error("Datenbank lässt sich nicht entschlüsseln. Passt master.key bzw. LC_MASTER_KEY? (" + e.message + ")");
    // Umzug von einer älteren, unverschlüsselten Version
    try { raw = JSON.parse(await fsp.readFile(LEGACY_DB_FILE, "utf8")); } catch (e2) { if (e2.code !== "ENOENT") throw e2; }
  }
  if (raw) {
    db = { ...structuredClone(DEFAULT_DB), ...raw };
    db.settings = { ...DEFAULT_DB.settings, ...db.settings };
    // Hat noch kein Elternteil ein Modell gewählt, gilt der aktuelle Standard (Haiku 5.5)
    if (!db.settings.modelChosen) { db.settings.provider = DEFAULT_PROVIDER; db.settings.model = DEFAULT_DB.settings.model; }
    db.settings.provider ||= DEFAULT_PROVIDER;
    // Gespräche werden standardmäßig nie automatisch gelöscht (Timo 27.11.). Frühere Versionen hatten 30 Tage
    // vorgegeben, ohne dass die Eltern das gewählt haben: dann gilt jetzt 0 = nie.
    if (!db.settings.retentionChosen) db.settings.retentionDays = 0;
    // Ältere Versionen kannten nur Claude: Modell pro Kind gehört dann zu Anthropic
    for (const k of db.kids) if (k.model && !k.provider) k.provider = "anthropic";
    // Doppelte Farben einmalig auf freie Farben verteilen
    const seen = new Set();
    for (const k of db.kids) {
      const c = (k.color || "").toLowerCase();
      if (seen.has(c)) {
        const free = KID_COLORS.find((x) => !db.kids.some((o) => (o.color || "").toLowerCase() === x));
        if (free) { console.log(`Farbe für ${k.name} geändert auf ${free}`); k.color = free; }
      }
      seen.add((k.color || "").toLowerCase());
    }
  }
  await saveDb();
  if (fs.existsSync(LEGACY_DB_FILE)) await fsp.unlink(LEGACY_DB_FILE);
}
function saveDb() {
  writing = writing.then(async () => {
    const tmp = DB_FILE + ".tmp";
    await fsp.writeFile(tmp, encryptBuf(Buffer.from(JSON.stringify(db))), { mode: 0o600 });
    await fsp.rename(tmp, DB_FILE);
  });
  return writing;
}

// Tägliche Sicherung der (verschlüsselten) Datenbank, die letzten BACKUP_KEEP Tage bleiben erhalten.
async function backupNow() {
  await writing;
  await fsp.mkdir(BACKUP_DIR, { recursive: true, mode: 0o700 });
  const target = path.join(BACKUP_DIR, `db-${localParts(new Date(), ENV_TZ).date}.enc`);
  await fsp.copyFile(DB_FILE, target);
  const files = (await fsp.readdir(BACKUP_DIR)).filter((f) => /^db-\d{4}-\d{2}-\d{2}\.enc$/.test(f)).sort();
  for (const f of files.slice(0, Math.max(0, files.length - BACKUP_KEEP))) await fsp.unlink(path.join(BACKUP_DIR, f));
  return target;
}

// Sicherungen werden nie nachträglich verändert. Zurückgeholt wird beim Wiederherstellen, und zwar nur das,
// was die Eltern auswählen (einzelne Kinder, Gespräche, allgemeine Einstellungen). Der Rest bleibt wie er ist.
const BACKUP_RE = /^db-\d{4}-\d{2}-\d{2}\.enc$/;
const SAFETY_FILE = "vor-wiederherstellung.enc"; // Stand direkt vor der letzten Wiederherstellung
async function readBackup(file) {
  if (!BACKUP_RE.test(file) && file !== SAFETY_FILE) throw Object.assign(new Error("Unbekannte Sicherung"), { status: 404 });
  let buf;
  try { buf = await fsp.readFile(path.join(BACKUP_DIR, file)); } catch { throw Object.assign(new Error("Sicherung nicht gefunden"), { status: 404 }); }
  try { return { ...structuredClone(DEFAULT_DB), ...JSON.parse(decryptBuf(buf).toString("utf8")) }; }
  catch { throw Object.assign(new Error("Sicherung lässt sich nicht entschlüsseln (anderer Wiederherstellungsschlüssel?)"), { status: 422 }); }
}
async function listBackups() {
  let files = [];
  try { files = (await fsp.readdir(BACKUP_DIR)).filter((f) => BACKUP_RE.test(f) || f === SAFETY_FILE); } catch { return []; }
  const out = [];
  for (const f of files) {
    const st = await fsp.stat(path.join(BACKUP_DIR, f));
    out.push({ file: f, date: BACKUP_RE.test(f) ? f.slice(3, 13) : null, at: st.mtime.toISOString(), safety: f === SAFETY_FILE });
  }
  return out.sort((x, y) => y.at.localeCompare(x.at));
}
function backupContents(b) {
  const nowKids = new Set(db.kids.map((k) => k.id)), nowConvos = new Set(db.convos.map((c) => c.id));
  return {
    kids: b.kids.map((k) => ({ id: k.id, name: k.name, color: k.color || null, missing: !nowKids.has(k.id),
      avatars: b.avatars.filter((a) => a.kidId === k.id).length })),
    convos: b.convos.slice().sort((x, y) => (y.updated || "").localeCompare(x.updated || ""))
      .map((c) => ({ id: c.id, kidId: c.kidId, title: c.title, emoji: c.emoji, updated: c.updated, count: (c.messages || []).length, missing: !nowConvos.has(c.id) })),
    settings: { provider: b.settings?.provider || null, model: b.settings?.model || null, persona: !!b.settings?.persona },
    avatars: (b.avatars || []).map((a) => ({ id: a.id, kidId: a.kidId, name: a.name, created: a.created, missing: !db.avatars.some((x) => x.id === a.id) })),
    // Nur Namen, nie die Schlüssel selbst
    keys: secretNames(b.secrets),
    devices: (b.devices || []).map((d) => ({ id: d.id, name: d.name, missing: !db.devices.some((x) => x.id === d.id) })),
  };
}
function secretNames(sec = {}) {
  const out = [];
  if (sec?.apiKey) out.push("Claude (Anthropic)");
  for (const pid of Object.keys(sec?.providers || {})) if (sec.providers[pid]?.key) out.push(CATALOG.providers[pid]?.label || pid);
  for (const [svc, slot] of Object.entries(TTS_SLOT)) if (sec?.[slot]) out.push({ google: "Google-Stimme", azure: "Azure-Stimme", elevenlabs: "ElevenLabs-Stimme", custom: "eigener Sprach-Server" }[svc]);
  return out;
}
async function restoreFromBackup(file, pick) {
  const b = await readBackup(file);
  await writing;
  // Vorher den aktuellen Stand sichern, damit auch eine Wiederherstellung rückgängig gemacht werden kann
  if (fs.existsSync(DB_FILE)) {
    await fsp.mkdir(BACKUP_DIR, { recursive: true, mode: 0o700 });
    await fsp.copyFile(DB_FILE, path.join(BACKUP_DIR, SAFETY_FILE));
  }
  // „Alles“: kompletter Stand der Sicherung. Das Eltern-Passwort bleibt das heutige, Verbrauchszähler laufen weiter.
  const wasAll = !!pick.all;
  if (wasAll) {
    pick = { kids: b.kids.map((k) => k.id), convos: b.convos.map((c) => c.id), avatars: (b.avatars || []).map((a) => a.id), settings: true, keys: true, devices: true };
    // Was es heute gibt, in der Sicherung aber nicht, kommt in den Papierkorb statt zu verschwinden
    const keep = new Set(pick.kids);
    for (const k of db.kids.filter((x) => !keep.has(x.id))) {
      trashPut("kid", k, { convos: db.convos.filter((c) => c.kidId === k.id), avatars: db.avatars.filter((a) => a.kidId === k.id), usage: db.usage[k.id] || null });
      db.convos = db.convos.filter((c) => c.kidId !== k.id);
      db.avatars = db.avatars.filter((a) => a.kidId !== k.id);
    }
    db.kids = db.kids.filter((k) => keep.has(k.id));
    for (const c of db.convos.filter((x) => !pick.convos.includes(x.id))) trashPut("convo", c);
    db.convos = db.convos.filter((c) => pick.convos.includes(c.id));
    for (const a of db.avatars.filter((x) => !pick.avatars.includes(x.id))) trashPut("avatar", a);
    db.avatars = db.avatars.filter((a) => pick.avatars.includes(a.id));
  }
  const kidIds = new Set(pick.kids || []), convoIds = new Set(pick.convos || []), avIds = new Set(pick.avatars || []);
  const r = { kids: 0, convos: 0, avatars: 0, settings: false, keys: false, devices: 0, skipped: 0, all: wasAll };
  for (const k of b.kids) {
    if (!kidIds.has(k.id)) continue;
    const i = db.kids.findIndex((x) => x.id === k.id);
    if (i >= 0) db.kids[i] = k;
    else {
      db.kids.push(k);
      if (b.usage[k.id] && !db.usage[k.id]) db.usage[k.id] = b.usage[k.id];
    }
    for (const a of b.avatars) if (a.kidId === k.id && !db.avatars.some((x) => x.id === a.id)) { db.avatars.push(a); r.avatars++; }
    r.kids++;
  }
  for (const c of b.convos) {
    if (!convoIds.has(c.id)) continue;
    if (!db.kids.some((k) => k.id === c.kidId)) { r.skipped++; continue; } // Kind fehlt und wurde nicht mit ausgewählt
    const i = db.convos.findIndex((x) => x.id === c.id);
    if (i >= 0) db.convos[i] = c; else db.convos.push(c);
    r.convos++;
  }
  for (const a of b.avatars || []) {
    if (!avIds.has(a.id) || db.avatars.some((x) => x.id === a.id)) continue;
    if (!db.kids.some((k) => k.id === a.kidId)) { r.skipped++; continue; }
    db.avatars.push(a); r.avatars++;
  }
  if (pick.keys && b.secrets) {
    db.secrets = structuredClone(b.secrets);
    if (!ENV_API_KEY) useKey(db.secrets.apiKey || null, "db");
    r.keys = true;
  }
  if (pick.devices) for (const d of b.devices || []) if (!db.devices.some((x) => x.id === d.id)) { db.devices.push(d); r.devices++; }
  if (pick.settings) { db.settings = { ...DEFAULT_DB.settings, ...b.settings }; r.settings = true; }
  // Was aus der Sicherung zurückkam, liegt nicht mehr zusätzlich im Papierkorb
  const back = new Set([...db.kids.map((k) => k.id), ...db.convos.map((c) => c.id), ...db.avatars.map((a) => a.id)]);
  db.trash = db.trash.filter((e) => !back.has(e.id));
  await saveDb();
  return r;
}

// ---------------------------------------------------------------- Hilfen
function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}
const sha256 = (s) => crypto.createHash("sha256").update(s).digest("hex");
const token = () => crypto.randomBytes(32).toString("base64url");
const id = () => crypto.randomBytes(8).toString("hex");

function hashPassword(pw, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(pw, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }).toString("hex");
  return { salt, hash };
}
function checkPassword(pw, rec) {
  if (!rec) return false;
  const { hash } = hashPassword(pw, rec.salt);
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(rec.hash, "hex"));
}

// Zeitzone: im Eltern-Bereich einstellbar; sonst TZ aus .env, sonst Europe/Berlin.
const validTz = (tz) => { try { new Intl.DateTimeFormat("de-DE", { timeZone: String(tz) }); return !!tz; } catch { return false; } };
const ENV_TZ = validTz(process.env.TZ) ? process.env.TZ : "Europe/Berlin";
// Die Zeitzone kommt vom Gerät (Header X-LC-TZ), die Uhrzeit aber immer vom Server:
// Ein Kind kann das Limit also nicht durch Verstellen der Tablet-Uhr umgehen. Ohne gültige Angabe: Zeitzone des Servers.
const requestCtx = new AsyncLocalStorage();
const timeZone = () => requestCtx.getStore()?.tz || ENV_TZ;
function localParts(d = new Date(), tz = timeZone()) {
  // formatToParts statt Text-Zerlegung: unabhängig von Gebietsschema, ICU-Version und Betriebssystem
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-US", {
    timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).formatToParts(d).map((x) => [x.type, x.value]));
  const hour = parts.hour === "24" ? "00" : parts.hour;
  const date = `${parts.year}-${parts.month}-${parts.day}`;
  return { date, month: date.slice(0, 7), time: `${hour}:${parts.minute}` };
}
// Erlaubtes Zeitfenster; "bis" vor "ab" (z. B. 07:00 bis 00:00 oder 20:00 bis 02:00) geht über Mitternacht.
// Verglichen wird in Minuten seit Mitternacht, nicht als Text ("6:00" vs. "13:00" wäre als Text falsch).
const toMin = (v) => { const m = String(v || "").match(/^(\d{1,2}):(\d{2})/); return m && +m[1] < 24 && +m[2] < 60 ? +m[1] * 60 + +m[2] : null; };
function inWindow(time, from, to) {
  const t = toMin(time), f = toMin(from), e = toMin(to);
  if (t === null || f === null || e === null || f === e) return true;
  return f < e ? t >= f && t < e : t >= f || t < e;
}
function ageFrom(birth) {
  const b = new Date(birth + "T00:00:00");
  const n = new Date();
  let a = n.getFullYear() - b.getFullYear();
  if (n.getMonth() < b.getMonth() || (n.getMonth() === b.getMonth() && n.getDate() < b.getDate())) a--;
  return Math.max(0, a);
}
function ageGuide(age) {
  if (age < 6) return "Sprich wie mit einem Kindergartenkind: sehr kurze, einfache Sätze, höchstens zwei bis drei Sätze pro Antwort, keine Fremdwörter, viele Vergleiche mit Dingen aus dem Alltag. Zahlen nur bis zwanzig verwenden.";
  if (age < 9) return "Sprich wie mit einem Grundschulkind der ersten bis dritten Klasse: einfache Sätze, schwierige Wörter sofort erklären, anschauliche Beispiele, drei bis vier Sätze pro Antwort.";
  if (age < 12) return "Sprich wie mit einem älteren Grundschulkind: gern etwas mehr Details und echte Fachbegriffe, die du kurz erklärst. Vier bis sechs Sätze sind in Ordnung, wenn das Thema es braucht.";
  return "Sprich wie mit einem Jugendlichen: sachlich, auf Augenhöhe, nicht kindisch. Erkläre Zusammenhänge gründlich, aber bleib beim Vorlesen gut verständlich.";
}

let personaDefault = "";
// Vergleichsform: Zeilenenden vereinheitlicht, Kommentare raus (die gehen ohnehin nie an die KI), Ränder getrimmt
const personaKey = (t) => String(t).replace(/\r\n/g, "\n").replace(/<!--[\s\S]*?-->/g, "").trim();
// Frühere Standard-Fassungen von kid_persona.md (SHA-256 der Vergleichsform). Wer eine davon wörtlich gespeichert hat,
// hat nichts angepasst: auch diese Fassung zählt als Standard, damit Verbesserungen ankommen, selbst wenn ein Gerät
// mehrere Updates auf einmal überspringt. Beim Ändern von kid_persona.md den bisherigen Wert hier ergänzen.
const FORMER_PERSONA_DEFAULTS = new Set([
  "edb9a40117aa670fcd942e4b81d37ff7e0e447c22ea343de215d7ac89f25393b", // erste Fassung (26.11.)
  "00dd96d47f080a9eac4a247475698a642960a0c90f938023022febcb4d56cddf", // Timos NUC-Fassung (26.11.), bis Rückfragen-Regel
  "5e8850d984da02377480d717ac895cbed252cf3911ea2c866c04801301f86ab8", // mit Sicherheitsabschnitt, bis Trennung in kid_safety.md (27.11.)
]);
const samePersona = (a, b) => personaKey(a) === personaKey(b) ||
  FORMER_PERSONA_DEFAULTS.has(crypto.createHash("sha256").update(personaKey(a)).digest("hex"));
function fillPlaceholders(tpl, kid) {
  const age = ageFrom(kid.birth);
  const today = new Intl.DateTimeFormat("de-DE", { dateStyle: "full", timeZone: timeZone() }).format(new Date());
  return tpl
    .replaceAll("{{NAME}}", kid.name)
    .replaceAll("{{AGE}}", String(age))
    .replaceAll("{{AGE_GUIDE}}", ageGuide(age))
    .replaceAll("{{TODAY}}", today)
    .replaceAll("{{APP}}", appName());
}
// Kinderschutz-Regeln (kid_safety.md, von Eltern anpassbar): stehen getrennt von der Persönlichkeit und werden
// immer im selben ersten Block mitgeschickt, egal wie die Persönlichkeit umgeschrieben wurde.
let safetyDefault = "";
const safetyText = () => TX.textKey(db.settings.safety || safetyDefault);
function personaFor(kid) {
  const persona = TX.textKey(db.settings.persona || personaDefault);
  return fillPlaceholders([persona, safetyText()].filter(Boolean).join("\n\n"), kid);
}

// ---------------------------------------------------------------- Gesprächsmodi
// Jeder Modus ist eine Markdown-Datei in modes/ (Kopf mit Name, Symbol, Farbe, Ansage; darunter die
// Anweisungen). Sie werden an die Persona angehängt; deren Sicherheitsregeln gelten immer zuerst.
// kid.modes: null = alle freigeschaltet (Standard, auch für später neu hinzukommende Modi), sonst Liste der Kennungen.
let MODES = [];
const DEFAULT_MODE = "erkunden";
function parseMode(id, raw) {
  const m = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!m) return null;
  const head = Object.fromEntries(m[1].split(/\r?\n/).map((l) => l.match(/^([\w-]+):\s*(.*)$/)).filter(Boolean).map((x) => [x[1], x[2].trim()]));
  const prompt = m[2].replace(/<!--[\s\S]*?-->/g, "").trim();
  if (!head.name || !prompt) return null;
  return { id, body: m[2].trim(), name: head.name, emoji: head.emoji || "💬", symbol: head.symbol || "", color: /^#[0-9a-f]{6}$/i.test(head.farbe) ? head.farbe : "#7a6f8c",
    order: Number(head.reihe) || 99, say: head.ansage || head.name, about: head.eltern || "", prompt,
    avatars: /^(ja|true|1)$/i.test(head.avatare || ""), figurTip: /^(ja|true|1)$/i.test(head["figur-tipp"] || "") };
}
async function loadModes() {
  let files = [];
  try { files = (await fsp.readdir(MODES_DIR)).filter((f) => /^[a-z0-9-]+\.md$/.test(f)); } catch {}
  const list = [];
  for (const f of files) {
    const mode = parseMode(f.slice(0, -3), await fsp.readFile(path.join(MODES_DIR, f), "utf8"));
    if (mode) list.push(mode); else console.warn(`  Hinweis: Modus ${f} ohne gültigen Kopf, wird ignoriert.`);
  }
  MODES = list.sort((a, b) => a.order - b.order || a.name.localeCompare(b.name));
}
const modeById = (id) => MODES.find((m) => m.id === id) || null;
// Anweisungen eines Modus: eigene Fassung der Eltern (settings.modeTexts) oder der Text aus modes/<id>.md
const modePrompt = (mode) => TX.textKey(db.settings.modeTexts?.[mode.id] || mode.prompt);

// ---------------------------------------------------------------- Bearbeitbare KI-Texte
// Ein Muster für Persönlichkeit, Kinderschutz-Regeln und Modi (siehe lib/texts.js). Speicherorte in der DB:
// settings.persona, settings.safety, settings.modeTexts[id]; dazu textBase (Standard, auf dem die eigene
// Fassung beruht) und textPrev (zuletzt verworfene eigene Fassung, einmal zurückholbar).
function textSlot(key) {
  if (key === "persona") return { key, kind: "persona", def: personaDefault, former: (t) => samePersona(t, personaDefault),
    get: () => db.settings.persona || null, set: (v) => { db.settings.persona = v; } };
  if (key === "safety") return { key, kind: "safety", def: safetyDefault,
    get: () => db.settings.safety || null, set: (v) => { db.settings.safety = v; } };
  const mode = key.startsWith("mode:") && modeById(key.slice(5));
  if (mode) return { key, kind: "mode", title: `${mode.emoji} ${mode.name}`, def: mode.body,
    get: () => db.settings.modeTexts?.[mode.id] || null,
    set: (v) => { db.settings.modeTexts ||= {}; if (v) db.settings.modeTexts[mode.id] = v; else delete db.settings.modeTexts[mode.id]; } };
  return null;
}
const textKeys = () => ["safety", "persona", ...MODES.map((m) => "mode:" + m.id)];
function textView(key) {
  const t = textSlot(key);
  const v = TX.view({ ...t, custom: t.get(), base: db.settings.textBase?.[key], prev: db.settings.textPrev?.[key] });
  // Ältere eigene Persönlichkeit mit eingebautem Sicherheitsabschnitt: der gilt weiter, die Regeln stehen jetzt aber getrennt
  if (key === "persona" && v.custom && /^##\s*Sicherheit/m.test(v.custom))
    v.note = "Deine Persönlichkeit enthält noch einen eigenen Abschnitt „Sicherheit“. Die Kinderschutz-Regeln stehen jetzt getrennt (Sicherheit › Kinderschutz-Regeln) und gelten immer. Den Abschnitt hier kannst du entfernen; er schadet aber nicht.";
  return v;
}
// Speichern: null/leer/Standard = Standard. Die bisherige eigene Fassung wird beim Zurücksetzen gemerkt.
function saveText(key, text, undo = false) {
  const t = textSlot(key);
  if (!t) throw Object.assign(new Error("Unbekannter Text"), { status: 404 });
  db.settings.textBase ||= {}; db.settings.textPrev ||= {};
  if (undo) text = db.settings.textPrev[key] ?? null;
  const before = t.get();
  const next = TX.normalize(text, t.def, t.former);
  if (before && !next) db.settings.textPrev[key] = before;
  if (next) { delete db.settings.textPrev[key]; if (next !== before) db.settings.textBase[key] = TX.textHash(t.def); }
  else delete db.settings.textBase[key];
  t.set(next);
}
function kidModes(kid) {
  if (!Array.isArray(kid.modes)) return MODES;
  const allowed = MODES.filter((m) => kid.modes.includes(m.id));
  return allowed.length ? allowed : MODES;
}
// Gewünschter Modus, wenn freigeschaltet; sonst Erkunden bzw. der erste freigeschaltete
function resolveMode(kid, wanted) {
  const allowed = kidModes(kid);
  return allowed.find((m) => m.id === wanted) || allowed.find((m) => m.id === DEFAULT_MODE) || allowed[0] || null;
}
const modePublic = ({ id, name, emoji, color, say, avatars }) => ({ id, name, emoji, color, say, avatars: !!avatars });

function kidUsage(kidId) {
  const { date, month } = localParts();
  const u = (db.usage[kidId] ||= {});
  if (u.date !== date) Object.assign(u, { date, questions: 0, tokens: 0, minutes: 0, lastTalk: 0 });
  u.months ||= {};
  u.months[month] ||= 0;
  return { u, month };
}
function globalMonth() {
  const { month } = localParts();
  db.global[month] ||= 0;
  return month;
}


// Prüft alle Limits; gibt eine kindgerechte Ansage zurück oder null.
// Verlängerung durch Eltern am Kindergerät: gilt nur heute, hebt Uhrzeit-, Minuten-, Fragen- und
// Token-Limit auf (nicht die Dollar-Budgets, die bleiben die harte Kostenbremse).
const EXTEND_CHOICES = [15, 30, 60, "today"];
function extensionActive(kidId) {
  const { u } = kidUsage(kidId);
  const e = u.ext;
  if (!e || e.date !== u.date) return null;
  if (e.allDay || Date.now() < e.until) return e;
  return null;
}
function limitMessage(kid, ignoreExtension = false) {
  const { u, month } = kidUsage(kid.id);
  const { time } = localParts();
  const gm = globalMonth();
  const ext = !ignoreExtension && extensionActive(kid.id);
  if (ext) {
    if (kid.monthlyUsd > 0 && u.months[month] >= kid.monthlyUsd || db.settings.globalMonthlyUsd > 0 && db.global[gm] >= db.settings.globalMonthlyUsd)
      return `Ich mache gerade eine längere Pause, ${kid.name}. Frag doch mal Mama oder Papa.`;
    return null;
  }
  if (!inWindow(time, kid.from, kid.to))
    return `Ich schlafe gerade, ${kid.name}. Wir können ${toMin(time) < toMin(kid.from) ? "heute" : "morgen"} ab ${kid.from.replace(/^0/, "")} Uhr wieder quatschen. Bis dann!`;
  if (kid.minutesPerDay > 0 && u.minutes >= kid.minutesPerDay)
    return `Für heute ist unsere Quatschzeit vorbei, ${kid.name}. Das hat Spaß gemacht! Morgen geht es weiter.`;
  if (kid.questionsPerDay > 0 && u.questions >= kid.questionsPerDay)
    return `Du hast heute schon so viele tolle Fragen gestellt, ${kid.name}! Mein Kopf braucht jetzt eine Pause. Morgen wieder!`;
  if (kid.tokensPerDay > 0 && u.tokens >= kid.tokensPerDay)
    return `Puh, ich habe heute schon ganz viel geredet, ${kid.name}. Meine Stimme macht jetzt Pause. Morgen erzähle ich dir wieder was!`;
  if (kid.monthlyUsd > 0 && u.months[month] >= kid.monthlyUsd)
    return `Ich mache gerade eine längere Pause, ${kid.name}. Frag doch mal Mama oder Papa.`;
  if (db.settings.globalMonthlyUsd > 0 && db.global[gm] >= db.settings.globalMonthlyUsd)
    return `Ich mache gerade eine längere Pause, ${kid.name}. Frag doch mal Mama oder Papa.`;
  return null;
}
function trackTime(kidId) {
  const { u } = kidUsage(kidId);
  const now = Date.now();
  const gap = now - (u.lastTalk || 0);
  // Zeit zwischen zwei Fragen zählt als Gesprächszeit, wenn die Pause unter 5 Min. liegt;
  // sonst zählt die Frage pauschal als 1 Minute.
  u.minutes = Math.round(((u.minutes || 0) + (gap < 5 * 60_000 ? gap / 60_000 : 1)) * 100) / 100;
  u.lastTalk = now;
}

// ---------------------------------------------------------------- Rate-Limits
const buckets = new Map();
function rateLimit(key, max, perMs) {
  const now = Date.now();
  const b = buckets.get(key) || { n: 0, reset: now + perMs };
  if (now > b.reset) { b.n = 0; b.reset = now + perMs; }
  b.n++;
  buckets.set(key, b);
  return b.n <= max;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of buckets) if (now > b.reset) buckets.delete(k);
  for (const [k, s] of parentSessions) if (now > s.exp || now > s.max) parentSessions.delete(k);
}, 60_000).unref();
setInterval(() => { if (purgeOldConvos()) saveDb(); }, 60 * 60_000).unref();

// ---------------------------------------------------------------- Gespräche (Erinnerungsblasen)
// Papierkorb leeren, was älter als trashDays ist (endgültig; die Sicherungen bleiben unverändert)
// Vom Kind zerplatzt bleibt für Eltern unter „Gespräche“, bis sie es als gelesen markieren (parentDoneAt).
// Erst dann liegt es im Papierkorb, und die Frist läuft ab diesem Zeitpunkt (Timo 27.11.).
const kidTrashedConvo = (c) => !!c.kidPoppedAt && !c.poppedByAvatar && !!c.parentDoneAt;
function purgeTrash() {
  const cutoff = Date.now() - (Number(db.settings.trashDays) || 30) * 86400_000;
  const old = (iso) => Date.parse(iso) < cutoff;
  const n = db.trash.length + db.convos.length + db.avatars.length;
  db.trash = db.trash.filter((e) => !old(e.at));
  db.convos = db.convos.filter((c) => !(kidTrashedConvo(c) && old(c.parentDoneAt)));
  for (const a of db.avatars.filter((x) => x.hiddenAt && old(x.hiddenAt))) deleteAvatar(a);
  return db.trash.length + db.convos.length + db.avatars.length !== n;
}
function trashPut(type, item, extra = {}) {
  db.trash.push({ type, id: item.id, at: new Date().toISOString(), by: "Eltern", item, ...extra });
}
function trashView() {
  const kidName = (id) => db.kids.find((k) => k.id === id)?.name || db.trash.find((e) => e.type === "kid" && e.id === id)?.item.name || "?";
  const out = [];
  for (const e of db.trash) {
    if (e.type === "convo") out.push({ id: e.id, type: "convo", at: e.at, by: e.by, kidId: e.item.kidId, kidName: kidName(e.item.kidId), title: e.item.title, emoji: e.item.emoji, count: e.item.messages?.length || 0 });
    if (e.type === "avatar") out.push({ id: e.id, type: "avatar", at: e.at, by: e.by, kidId: e.item.kidId, kidName: kidName(e.item.kidId), title: e.item.name, svg: AV.styledSvg(e.item.svg) });
    if (e.type === "kid") out.push({ id: e.id, type: "kid", at: e.at, by: e.by, kidId: e.id, kidName: e.item.name, title: e.item.name, color: e.item.color, convos: e.convos.length, avatars: e.avatars.length });
  }
  for (const c of db.convos) if (kidTrashedConvo(c)) out.push({ id: c.id, type: "convo", at: c.parentDoneAt, by: "Kind", kidId: c.kidId, kidName: kidName(c.kidId), title: c.title, emoji: c.emoji, count: c.messages.length });
  for (const a of db.avatars) if (a.hiddenAt) out.push({ id: a.id, type: "avatar", at: a.hiddenAt, by: "Kind", kidId: a.kidId, kidName: kidName(a.kidId), title: a.name, svg: AV.styledSvg(a.svg) });
  const days = Number(db.settings.trashDays) || 30;
  return out.map((x) => ({ ...x, until: new Date(Date.parse(x.at) + days * 86400_000).toISOString() })).sort((a, b) => b.at.localeCompare(a.at));
}
// Zurückholen: Eltern-Gelöschtes wandert zurück, vom Kind Gelöschtes wird wieder sichtbar
function trashRestore(id) {
  const e = db.trash.find((x) => x.id === id);
  if (e) {
    const kidOk = (kidId) => db.kids.some((k) => k.id === kidId);
    if (e.type !== "kid" && !kidOk(e.item.kidId)) return "Das Kind liegt selbst im Papierkorb. Bitte zuerst das Kind zurückholen.";
    if (e.type === "convo") db.convos.push(e.item);
    if (e.type === "avatar") db.avatars.push(e.item);
    if (e.type === "kid") {
      db.kids.push(e.item);
      db.convos.push(...e.convos.filter((c) => !db.convos.some((x) => x.id === c.id)));
      db.avatars.push(...e.avatars.filter((a) => !db.avatars.some((x) => x.id === a.id)));
      if (e.usage && !db.usage[e.id]) db.usage[e.id] = e.usage;
    }
    db.trash = db.trash.filter((x) => x !== e);
    return null;
  }
  const c = db.convos.find((x) => x.id === id && kidTrashedConvo(x));
  if (c) { delete c.kidPoppedAt; delete c.parentDoneAt; return null; }
  const a = db.avatars.find((x) => x.id === id && x.hiddenAt);
  if (a) { delete a.hiddenAt; return null; }
  return "Nicht im Papierkorb";
}
function trashDelete(id) {
  const e = db.trash.find((x) => x.id === id);
  if (e) { db.trash = db.trash.filter((x) => x !== e); return true; }
  const c = db.convos.find((x) => x.id === id && kidTrashedConvo(x));
  if (c) { db.convos = db.convos.filter((x) => x !== c); return true; }
  const a = db.avatars.find((x) => x.id === id && x.hiddenAt);
  if (a) { deleteAvatar(a); return true; }
  return false;
}

function purgeOldConvos() {
  const trashChanged = purgeTrash();
  const days = Number(db.settings.retentionDays) || 0;
  if (days <= 0) return trashChanged;
  const cutoff = Date.now() - days * 86400_000;
  // Alte Gespräche wandern in den Papierkorb, nicht gleich endgültig weg (Timo 27.11.)
  const old = db.convos.filter((c) => Date.parse(c.updated) < cutoff && !kidTrashedConvo(c));
  if (!old.length) return trashChanged;
  for (const c of old) trashPut("convo", c, { by: "Automatisch" });
  const gone = new Set(old.map((c) => c.id));
  db.convos = db.convos.filter((c) => !gone.has(c.id));
  return true;
}
const parentSeenPending = (c) => !!c.parentSeenAt && (!c.kidNotifiedAt || c.kidNotifiedAt < c.parentSeenAt);
function bubbleView(c) {
  // Bewusst ohne Hinweis, ob Eltern das Gespräch gesehen haben: das erfährt das Kind erst beim Fortsetzen.
  return { id: c.id, emoji: c.emoji, title: c.title, recap: c.recap, updated: c.updated, minutes: convoMinutes(c), mode: c.mode || null,
    ...(c.splitFrom ? { splitFrom: c.splitFrom } : {}) };
}
// Gesprächszeit einer Seifenblase, wie beim Tageslimit gezählt: Abstand zwischen zwei Fragen zählt,
// wenn er unter 5 Minuten liegt, sonst zählt die Frage pauschal als 1 Minute.
function convoMinutes(c) {
  let total = 0, last = 0;
  for (const m of c.messages) {
    if (m.role !== "user") continue;
    const t = Date.parse(m.at) || 0;
    const gap = t - last;
    total += last && gap >= 0 && gap < 5 * 60_000 ? gap / 60_000 : 1;
    last = t;
  }
  return Math.round(total * 10) / 10;
}

// Welche Nachrichten wörtlich an Claude gehen (Rest steckt in convo.memory)
function contextWindow(convo) {
  const n = convo.messages.length;
  let start = Math.max(convo.summarizedUpTo || 0, n - WINDOW_MAX);
  let ctx = convo.messages.slice(start).filter((m) => !m.refused);
  let chars = ctx.reduce((a, m) => a + m.text.length, 0);
  while (ctx.length && (chars > CONTEXT_CHAR_CAP || ctx[0].role !== "user")) { chars -= ctx[0].text.length; ctx.shift(); }
  return ctx;
}
const needsMemory = (c) => c.messages.length - WINDOW_MIN - (c.summarizedUpTo || 0) >= 6;
const summarizing = new Set();
async function summarize(convo) {
  // Ein günstiger Aufruf liefert: Emoji, Titel und Vorlese-Satz für die Seifenblase
  // sowie die laufende Zusammenfassung (memory) für alles, was aus dem Kontextfenster fällt.
  if (summarizing.has(convo.id)) return;
  summarizing.add(convo.id);
  const fmt = (ms) => ms.map((m) => (m.role === "user" ? "Kind: " : appName() + ": ") + m.text.slice(0, 1200)).join("\n");
  const n = convo.messages.length;
  const upto = Math.max(convo.summarizedUpTo || 0, n - WINDOW_MIN);
  const older = convo.messages.slice(convo.summarizedUpTo || 0, upto);
  const recent = convo.messages.slice(upto).slice(-WINDOW_MIN);
  const transcript = (modeById(convo.mode) ? `Gesprächsmodus: ${modeById(convo.mode).name}\n\n` : "") +
    `Bisherige Zusammenfassung:\n${convo.memory || "(noch keine)"}\n\n` +
    `Ältere Nachrichten, die jetzt in die Zusammenfassung sollen:\n${older.length ? fmt(older) : "(keine)"}\n\n` +
    `Neueste Nachrichten (nur für Titel und Vorlese-Satz):\n${fmt(recent)}`;
  try {
    const kid = db.kids.find((k) => k.id === convo.kidId);
    const choice = kid && choiceFor(kid);
    if (!choice) return;
    const sc = summaryChoice(choice);
    const schema = {
      type: "object", additionalProperties: false, required: ["emoji", "title", "recap", "memory"],
      properties: {
        emoji: { type: "string", description: "Genau ein kindgerechtes Emoji, das das Thema zeigt" },
        title: { type: "string", description: "Titel mit höchstens 4 Wörtern, auf Deutsch" },
        recap: { type: "string", description: "Ein Satz zum Vorlesen, beginnt mit 'Wir haben über' und endet mit 'gesprochen.'" },
        memory: { type: "string", description: "Bisherige Zusammenfassung plus ältere Nachrichten, verdichtet auf höchstens 120 Wörter: Themen, was das Kind schon weiß, offene Fragen, laufende Spiele oder Geschichten. Nur der aktuelle Stand: Hat sich etwas geändert (zum Beispiel etwas wurde bestätigt), ersetze den alten Satz, statt beide stehen zu lassen. Keine widersprüchlichen Angaben." },
      } };
    const r = await aiChat(sc, {
      maxTokens: 1500,
      json: { schema, description: Object.entries(schema.properties).map(([k, v]) => `"${k}" (${v.description})`).join(", ") },
      system: "Du fasst Gespräche zwischen einem Kind und " + appName() + " zusammen: für eine Erinnerungs-Blase und als Gedächtnis für die Fortsetzung. Kindgerecht, sachlich, ohne persönliche Daten wie Adressen oder Nachnamen.",
      messages: [{ role: "user", content: transcript }],
    });
    const kidRec = kidUsage(convo.kidId);
    const cost = costUsd(sc.provider, sc.model, r.usage);
    kidRec.u.months[kidRec.month] += cost;
    db.global[globalMonth()] += cost;
    // Manche Anbieter packen JSON trotzdem in ```json … ```
    const txt = (r.text || "{}").replace(/^\s*```(?:json)?\s*|\s*```\s*$/g, "");
    const j = JSON.parse(txt.slice(txt.indexOf("{"), txt.lastIndexOf("}") + 1) || "{}");
    convo.emoji = String(j.emoji || "💬").slice(0, 8);
    convo.title = String(j.title || convo.title).slice(0, 40);
    // Avatar-Gespräche: Logo bleibt das Symbol des Knopfs
    const avMode = modeById(convo.mode);
    if (avMode?.avatars) convo.emoji = avMode.emoji;
    convo.recap = String(j.recap || "").slice(0, 200);
    if (j.memory) { convo.memory = String(j.memory).slice(0, MEMORY_CHAR_CAP); convo.summarizedUpTo = Math.min(upto, convo.messages.length); }
    await saveDb();
  } catch (e) {
    console.error("[summary]", e instanceof SyntaxError ? "ungültiges JSON" : AI.errorText(e));
  } finally {
    summarizing.delete(convo.id);
    // Während der Zusammenfassung wurde das Gespräch geteilt (Themenwechsel): noch einmal, passend zum neuen Stand
    if (convo.resummarize) { delete convo.resummarize; summarize(convo); }
  }
}

// ---------------------------------------------------------------- Themenwechsel (neue Seifenblase)
// Nach jeder Antwort prüft ein günstiger Aufruf, ob die neueste Kinder-Frage noch zum Thema (Logo) der Blase passt.
// Logik und Trägheit stehen in lib/topics.js. Avatar-Gespräche werden nie geteilt (Runden zählen, Blase platzt am Ende).
const topicChecks = new Map(); // convo.id -> laufende Prüfung; die nächste Frage wartet darauf
const topicSplitOn = () => db.settings.topicSplit !== false;
function resummarize(c) { if (summarizing.has(c.id)) c.resummarize = true; else summarize(c); }
function watchTopic(kid, choice, convo, mode, resum) {
  const n = convo.messages.length;
  if (!topicSplitOn() || mode?.avatars || convo.avatarEdit || n < TOPIC.MIN_KEEP + 2 || convo.messages[n - 1].refused) {
    if (resum) summarize(convo);
    return;
  }
  const run = (async () => {
    let did = null;
    try {
      const sc = summaryChoice(choice);
      const from = TOPIC.checkFrom(convo);
      const r = await aiChat(sc, {
        maxTokens: 300, signal: AbortSignal.timeout(15_000),
        json: { schema: TOPIC.SCHEMA, description: Object.entries(TOPIC.SCHEMA.properties).map(([k, v]) => `"${k}" (${v.description})`).join(", ") },
        system: TOPIC.SYSTEM,
        messages: [{ role: "user", content: TOPIC.prompt(convo, { from, ai: appName(), modeName: modeById(convo.mode)?.name }) }],
      });
      const kidRec = kidUsage(convo.kidId);
      const cost = costUsd(sc.provider, sc.model, r.usage);
      kidRec.u.months[kidRec.month] += cost;
      db.global[globalMonth()] += cost;
      // Inzwischen weitergesprochen, zerplatzt oder gelöscht: nichts ändern, die nächste Antwort prüft neu
      if (convo.messages.length !== n || convo.kidPoppedAt || !db.convos.includes(convo)) return;
      const d = TOPIC.decide(convo, TOPIC.parse(r.text));
      if (d.clear) delete convo.topicWatch;
      if (d.watch) convo.topicWatch = d.watch;
      if (d.split !== undefined) {
        const fresh = TOPIC.split(convo, d.split, { id: id(), emoji: d.emoji, title: d.title });
        db.convos.push(fresh);
        did = fresh;
      }
      if (d.clear || d.watch || did) await saveDb();
    } catch (e) {
      console.error("[thema]", e instanceof SyntaxError ? "ungültiges JSON" : AI.errorText(e));
    } finally {
      topicChecks.delete(convo.id);
      // Nach dem Teilen bekommen beide Blasen frische Titel, Emojis und Vorlese-Sätze
      if (did) { resummarize(convo); resummarize(did); } else if (resum) summarize(convo);
    }
  })();
  topicChecks.set(convo.id, run);
}

// ---------------------------------------------------------------- Sitzungen
const parentSessions = new Map(); // sha256(token) -> { exp }
let setupCode = null;

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
// maxAgeSec === null: Sitzungs-Cookie, das der Browser beim Schließen verwirft
function cookie(name, value, maxAgeSec) {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Strict${maxAgeSec === null ? "" : `; Max-Age=${maxAgeSec}`}${SECURE_COOKIES ? "; Secure" : ""}`;
}
// touch=false: nur nachsehen, die Anmeldung dadurch nicht verlängern (z. B. Startbildschirm des Kindes)
function isParent(req, touch = true) {
  const t = parseCookies(req).lc_parent;
  if (!t) return false;
  const key = sha256(t), s = parentSessions.get(key);
  const now = Date.now();
  if (!s || now > s.exp || now > s.max) { if (s) parentSessions.delete(key); return false; }
  if (touch) s.exp = Math.min(now + PARENT_IDLE_MS, s.max);
  return true;
}
const PAIR_CODE_TTL = 10 * 60_000;
const pairCodes = new Map(); // nur im Speicher: Code -> { exp, name }
function createDevice(req, name, touch) {
  const t = token();
  const prev = findDevice(req);
  if (prev) db.devices = db.devices.filter((d) => d.id !== prev.id); // erneute Freigabe ersetzt den alten Eintrag
  const ua = describeUa(req.headers["user-agent"]);
  if (touch && ua.os === "macOS") { ua.type = "Tablet"; ua.os = "iPadOS"; } // iPad im Desktop-Modus
  const dev = { id: id(), name: String(name || "").trim().slice(0, 40) || `${ua.type} (${ua.os})`.slice(0, 40), tokenHash: sha256(t),
    created: new Date().toISOString(), lastSeen: new Date().toISOString(), ua, via: accessVia(req) };
  db.devices.push(dev);
  return { dev, setCookie: cookie("lc_device", t, DEVICE_COOKIE_DAYS * 86400) };
}
const LEGACY_NAME = /^(Win32|Win64|MacIntel|iPad|iPhone|Linux( armv\w+| aarch64| x86_64| i686)?|Gerät)$/i;
function findDevice(req) {
  const t = parseCookies(req).lc_device;
  return t ? db.devices.find((x) => x.tokenHash === sha256(t)) || null : null;
}
function deviceOf(req) {
  const d = findDevice(req);
  if (d) {
    d.lastSeen = new Date().toISOString();
    const ua = describeUa(req.headers["user-agent"]);
    if (!(d.ua?.os?.startsWith("iPadOS") && ua.os === "macOS")) d.ua = ua; // iPads melden sich in Safari als Mac
    // Ältere Freigaben hießen nach navigator.platform ("Win32", "Linux armv8l" …): sinnvollen Namen geben
    if (LEGACY_NAME.test(d.name) && d.ua.os !== "Unbekannt") d.name = `${d.ua.type} (${d.ua.os})`.slice(0, 40);
    d.via = accessVia(req);
    if (requestCtx.getStore()?.tz) d.tz = requestCtx.getStore().tz;
  }
  return d || null;
}
// Grobe, datensparsame Geräteerkennung aus dem User-Agent (kein Fingerprinting, nur fürs Eltern-Menü).
function describeUa(raw) {
  const ua = String(raw || "").slice(0, 400);
  let os = "Unbekannt", type = "Computer", browser = "Unbekannt";
  const v = (re) => (ua.match(re)?.[1] || "").replace(/_/g, ".");
  if (/iPad/.test(ua) || (/Macintosh/.test(ua) && /Mobile\//.test(ua))) { os = "iPadOS " + v(/OS (\d+[_.]\d+)/); type = "Tablet"; }
  else if (/iPhone|iPod/.test(ua)) { os = "iOS " + v(/OS (\d+[_.]\d+)/); type = "Handy"; }
  else if (/Android/.test(ua)) { os = "Android " + v(/Android (\d+(?:\.\d+)?)/); type = /Mobile/.test(ua) ? "Handy" : "Tablet"; }
  else if (/CrOS/.test(ua)) os = "ChromeOS";
  else if (/Windows NT/.test(ua)) os = "Windows";
  else if (/Mac OS X/.test(ua)) os = "macOS";
  else if (/Linux/.test(ua)) os = "Linux";
  if (/Edg\//.test(ua)) browser = "Edge " + v(/Edg\/(\d+)/);
  else if (/SamsungBrowser\//.test(ua)) browser = "Samsung Internet " + v(/SamsungBrowser\/(\d+)/);
  else if (/Firefox\/|FxiOS\//.test(ua)) browser = "Firefox " + v(/(?:Firefox|FxiOS)\/(\d+)/);
  else if (/CriOS\//.test(ua)) browser = "Chrome " + v(/CriOS\/(\d+)/);
  else if (/Chrome\//.test(ua)) browser = "Chrome " + v(/Chrome\/(\d+)/);
  else if (/Safari\//.test(ua)) browser = "Safari " + v(/Version\/(\d+)/);
  return { type, os: os.trim(), browser: browser.trim() };
}
// Über welchen Weg das Gerät kommt: direkt am Server (localhost) oder über Tailscale/Proxy (Hostname).
function accessVia(req) {
  const host = String((TRUST_PROXY && req.headers["x-forwarded-host"]) || req.headers.host || "").slice(0, 100);
  return /^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host) ? "lokal am Server" : host.replace(/:\d+$/, "");
}
function clientIp(req) {
  if (TRUST_PROXY && req.headers["x-forwarded-for"]) return String(req.headers["x-forwarded-for"]).split(",")[0].trim();
  return req.socket.remoteAddress || "?";
}

// ---------------------------------------------------------------- HTTP
const SECURITY_HEADERS = {
  "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; media-src 'self' blob: data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Permissions-Policy": "microphone=(self), camera=(), geolocation=()",
  "Cross-Origin-Opener-Policy": "same-origin",
};
function send(res, status, body, headers = {}) {
  const isJson = typeof body !== "string";
  res.writeHead(status, {
    ...SECURITY_HEADERS,
    "Content-Type": isJson ? "application/json; charset=utf-8" : "text/plain; charset=utf-8",
    "Cache-Control": "no-store",
    ...headers,
  });
  res.end(isJson ? JSON.stringify(body) : body);
}
async function readRaw(req, limit) {
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw Object.assign(new Error("zu groß"), { status: 413 });
    chunks.push(c);
  }
  return Buffer.concat(chunks);
}
async function readJson(req, limit = 64 * 1024) {
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw Object.assign(new Error("zu groß"), { status: 413 });
    chunks.push(c);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8")); }
  catch { throw Object.assign(new Error("ungültiges JSON"), { status: 400 }); }
}

const MIME = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml", ".png": "image/png", ".webmanifest": "application/manifest+json", ".json": "application/json",
};
async function serveStatic(req, res, urlPath) {
  const rel = urlPath === "/" ? "/index.html" : urlPath;
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return send(res, 404, "Nicht gefunden");
  try {
    const data = await fsp.readFile(file);
    // Immer neu prüfen (no-cache + ETag): Updates kommen sofort an, unveränderte Dateien kosten nur ein 304.
    // Früher durfte app.js eine Stunde aus dem Cache kommen, dann passten neue Seite und alter Code nicht zusammen.
    const etag = '"' + crypto.createHash("sha1").update(data).digest("base64url") + '"';
    const headers = { ...SECURITY_HEADERS, "Content-Type": MIME[path.extname(file)] || "application/octet-stream", "Cache-Control": "no-cache", ETag: etag };
    if (req.headers["if-none-match"] === etag) { res.writeHead(304, headers); return res.end(); }
    res.writeHead(200, headers);
    res.end(data);
  } catch {
    send(res, 404, "Nicht gefunden");
  }
}

// Anleitungen pro KI-Anbieter (docs/anbieter/*.md), als schlichte Seite für Eltern.
// Bewusst winziger Markdown-Umsetzer: Überschriften, Absätze, Listen, fett, Code, Links.
const GUIDE_DIR = path.join(ROOT, "docs", "anbieter");
async function serveGuide(res, name) {
  // /anleitung/openai = KI-Anbieter (docs/anbieter), /anleitung/stimmen/google = Stimmen-Dienst (docs/stimmen)
  const sm = name.match(/^stimmen\/([a-z]+)$/);
  if (!sm && !/^[a-z]+$/.test(name)) return send(res, 404, "Nicht gefunden");
  let md;
  try { md = await fsp.readFile(sm ? path.join(ROOT, "docs", "stimmen", sm[1] + ".md") : path.join(GUIDE_DIR, name + ".md"), "utf8"); } catch { return send(res, 404, "Nicht gefunden"); }
  const esc = (t) => t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const inline = (t) => esc(t)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>")
    .replace(/\[([^\]]+)\]\((https:\/\/[^)\s]+|\/anleitung\/(?:stimmen\/)?[a-z]+)\)/g, (_, txt, href) => `<a href="${href}"${href.startsWith("https:") ? ' target="_blank" rel="noopener"' : ""}>${txt}</a>`);
  const out = [];
  let list = null;
  const close = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (const line of md.replace(/<!--[\s\S]*?-->/g, "").split(/\r?\n/)) {
    let m;
    if ((m = line.match(/^(#{1,3})\s+(.*)/))) { close(); out.push(`<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`); }
    else if ((m = line.match(/^\s*(\d+\.|[-*])\s+(.*)/))) {
      const t = /\d/.test(m[1]) ? "ol" : "ul";
      if (list !== t) { close(); out.push(`<${t}>`); list = t; }
      out.push(`<li>${inline(m[2])}</li>`);
    } else if ((m = line.match(/^>\s?(.*)/))) { close(); out.push(`<p class="note">${inline(m[1])}</p>`); }
    else if (line.trim()) { close(); out.push(`<p>${inline(line)}</p>`); }
    else close();
  }
  close();
  const title = (md.match(/^#\s+(.*)/m)?.[1] || "Anleitung").replace(/[<>&"]/g, "");
  const html = `<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} · ${esc(appName())}</title><link rel="stylesheet" href="/anleitung.css"></head><body><main>${out.join("\n")}<p class="back">Fertig? Diesen Tab schließen, der Eltern-Bereich ist im anderen Tab noch offen.</p></main></body></html>`;
  res.writeHead(200, { ...SECURITY_HEADERS, "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache" });
  res.end(html);
}

// Echtes Kalenderdatum, nicht in der Zukunft, nicht vor 1900. Über 18 ist erlaubt (z. B. Eltern testen selbst).
function birthProblem(birth) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(birth)) return "Geburtsdatum ungültig";
  const d = new Date(birth + "T00:00:00Z");
  if (isNaN(d) || d.toISOString().slice(0, 10) !== birth) return "Geburtsdatum ungültig";
  if (+birth.slice(0, 4) < 1900) return "Geburtsdatum ungültig";
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: timeZone() }).format(new Date());
  if (birth > today) return "Das Geburtsdatum liegt in der Zukunft.";
  return "";
}

function sanitizeKid(b, existing = {}) {
  const name = String(b.name ?? existing.name ?? "").trim().slice(0, 30);
  const birth = String(b.birth ?? existing.birth ?? "");
  if (!name) throw Object.assign(new Error("Name fehlt"), { status: 400 });
  const bad = birthProblem(birth);
  if (bad) throw Object.assign(new Error(bad), { status: 400 });
  const num = (v, d, max) => Math.min(max, Math.max(0, Number.isFinite(Number(v)) ? Number(v) : d));
  // akzeptiert "6:00", "06:00" und "06:00:00", speichert immer "06:00"
  const hhmm = (v) => { const m = toMin(v); return m === null ? "" : `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`; };
  return {
    id: existing.id || id(),
    name,
    birth,
    color: /^#[0-9a-f]{6}$/i.test(b.color) ? b.color : existing.color || nextKidColor(),
    questionsPerDay: num(b.questionsPerDay, existing.questionsPerDay ?? 40, 1000),
    minutesPerDay: num(b.minutesPerDay, existing.minutesPerDay ?? 30, 1440),
    tokensPerDay: num(b.tokensPerDay, existing.tokensPerDay ?? 50000, 10_000_000),
    monthlyUsd: num(b.monthlyUsd, existing.monthlyUsd ?? 3, 1000),
    from: hhmm(b.from ?? existing.from ?? "07:00"),
    to: hhmm(b.to ?? existing.to ?? "19:30"),
    // "Eltern haben geschaut"-Hinweis beim Fortsetzen einer Seifenblase (Standard: an)
    notifySeen: typeof b.notifySeen === "boolean" ? b.notifySeen : existing.notifySeen ?? true,
    // Untertitel: das gerade Gesprochene erscheint als Text (Standard: an)
    captions: typeof b.captions === "boolean" ? b.captions : existing.captions ?? true,
    // Anbieter und Modell pro Kind; leer = Standard aus den Einstellungen.
    // Formular schickt "anbieter|modell"; ältere Aufrufe nur das Claude-Modell.
    ...kidChoice(b, existing),
    // Freigeschaltete Gesprächsmodi; null = alle (Standard). Mindestens einer muss an bleiben.
    modes: sanitizeModes(b.modes, existing.modes),
    // Stimme pro Kind: "dienst:stimme" (z. B. "google:de-DE-Chirp3-HD-Aoede"), "browser" oder leer = wie für alle
    voice: kidVoice(b.voice, existing.voice),
    // Farbschloss: nur über die eigenen Endpunkte änderbar, nie über das Kinder-Formular
    lock: existing.lock || null,
    // Profilbild: einer der eigenen Avatare (nur über die Avatar-Endpunkte änderbar)
    avatarId: existing.avatarId || null,
  };
}

// Systemprompt für jeden Anbieter: Persona, dazu der Gesprächsmodus (Sicherheitsregeln haben Vorrang)
function systemFor(kid, mode) {
  const system = [personaFor(kid)];
  if (mode) system.push(fillPlaceholders(
    modePrompt(mode) + "\n\nDieser Modus bestimmt Ablauf und Stil des Gesprächs. Die Sicherheitsregeln oben gelten trotzdem immer und haben Vorrang. " +
    `Möchte ${kid.name} etwas ganz anderes, geh freundlich darauf ein.`, kid));
  if (mode?.avatars) system.push(fillPlaceholders(AV.AVATAR_PROMPT, kid));
  return system;
}

function kidChoice(b, existing) {
  if (b.model === undefined && b.provider === undefined) return { provider: existing.provider ?? "", model: existing.model ?? "" };
  let provider = b.provider, model = String(b.model ?? "");
  if (provider === undefined && model.includes("|")) [provider, model] = [model.slice(0, model.indexOf("|")), model.slice(model.indexOf("|") + 1)];
  if (!model) return { provider: "", model: "" };
  provider ||= "anthropic";
  if (!validChoice(provider, model)) throw Object.assign(new Error("Unbekanntes Modell"), { status: 400 });
  if (!providerUsable(provider)) throw Object.assign(new Error(`${CATALOG.providers[provider].label} ist noch nicht eingerichtet oder „ungetestet verstanden“ fehlt noch.`), { status: 400 });
  return { provider, model };
}

function kidVoice(v, existing) {
  if (v === undefined) return existing || "";
  v = String(v || "").trim();
  if (!v) return "";
  const svc = v.split(":")[0];
  if (!TTS_PROVIDERS.includes(svc) || svc === "custom" || !/^[a-z]+(:[A-Za-z0-9_:.-]{1,120})?$/.test(v))
    throw Object.assign(new Error("Unbekannte Stimme"), { status: 400 });
  if (!ttsConfigured(svc, { ...ttsSettingsRaw(), ...(svc === "elevenlabs" ? { elevenVoice: v.slice(svc.length + 1) || ttsSettingsRaw().elevenVoice } : {}) }))
    throw Object.assign(new Error(`Die Stimme von ${VOICES.TTS_SERVICES[svc]?.label || svc} ist noch nicht eingerichtet (Eltern-Bereich › Stimme).`), { status: 400 });
  return v;
}

function sanitizeModes(v, existing) {
  if (v === undefined) return existing ?? null;
  if (v === null) return null;
  if (!Array.isArray(v)) throw Object.assign(new Error("Modi ungültig"), { status: 400 });
  const ids = MODES.map((m) => m.id).filter((id) => v.includes(id));
  if (!ids.length) throw Object.assign(new Error("Mindestens ein Gesprächsmodus muss an sein"), { status: 400 });
  return ids.length === MODES.length ? null : ids;
}

// Jedes Kind bekommt ab Werk eine eigene Farbe (die erste noch freie aus dieser Liste).
const KID_COLORS = ["#3d7aff", "#2bb673", "#b44dff", "#ff4d8d", "#00a6b8", "#e0a100", "#e5484d", "#5b6b8c"];
// Orange wählt das Kind selbst, wenn es will (Timo 2026-11-27: das Orange-Verbot gilt nur fürs App-Design).
function nextKidColor() {
  const used = new Set(db.kids.map((k) => (k.color || "").toLowerCase()));
  return KID_COLORS.find((c) => !used.has(c)) || KID_COLORS[db.kids.length % KID_COLORS.length];
}

// ---------------------------------------------------------------- Farbschloss
// Kinderschloss für Geschwister an einem Tablet: 3 von 6 Farben in Reihenfolge (216 Möglichkeiten).
// Das ist bewusst KEIN echter Schutz, nur „nicht aus Versehen ins Profil der Schwester“.
// Gespeichert wird nur ein gesalzener Hash, auch Eltern sehen die Kombination nicht.
const LOCK_COLORS = 6, LOCK_LEN = 3;
const UNLOCK_IDLE_MS = 15 * 60_000;
const unlocks = new Map(); // "geräteId:kindId" -> Ablaufzeit
const validCombo = (c) => Array.isArray(c) && c.length === LOCK_LEN && c.every((x) => Number.isInteger(x) && x >= 0 && x < LOCK_COLORS);
function makeLock(combo, by) {
  const salt = crypto.randomBytes(16).toString("hex");
  return { salt, hash: sha256(salt + ":" + combo.join(",")), by, at: new Date().toISOString() };
}
function comboMatches(kid, combo) {
  if (!kid.lock || !validCombo(combo)) return false;
  const a = Buffer.from(sha256(kid.lock.salt + ":" + combo.join(",")), "hex"), b = Buffer.from(kid.lock.hash, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
// Offen für dieses Gerät? Jede Nutzung verlängert um 15 Minuten.
function kidUnlocked(dev, kid) {
  if (!kid.lock) return true;
  if (!dev) return false;
  const key = dev.id + ":" + kid.id, exp = unlocks.get(key);
  if (!exp || Date.now() > exp) { unlocks.delete(key); return false; }
  unlocks.set(key, Date.now() + UNLOCK_IDLE_MS);
  return true;
}
// 5 falsche Versuche pro Gerät und Kind, dann 5 Minuten Pause
const lockTries = (dev, kid) => rateLimit("lock:" + dev.id + ":" + kid.id, 5, 5 * 60_000);
const LOCK_PAUSE = "Kurze Pause! Probier es in ein paar Minuten nochmal, oder frag Mama oder Papa.";

// Adresse, unter der Tablets den Server erreichen (für den Hinweis im Eltern-Bereich).
// LC_PUBLIC_URL gewinnt; sonst wird Tailscale gefragt (Name im Tailnet + ob "tailscale serve" läuft).
const TAILSCALE_BIN = process.env.LC_TAILSCALE || (process.platform === "win32" ? "C:\\Program Files\\Tailscale\\tailscale.exe" : "tailscale");
let reach = { url: process.env.LC_PUBLIC_URL || null, tailscale: null, serve: null, checked: 0 };
function tsJson(args) {
  return new Promise((resolve) => execFile(TAILSCALE_BIN, args, { timeout: 4000, windowsHide: true }, (err, out) => {
    if (err) return resolve(null);
    try { resolve(JSON.parse(out || "{}")); } catch { resolve(null); }
  }));
}
async function refreshReach() {
  if (process.env.LC_PUBLIC_URL || process.env.LC_NO_TAILSCALE_CHECK) return;
  if (Date.now() - reach.checked < 5 * 60_000) return;
  reach.checked = Date.now();
  const st = await tsJson(["status", "--json"]);
  const name = st?.Self?.DNSName ? String(st.Self.DNSName).replace(/\.$/, "") : null;
  const serve = st ? await tsJson(["serve", "status", "--json"]) : null;
  const serving = !!serve && Object.keys(serve.TCP || serve.Web || {}).length > 0;
  reach = { ...reach, tailscale: st ? (st.BackendState === "Running" ? "an" : "aus") : "fehlt", serve: serving, url: name && serving ? "https://" + name : null };
}

// Anbieter für den Eltern-Bereich: nie Schlüssel, nur ob einer da ist (und die letzten 4 Zeichen)
function providerView() {
  return AI.PROVIDER_IDS.filter((pid) => CATALOG.providers[pid]).map((pid) => {
    const c = CATALOG.providers[pid];
    const key = providerKey(pid);
    return {
      id: pid, label: c.label, guide: c.guide, keyHint: c.keyHint || "", local: !!c.local, warning: c.warning || "", safety: c.safety || "",
      configured: providerConfigured(pid), usable: providerUsable(pid), source: providerKeySource(pid), last4: key ? key.slice(-4) : "",
      url: pid === "ollama" ? db.settings.ollama?.url || AI.baseUrl("ollama") : undefined,
      models: Object.fromEntries(Object.entries(providerModels(pid)).map(([id, m]) => [id, m.label])),
      defaultModel: defaultModel(pid),
      check: db.settings.providerChecks?.[pid] || null,
      untested: pid !== "anthropic",
      ack: db.settings.providerAck?.[pid] || null,
      degraded: AI.degraded[pid] || null,
    };
  });
}

function parentView(req, cur = req ? findDevice(req) : null) {
  const { date, month } = localParts();
  return {
    keyConfigured: anyProvider(),
    anthropicConfigured: !!anthropicKey,
    keySource: keyInfo.source,   // "env" | "db" | null – der Schlüssel selbst wird nie ausgeliefert
    pwReset: db.pwReset || null,  // letztes Zurücksetzen per Wiederherstellungsschlüssel (Zeit, Gerät)
    keyLast4: keyInfo.last4,
    backupDir: BACKUP_DIR,
    backupKeep: BACKUP_KEEP,
    stt: STT_URL ? "server" : "browser",
    tts: (({ provider, url, model, customVoice, piperVoice, piperSpeaker, piperSpeed, googleVoice, azureVoice, azureRegion, elevenVoice, elevenModel, cloudRate }) =>
      ({ provider, url, model, customVoice, piperVoice, piperSpeaker, piperSpeed, googleVoice, azureVoice, azureRegion, elevenVoice, elevenModel, cloudRate }))({ ...ttsSettingsRaw(), provider: ttsSettings().provider }),
    ttsWanted: ttsSettingsRaw().provider,
    piper: piperVoices().map(({ id, label, license, speakers }) => ({ id, label, license, speakers })),
    ttsServices: ttsServicesView(),
    time: { zone: ENV_TZ, now: localParts(new Date(), ENV_TZ).time },
    reach: { url: reach.url, tailscale: reach.tailscale, serve: reach.serve, via: accessVia(req) },
    providers: providerView(),
    choice: choiceFor(null),
    settings: db.settings,
    personaDefault, appNameDefault: APP_NAME,
    texts: textKeys().map(textView),
    modes: MODES.map(({ id, name, emoji, color, about }) => ({ id, name, emoji, color, about })),
    extensions: (db.extensions || []).filter((e) => Date.now() - Date.parse(e.at) < 30 * 86400_000).slice(-50).reverse(),
    nextKidColor: nextKidColor(),
    recoverySavedAt: db.settings.recoverySavedAt || null,
    trashCount: db.trash.length + db.convos.filter(kidTrashedConvo).length + db.avatars.filter((a) => a.hiddenAt).length,
    trashDays: db.settings.trashDays || 30,
    digestOn: db.settings.digest !== false,
    kids: db.kids.map((k) => {
      const u = db.usage[k.id] || {};
      const today = u.date === date;
      const { lock, ...rest } = k;
      return { ...rest, age: ageFrom(k.birth), avatars: allAvatars(k.id).map(avatarView(k)), lock: lock ? { by: lock.by, at: lock.at } : null, usage: {
        questions: today ? u.questions : 0, tokens: today ? u.tokens : 0,
        minutes: today ? Math.round(u.minutes) : 0, monthUsd: +(u.months?.[month] || 0).toFixed(3),
      }, blocked: limitMessage(k) ? limitName(k) : null,
      extension: (() => { const e = extensionActive(k.id); return e ? { allDay: !!e.allDay, until: e.until || null } : null; })() };
    }),
    devices: db.devices.map((d) => {
      const convos = db.convos.filter((c) => c.deviceId === d.id);
      const kidIds = [...new Set(convos.map((c) => c.kidId))];
      const lastKid = db.kids.find((k) => k.id === d.lastKidId);
      return { id: d.id, name: d.name, created: d.created, lastSeen: d.lastSeen, ua: d.ua || null, via: d.via || null, tz: d.tz || null,
        current: !!cur && cur.id === d.id, convos: convos.length,
        kids: db.kids.filter((k) => kidIds.includes(k.id)).map((k) => k.name), lastKid: lastKid ? lastKid.name : null };
    }),
    globalMonthUsd: +(db.global[month] || 0).toFixed(3),
  };
}

// Update-Status für den Elternbereich: liest, was der Aufpasser (scripts/supervisor.js) in logs/ schreibt.
// Nur lesen, keine Aktionen. Ohne Aufpasser (z. B. „npm start“) gibt es keine Datei: managed = false.
const APP_DIR = process.env.LC_APP_DIR || ROOT;
async function updateStatusView() {
  const logDir = path.join(APP_DIR, "logs");
  const st = await fsp.readFile(path.join(logDir, "update-status.json"), "utf8").then(JSON.parse).catch(() => null);
  const log = await fsp.readFile(path.join(logDir, "update.log"), "utf8").catch(() => "");
  const flag = (f) => fs.existsSync(path.join(APP_DIR, f));
  const every = Number(st?.everyMin) || 10;
  const age = st?.updatedAt ? Date.now() - Date.parse(st.updatedAt) : Infinity;
  return {
    managed: typeof process.send === "function", version: process.env.LC_VERSION || null, now: new Date().toISOString(),
    status: st, stale: !!st?.autoupdate && !!st?.canUpdate && age > Math.max(3 * every, 30) * 60_000,
    requested: { update: flag("update-now"), publish: flag("publish-now"), rollback: flag("rollback-now") },
    log: log.trim().split(/\r?\n/).filter(Boolean).slice(-15),
  };
}

async function handleApi(req, res, url) {
  const m = req.method;
  const p = url.pathname;

  // CSRF-Schutz: nur gleiche Herkunft, plus eigener Header (kein einfacher Formular-POST möglich)
  if (m !== "GET") {
    const origin = req.headers.origin;
    const host = req.headers["x-forwarded-host"] && TRUST_PROXY ? req.headers["x-forwarded-host"] : req.headers.host;
    if (req.headers["x-lc"] !== "1" || (origin && new URL(origin).host !== host))
      return send(res, 403, { error: "Ungültige Herkunft" });
  }

  if (p === "/api/state" && m === "GET") {
    return send(res, 200, {
      setup: !!db.parent, parent: isParent(req, false), parentIdleMin: PARENT_IDLE_MS / 60_000, wakeMinutes: db.settings.wakeMinutes ?? 10, device: !!deviceOf(req), keyConfigured: anyProvider(),
      appName: appName(), stt: STT_URL ? "server" : "browser", tts: ttsClient(ttsSettings()), ttsSig: ttsVoiceSig(ttsSettings()),
      ...(isParent(req, false) && process.env.LC_VERSION ? { version: process.env.LC_VERSION } : {}),
    });
  }

  if (p === "/api/setup" && m === "POST") {
    if (db.parent) return send(res, 409, { error: "Schon eingerichtet" });
    if (!rateLimit("setup:" + clientIp(req), 5, 15 * 60_000)) return send(res, 429, { error: "Zu viele Versuche" });
    const b = await readJson(req);
    if (!setupCode || String(b.code || "").trim().toUpperCase() !== setupCode) return send(res, 403, { error: "Einrichtungscode falsch (steht im Server-Log)" });
    if (String(b.password || "").length < 10) return send(res, 400, { error: "Passwort: mindestens 10 Zeichen" });
    db.parent = hashPassword(String(b.password));
    setupCode = null;
    fsp.unlink(SETUP_CODE_FILE).catch(() => {});
    await saveDb();
    return loginOk(res);
  }

  if (p === "/api/login" && m === "POST") {
    const ip = clientIp(req);
    if (!rateLimit("login:" + ip, 5, 15 * 60_000) || !rateLimit("login:all", 20, 15 * 60_000))
      return send(res, 429, { error: "Zu viele Versuche. Bitte 15 Minuten warten." });
    const b = await readJson(req);
    if (!checkPassword(String(b.password || ""), db.parent)) return send(res, 401, { error: "Passwort falsch" });
    return loginOk(res);
  }

  // Passwort vergessen: mit dem Wiederherstellungsschlüssel (= Hauptschlüssel der Verschlüsselung) ein neues Passwort setzen.
  // Der Schlüssel hat 256 Bit, Raten ist aussichtslos; die Sperre schützt trotzdem vor Dauerbeschuss und hält die CPU frei.
  // Passwort und Verschlüsselung sind getrennt: Datenbank und Backups hängen nur am Schlüssel, nicht am Passwort,
  // deshalb bleiben alle Backups nach dem Zurücksetzen lesbar. Das Zurücksetzen wird protokolliert und im Eltern-Bereich angezeigt.
  if (p === "/api/login/recover" && m === "POST") {
    if (!db.parent) return send(res, 409, { error: "Noch nicht eingerichtet" });
    const ip = clientIp(req);
    const keys = ["recover:" + ip, "recover:all"];
    const max = (k) => (k === "recover:all" ? 10 : 5);
    const blocked = keys.some((k) => { const x = buckets.get(k); return x && Date.now() <= x.reset && x.n >= max(k); });
    if (blocked) return send(res, 429, { error: "Zu viele Versuche. Bitte eine Stunde warten." });
    const b = await readJson(req);
    let given = null;
    try { given = parseRecovery(b.key || ""); } catch {}
    if (!given || !crypto.timingSafeEqual(given, masterKey)) {
      for (const k of keys) rateLimit(k, max(k), 60 * 60_000);
      return send(res, 401, { error: "Der Wiederherstellungsschlüssel stimmt nicht." });
    }
    if (String(b.password || "").length < 10) return send(res, 400, { error: "Passwort: mindestens 10 Zeichen" });
    for (const k of keys) buckets.delete(k);
    db.parent = hashPassword(String(b.password));
    db.pwReset = { at: new Date().toISOString(), device: deviceOf(req)?.name || null };
    parentSessions.clear();
    await saveDb();
    console.log(`Eltern-Passwort mit dem Wiederherstellungsschlüssel zurückgesetzt (${db.pwReset.device || "Browser ohne Kopplung"})`);
    return loginOk(res);
  }

  if (p === "/api/logout" && m === "POST") {
    const t = parseCookies(req).lc_parent;
    if (t) parentSessions.delete(sha256(t));
    return send(res, 200, { ok: true }, { "Set-Cookie": cookie("lc_parent", "", 0) });
  }

  // ------------------------------------------------ Geräte-Endpunkte (Kinder)
  if (p === "/api/kids" && m === "GET") {
    if (!deviceOf(req) && !isParent(req)) return send(res, 401, { error: "Gerät nicht freigegeben" });
    return send(res, 200, db.kids.map((k) => ({ id: k.id, name: k.name, color: k.color, age: ageFrom(k.birth), locked: !!k.lock, captions: k.captions !== false, avatar: AV.styledSvg(activeAvatar(k)?.svg) || null, modes: kidModes(k).map(modePublic), tts: ttsClient(ttsFor(k)), ttsSig: ttsVoiceSig(ttsFor(k)) })));
  }

  // Farbschloss öffnen / schließen / einrichten (Kind am eigenen Gerät)
  if (p.startsWith("/api/kids/") && m === "POST") {
    const dev = deviceOf(req);
    if (!dev) return send(res, 401, { error: "Gerät nicht freigegeben" });
    const b = await readJson(req);
    const kid = db.kids.find((k) => k.id === b.kidId);
    if (!kid) return send(res, 404, { error: "Kind nicht gefunden" });
    const key = dev.id + ":" + kid.id;
    if (p === "/api/kids/unlock") {
      if (!kid.lock) return send(res, 200, { ok: true });
      const wait = buckets.get("lock:" + key);
      if (wait && Date.now() <= wait.reset && wait.n >= 5) return send(res, 429, { error: LOCK_PAUSE });
      if (!comboMatches(kid, b.combo)) {
        lockTries(dev, kid);
        return send(res, 403, { error: "Das waren nicht die richtigen Farben." });
      }
      buckets.delete("lock:" + key);
      unlocks.set(key, Date.now() + UNLOCK_IDLE_MS);
      return send(res, 200, { ok: true });
    }
    // Kind wählt seine Farbe selbst (offenes Profil nötig, wie beim Schloss)
    if (p === "/api/kids/color") {
      if (!kidUnlocked(dev, kid)) return send(res, 403, { error: "Erst dein Profil öffnen." });
      if (!/^#[0-9a-f]{6}$/i.test(String(b.color || ""))) return send(res, 400, { error: "Unbekannte Farbe" });
      kid.color = b.color.toLowerCase();
      await saveDb();
      return send(res, 200, { ok: true, color: kid.color });
    }
    if (p === "/api/kids/relock") { unlocks.delete(key); return send(res, 200, { ok: true }); }
    if (p === "/api/kids/lock") {
      // Nur wer gerade im Profil ist, darf das Schloss einrichten; ändern/entfernen nur mit den alten Farben
      if (!kidUnlocked(dev, kid)) return send(res, 403, { error: "Erst dein Profil öffnen." });
      if (kid.lock) {
        const wait = buckets.get("lock:" + key);
        if (wait && Date.now() <= wait.reset && wait.n >= 5) return send(res, 429, { error: LOCK_PAUSE });
        if (!comboMatches(kid, b.oldCombo)) { lockTries(dev, kid); return send(res, 403, { error: "Das waren nicht die richtigen Farben." }); }
      }
      if (b.combo === null) kid.lock = null;
      else if (validCombo(b.combo)) kid.lock = makeLock(b.combo, "Kind");
      else return send(res, 400, { error: "Bitte genau 3 Farben." });
      if (kid.lock) unlocks.set(key, Date.now() + UNLOCK_IDLE_MS);
      await saveDb();
      return send(res, 200, { ok: true, locked: !!kid.lock });
    }
    return send(res, 404, { error: "Unbekannt" });
  }

  if (p === "/api/bubbles" && m === "GET") {
    const dev = deviceOf(req);
    if (!dev) return send(res, 401, { error: "Gerät nicht freigegeben" });
    const kidId = url.searchParams.get("kidId");
    const lk = db.kids.find((k) => k.id === kidId);
    if (lk && !kidUnlocked(dev, lk)) return send(res, 423, { error: "Profil ist abgeschlossen" });
    const list = db.convos.filter((c) => c.kidId === kidId && c.messages.length >= 2 && !c.kidPoppedAt)
      .sort((a, b) => b.updated.localeCompare(a.updated)).slice(0, 12).map(bubbleView);
    return send(res, 200, list);
  }

  // Kind lässt eine Seifenblase zerplatzen: für das Kind ist das Gespräch weg. Für die Eltern bleibt es
  // lesbar und ist markiert; endgültig löschen können nur die Eltern (oder die automatische Aufbewahrungsfrist).
  if (p === "/api/bubbles/pop" && m === "POST") {
    const dev = deviceOf(req);
    if (!dev) return send(res, 401, { error: "Gerät nicht freigegeben" });
    const b = await readJson(req);
    const lk = db.kids.find((k) => k.id === b.kidId);
    if (lk && !kidUnlocked(dev, lk)) return send(res, 423, { error: "Profil ist abgeschlossen" });
    const c = db.convos.find((x) => x.id === b.convoId && x.kidId === b.kidId);
    if (!c) return send(res, 404, { error: "Nicht gefunden" });
    c.kidPoppedAt = new Date().toISOString();
    await saveDb();
    return send(res, 200, { ok: true });
  }

  // Kind tippt eine Seifenblase an: Rückblick zum Vorlesen. Hat ein Elternteil das Gespräch seit dem letzten
  // Mal angesehen, kommt genau jetzt (einmal pro Ansicht) der Hinweis dazu.
  if (p === "/api/bubbles/resume" && m === "POST") {
    const dev = deviceOf(req);
    if (!dev) return send(res, 401, { error: "Gerät nicht freigegeben" });
    const b = await readJson(req);
    const c = db.convos.find((x) => x.id === b.convoId && x.kidId === b.kidId && !x.kidPoppedAt);
    const kid = db.kids.find((k) => k.id === b.kidId);
    if (!c || !kid) return send(res, 404, { error: "Nicht gefunden" });
    if (!kidUnlocked(dev, kid)) return send(res, 423, { error: "Profil ist abgeschlossen" });
    delete c.splitTo; // bewusst die alte Blase angetippt: dort weitersprechen, nicht in der abgetrennten
    let notice = null;
    if (parentSeenPending(c)) {
      // Ist der Hinweis für dieses Kind ausgeschaltet, gilt die Ansicht trotzdem als erledigt,
      // damit beim späteren Einschalten keine alten Ansichten nachträglich angesagt werden.
      if (kid.notifySeen !== false)
        notice = "Übrigens: Mama oder Papa haben sich dieses Gespräch angeschaut. Die finden es schön, was dich interessiert.";
      c.kidNotifiedAt = new Date().toISOString();
      await saveDb();
    }
    const recap = c.recap || `Wir haben über ${c.title} gesprochen.`;
    return send(res, 200, { say: `Weißt du noch, ${kid.name}? ${recap}`, notice, then: "Was möchtest du noch dazu wissen?", mode: resolveMode(kid, c.mode)?.id || null });
  }

  // Avatare des Kindes: ansehen, als Profilbild wählen, löschen (Kind am eigenen Gerät, Profil offen)
  if (p.startsWith("/api/avatars")) {
    const dev = deviceOf(req);
    if (!dev) return send(res, 401, { error: "Gerät nicht freigegeben" });
    const b = m === "GET" ? { kidId: url.searchParams.get("kidId") } : await readJson(req, 4 * 1024);
    const kid = db.kids.find((k) => k.id === b.kidId);
    if (!kid) return send(res, 404, { error: "Kind nicht gefunden" });
    if (!kidUnlocked(dev, kid)) return send(res, 423, { error: "Profil ist abgeschlossen" });
    if (p === "/api/avatars" && m === "GET") return send(res, 200, kidAvatars(kid.id).map(avatarView(kid)));
    const av = kidAvatars(kid.id).find((a) => a.id === b.avatarId);
    if (!av) return send(res, 404, { error: "Avatar nicht gefunden" });
    if (p === "/api/avatars/activate" && m === "POST") kid.avatarId = av.id;
    else if (p === "/api/avatars/delete" && m === "POST") hideAvatar(av); // Kind löscht: nur ausgeblendet, Eltern sehen ihn weiter
    else return send(res, 404, { error: "Unbekannt" });
    await saveDb();
    return send(res, 200, kidAvatars(kid.id).map(avatarView(kid)));
  }

  if (p === "/api/extend" && m === "POST") return extendLimit(req, res);
  if (p === "/api/talk" && m === "POST") return talk(req, res);
  if (p === "/api/stt" && m === "POST") return stt(req, res);
  if (p === "/api/tts" && m === "POST") return tts(req, res);

  if (p === "/api/pair" && m === "POST") {
    if (!rateLimit("pair:" + clientIp(req), 10, 15 * 60_000) || !rateLimit("pair", 30, 15 * 60_000))
      return send(res, 429, { error: "Zu viele Versuche. Bitte in 15 Minuten nochmal." });
    const b = await readJson(req, 1024);
    const touch = b.touch === true;
    const code = String(b.code || "").replace(/\D/g, "");
    const entry = pairCodes.get(code);
    if (!entry || Date.now() > entry.exp) return send(res, 400, { error: "Code falsch oder abgelaufen. Bitte im Eltern-Bereich einen neuen erzeugen." });
    pairCodes.delete(code); // nur einmal gültig
    const { setCookie } = createDevice(req, entry.name, touch);
    await saveDb();
    return send(res, 200, { ok: true }, { "Set-Cookie": setCookie });
  }

  // ------------------------------------------------ Eltern-Endpunkte
  if (!p.startsWith("/api/parent")) return send(res, 404, { error: "Unbekannt" });
  if (!isParent(req)) return send(res, 401, { error: "Bitte als Eltern anmelden" });

  if (p === "/api/parent" && m === "GET") { await refreshReach(); return send(res, 200, parentView(req)); }

  if (p === "/api/parent/update-status" && m === "GET") return send(res, 200, await updateStatusView());

  if (p === "/api/parent/settings" && m === "PUT") {
    const b = await readJson(req, 256 * 1024);
    if (b.model !== undefined) {
      let provider = b.provider, model = String(b.model);
      if (provider === undefined && model.includes("|")) [provider, model] = [model.slice(0, model.indexOf("|")), model.slice(model.indexOf("|") + 1)];
      provider ||= "anthropic";
      if (!validChoice(provider, model)) return send(res, 400, { error: "Unbekanntes Modell" });
      if (!providerUsable(provider)) return send(res, 400, { error: `${CATALOG.providers[provider].label} ist noch nicht eingerichtet oder „ungetestet verstanden“ fehlt noch.` });
      db.settings.provider = provider;
      db.settings.model = model;
      db.settings.modelChosen = true;
    }
    if (b.digest !== undefined) db.settings.digest = b.digest !== false;
    if (b.trashDays !== undefined) { db.settings.trashDays = Math.max(1, Math.min(365, Math.round(Number(b.trashDays) || 30))); purgeTrash(); }
    if (b.globalMonthlyUsd !== undefined) db.settings.globalMonthlyUsd = Math.max(0, Math.min(10000, Number(b.globalMonthlyUsd) || 0));
    if (b.appName !== undefined) {
      const n = String(b.appName || "").replace(/\s+/g, " ").trim();
      if (n && !/^[\p{L}\p{N}][\p{L}\p{N} .'-]{0,23}$/u.test(n)) return send(res, 400, { error: "Name: 1 bis 24 Zeichen, nur Buchstaben, Ziffern, Leerzeichen, Punkt, Bindestrich" });
      db.settings.appName = n && n !== APP_NAME ? n : null;
    }
    // Eigene Fassung bleibt in der DB (data/, von Updates nie angefasst). Text gleich dem Standard = kein eigener,
    // damit Verbesserungen aus kid_persona.md nach einem Update automatisch ankommen.
    if (b.persona !== undefined) saveText("persona", b.persona);
    // Bildschirm in der Kinderansicht wach halten: Minuten ohne Berührung, 0 = Gerät entscheidet
    if (b.wakeMinutes !== undefined) db.settings.wakeMinutes = Math.max(0, Math.min(120, Math.round(Number(b.wakeMinutes) || 0)));
    if (b.retentionDays !== undefined) { db.settings.retentionDays = Math.max(0, Math.min(3650, Math.round(Number(b.retentionDays) || 0))); db.settings.retentionChosen = true; purgeOldConvos(); }
    await saveDb();
    return send(res, 200, parentView(req));
  }

  // Bearbeitbare KI-Texte: { text } speichert (null/leer/gleich Standard = Standard), { undo: true } holt die
  // zuletzt verworfene eigene Fassung zurück
  const textMatch = p.replace(/%3A/gi, ":").match(/^\/api\/parent\/texts\/(safety|persona|mode:[a-z0-9-]+)$/);
  if (textMatch && m === "PUT") {
    const b = await readJson(req, 256 * 1024);
    if (!textSlot(textMatch[1])) return send(res, 404, { error: "Unbekannter Text" });
    saveText(textMatch[1], b.text ?? null, b.undo === true);
    await saveDb();
    return send(res, 200, parentView(req));
  }

  if (p === "/api/parent/kids" && m === "POST") {
    db.kids.push(sanitizeKid(await readJson(req)));
    await saveDb();
    return send(res, 200, parentView(req));
  }
  const lockMatch = p.match(/^\/api\/parent\/kids\/([a-f0-9]{16})\/lock$/);
  if (lockMatch) {
    const kid = db.kids.find((k) => k.id === lockMatch[1]);
    if (!kid) return send(res, 404, { error: "Kind nicht gefunden" });
    if (m === "PUT") {
      const b = await readJson(req);
      if (!validCombo(b.combo)) return send(res, 400, { error: "Bitte genau 3 Farben." });
      kid.lock = makeLock(b.combo, "Eltern");
    } else if (m === "DELETE") kid.lock = null;
    else return send(res, 405, { error: "Methode" });
    for (const k of unlocks.keys()) if (k.endsWith(":" + kid.id)) unlocks.delete(k);
    for (const k of buckets.keys()) if (k.startsWith("lock:") && k.endsWith(":" + kid.id)) buckets.delete(k);
    await saveDb();
    return send(res, 200, parentView(req));
  }
  const kidMatch = p.match(/^\/api\/parent\/kids\/([a-f0-9]{16})$/);
  if (kidMatch) {
    const i = db.kids.findIndex((k) => k.id === kidMatch[1]);
    if (i < 0) return send(res, 404, { error: "Kind nicht gefunden" });
    if (m === "PUT") db.kids[i] = sanitizeKid(await readJson(req), db.kids[i]);
    else if (m === "DELETE") {
      if (!confirmPassword(req, res)) return;
      const kidId = db.kids[i].id;
      trashPut("kid", db.kids[i], { convos: db.convos.filter((c) => c.kidId === kidId), avatars: db.avatars.filter((a) => a.kidId === kidId), usage: db.usage[kidId] || null });
      delete db.usage[kidId];
      db.convos = db.convos.filter((c) => c.kidId !== kidId);
      db.avatars = db.avatars.filter((a) => a.kidId !== kidId);
      db.kids.splice(i, 1);
    }
    else return send(res, 405, { error: "Methode" });
    await saveDb();
    return send(res, 200, parentView(req));
  }

  if (p === "/api/parent/devices" && m === "POST") {
    const b = await readJson(req);
    const { dev, setCookie } = createDevice(req, b.name, b.touch === true);
    await saveDb();
    return send(res, 200, parentView(req, dev), { "Set-Cookie": setCookie });
  }
  // Kopplungscode: Eltern erzeugen ihn auf ihrem Gerät, das Tablet gibt ihn in der installierten App ein.
  // So muss sich niemand auf dem Kinder-Tablet als Eltern anmelden.
  if (p === "/api/parent/devices/code" && m === "POST") {
    const b = await readJson(req);
    pairCodes.clear(); // immer nur ein gültiger Code
    const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, "0");
    const expires = Date.now() + PAIR_CODE_TTL;
    pairCodes.set(code, { exp: expires, name: String(b.name || "").trim().slice(0, 40) });
    return send(res, 200, { code, expires: new Date(expires).toISOString() });
  }
  const devMatch = p.match(/^\/api\/parent\/devices\/([a-f0-9]{16})$/);
  if (devMatch && m === "PATCH") {
    const d = db.devices.find((x) => x.id === devMatch[1]);
    if (!d) return send(res, 404, { error: "Gerät nicht gefunden" });
    const b = await readJson(req);
    const name = String(b.name || "").trim().slice(0, 40);
    if (!name) return send(res, 400, { error: "Name fehlt" });
    d.name = name;
    await saveDb();
    return send(res, 200, parentView(req));
  }
  if (devMatch && m === "DELETE") {
    db.devices = db.devices.filter((d) => d.id !== devMatch[1]);
    await saveDb();
    return send(res, 200, parentView(req));
  }

  if (p === "/api/parent/convos" && m === "GET") {
    const kidId = url.searchParams.get("kidId");
    return send(res, 200, db.convos.filter((c) => !kidId || c.kidId === kidId)
      .sort((a, b) => b.updated.localeCompare(a.updated))
      .map((c) => ({ id: c.id, kidId: c.kidId, emoji: c.emoji, title: c.title, created: c.created, updated: c.updated, flagged: !!c.flagged,
        count: c.messages.length, mode: c.mode || null, parentSeenAt: c.parentSeenAt || null, kidNotifiedAt: c.kidNotifiedAt || null, kidPoppedAt: c.kidPoppedAt || null, poppedByAvatar: !!c.poppedByAvatar, parentDoneAt: c.parentDoneAt || null })));
  }
  // Mehrere Gespräche endgültig löschen (alle eines Kindes oder alle). Die Sicherungen bleiben unverändert
  // und laufen nach BACKUP_KEEP Tagen ab, bis dahin lässt sich ein Gespräch dort noch zurückholen.
  if (p === "/api/parent/convos" && m === "DELETE") {
    if (!confirmPassword(req, res)) return;
    const kidId = url.searchParams.get("kidId");
    const gone = db.convos.filter((c) => (!kidId || c.kidId === kidId) && !kidTrashedConvo(c));
    for (const c of gone) trashPut("convo", c);
    db.convos = db.convos.filter((c) => !gone.includes(c));
    await saveDb();
    return send(res, 200, { deleted: gone.length });
  }
  const convoMatch = p.match(/^\/api\/parent\/convos\/([a-f0-9]{16})$/);
  if (convoMatch) {
    const c = db.convos.find((x) => x.id === convoMatch[1]);
    if (!c) return send(res, 404, { error: "Gespräch nicht gefunden" });
    if (m === "GET") {
      c.parentSeenAt = new Date().toISOString();
      await saveDb();
      return send(res, 200, c);
    }
    if (m === "DELETE") {
      // vom Kind zerplatzt: liegt schon im Papierkorb, Eltern-Löschen dort heißt endgültig
      if (!kidTrashedConvo(c)) trashPut("convo", c);
      db.convos = db.convos.filter((x) => x !== c);
      await saveDb();
      return send(res, 200, { ok: true });
    }
    return send(res, 405, { error: "Methode" });
  }

  // Eltern: Avatar endgültig löschen (DELETE) oder einen vom Kind gelöschten zurückholen (POST …/restore).
  // Zurückgeholt zählt er wieder mit; das Kind kann dann mehr als 3 haben, neu erfinden geht erst unter 3.
  const avMatch = p.match(/^\/api\/parent\/avatars\/([a-f0-9]{16})(\/restore)?$/);
  if (avMatch && ((m === "DELETE" && !avMatch[2]) || (m === "POST" && avMatch[2]))) {
    const av = db.avatars.find((a) => a.id === avMatch[1]);
    if (!av) return send(res, 404, { error: "Avatar nicht gefunden" });
    if (m === "DELETE") { if (!av.hiddenAt) trashPut("avatar", av); deleteAvatar(av); }
    else delete av.hiddenAt;
    await saveDb();
    return send(res, 200, parentView(req));
  }

  if (p === "/api/parent/password" && m === "POST") {
    const b = await readJson(req);
    if (!checkPassword(String(b.old || ""), db.parent)) return send(res, 401, { error: "Altes Passwort falsch" });
    if (String(b.password || "").length < 10) return send(res, 400, { error: "Passwort: mindestens 10 Zeichen" });
    db.parent = hashPassword(String(b.password));
    parentSessions.clear();
    await saveDb();
    return loginOk(res);
  }

  // API-Schlüssel über den Assistenten hinterlegen: wird geprüft, dann verschlüsselt gespeichert, nie zurückgegeben.
  if (p === "/api/parent/apikey" && m === "PUT") {
    if (keyInfo.source === "env") return send(res, 409, { error: "Der Schlüssel kommt aus der .env-Datei. Dort ändern oder entfernen." });
    if (!rateLimit("apikey", 10, 60 * 60_000)) return send(res, 429, { error: "Zu viele Versuche" });
    const key = String((await readJson(req)).key || "").trim();
    if (!/^sk-ant-[A-Za-z0-9_-]{20,}$/.test(key)) return send(res, 400, { error: "Das sieht nicht wie ein Anthropic-API-Schlüssel aus (beginnt mit sk-ant-)." });
    try {
      const r = await AI.chat({ catalog: CATALOG, provider: "anthropic", key, model: DEFAULT_MODEL, maxTokens: 300, system: "Test", messages: [{ role: "user", content: "Antworte nur mit: OK" }] });
      db.global[globalMonth()] += costUsd("anthropic", r.model, r.usage);
    } catch (e) {
      return send(res, 400, { error: "Schlüssel funktioniert nicht: " + AI.errorText(e, "anthropic") });
    }
    db.secrets = { ...(db.secrets || {}), apiKey: key };
    useKey(key, "db");
    await saveDb();
    return send(res, 200, parentView(req));
  }
  // Stimmen-Einstellungen aus einem Formular (nur bekannte Felder, alles begrenzt)
  const ttsFromBody = (b, base = ttsSettingsRaw()) => {
    const provider = TTS_PROVIDERS.includes(b.provider) ? b.provider : "browser";
    const next = { ...base, provider };
    const str = (v, n) => String(v || "").trim().slice(0, n);
    if (b.piperVoice !== undefined) next.piperVoice = piperVoices().some((v) => v.id === b.piperVoice) ? b.piperVoice : "";
    if (b.piperSpeaker !== undefined) next.piperSpeaker = str(b.piperSpeaker, 40);
    if (b.piperSpeed !== undefined) next.piperSpeed = Math.min(1.6, Math.max(0.7, Number(b.piperSpeed) || 1.1));
    if (b.url !== undefined) next.url = str(b.url, 300);
    if (b.model !== undefined) next.model = str(b.model, 80);
    if (b.customVoice !== undefined) next.customVoice = str(b.customVoice, 80);
    if (b.googleVoice !== undefined) next.googleVoice = /^[A-Za-z0-9-]{1,80}$/.test(b.googleVoice) ? b.googleVoice : "";
    if (b.azureVoice !== undefined) next.azureVoice = /^[A-Za-z0-9:-]{1,100}$/.test(b.azureVoice) ? b.azureVoice : "";
    if (b.azureRegion !== undefined) next.azureRegion = str(b.azureRegion, 30).toLowerCase().replace(/\s+/g, "");
    if (b.elevenVoice !== undefined) next.elevenVoice = /^[A-Za-z0-9]{1,64}$/.test(b.elevenVoice) ? b.elevenVoice : "";
    if (b.elevenModel !== undefined) next.elevenModel = VOICES.TTS_SERVICES.elevenlabs.models[b.elevenModel] ? b.elevenModel : "";
    if (b.cloudRate !== undefined) next.cloudRate = Math.min(1.2, Math.max(0.8, Number(b.cloudRate) || 1));
    return next;
  };
  // Schlüssel: neu eingetippt, sonst gespeichert. Nie aus einer Antwort zurück.
  const ttsKeyIn = (b, svc) => (b.key ? VOICES.cleanKey(b.key) : "") || ttsKeyFor(svc);
  const keyShapeError = (svc, key) => {
    if (!VOICES.TTS_SERVICES[svc]?.needsKey) return null;
    if (!key) return `Bitte den ${VOICES.TTS_SERVICES[svc].label}-Schlüssel eintragen.`;
    if (svc === "google" && VOICES.googleKeyMistake(key)) return VOICES.googleKeyMistake(key) + " Gebraucht wird ein API-Schlüssel (beginnt mit AIza), siehe Anleitung.";
    if (key.length < 16) return `Der Schlüssel sieht unvollständig aus (nur ${key.length} Zeichen). Bitte noch einmal vollständig kopieren.`;
    return null;
  };
  // Deutsche Stimmen eines Dienstes laden (kostenlos, prüft nebenbei den Schlüssel)
  if (p === "/api/parent/tts/voices" && m === "POST") {
    if (!rateLimit("ttsvoices", 30, 60 * 60_000)) return send(res, 429, { error: "Zu viele Versuche" });
    const b = await readJson(req, 8 * 1024);
    const svc = b.provider;
    if (!VOICES.CLOUD_IDS.includes(svc)) return send(res, 400, { error: "Unbekannter Dienst" });
    const t = ttsFromBody(b), key = ttsKeyIn(b, svc);
    const bad = keyShapeError(svc, key);
    if (bad) return send(res, 400, { error: bad });
    try {
      const voices = await VOICES.listVoices(svc, key, t);
      if (!voices.length) return send(res, 400, { error: svc === "elevenlabs" ? "Keine Stimmen gefunden. Leg in ElevenLabs eine Stimme in „My Voices“ an oder füge eine aus der Bibliothek hinzu." : "Keine deutschen Stimmen gefunden." });
      if (!b.key || VOICES.cleanKey(b.key) === ttsKeyFor(svc)) { db.settings.ttsVoiceLists = { ...(db.settings.ttsVoiceLists || {}), [svc]: voices.slice(0, 200) }; await saveDb(); }
      return send(res, 200, { voices });
    } catch (e) { return send(res, 400, { error: e.message }); }
  }
  // Probehören einer Stimme, ohne etwas zu speichern. Cloud-Proben werden zwischengespeichert (kostet einmal).
  if (p === "/api/parent/tts/preview" && m === "POST") {
    if (!rateLimit("ttspreview", 60, 60_000)) return send(res, 429, { error: "Zu viele Versuche" });
    const b = await readJson(req, 8 * 1024);
    const svc = b.provider || "piper";
    const next = ttsFromBody({ ...b, provider: svc });
    if (svc === "browser") return send(res, 400, { error: "Die Systemstimme spielt das Gerät selbst ab." });
    if (svc === "piper" && !piperVoices().length) return send(res, 404, { error: "Piper ist nicht installiert" });
    const key = svc === "custom" ? (b.key || db.secrets?.ttsCustomKey || "") : ttsKeyIn(b, svc);
    const bad = svc === "custom" ? null : keyShapeError(svc, key);
    if (bad) return send(res, 400, { error: bad });
    try {
      const out = await synthesize(String(b.text || "Hallo! Ich bin " + appName() + ". Was möchtest du heute wissen?").slice(0, 300), next, { key, fixed: true, strict: true });
      res.writeHead(200, { ...SECURITY_HEADERS, "Content-Type": out.type, "Cache-Control": "no-store", "Content-Length": out.audio.length });
      return res.end(out.audio);
    } catch (e) { return send(res, 502, { error: (svc === "piper" ? "Piper: " : "") + e.message }); }
  }
  if (p === "/api/parent/tts" && m === "PUT") {
    if (!rateLimit("ttscfg", 20, 60 * 60_000)) return send(res, 429, { error: "Zu viele Versuche" });
    const b = await readJson(req);
    const next = ttsFromBody(b);
    const provider = next.provider;
    if (provider === "piper" && !piperVoices().length) return send(res, 400, { error: "Piper ist auf dem Server nicht installiert. Siehe README: node scripts/setup-piper.mjs" });
    const newKey = b.key !== undefined ? VOICES.cleanKey(b.key) : null;
    const key = provider === "custom" ? (newKey || db.secrets?.ttsCustomKey || "") : newKey || ttsKeyFor(provider);
    if (provider === "custom" && !/^https?:\/\/[^\s]+$/.test(next.url)) return send(res, 400, { error: "Adresse des Sprach-Servers fehlt, z. B. http://127.0.0.1:8000/v1/audio/speech" });
    const bad = provider === "custom" ? null : keyShapeError(provider, key);
    if (bad) return send(res, 400, { error: bad });
    if (provider === "azure" && !VOICES.validRegion(next.azureRegion)) return send(res, 400, { error: "Bitte die Azure-Region eintragen, z. B. westeurope oder germanywestcentral (steht im Azure-Portal bei der Speech-Ressource)." });
    // ElevenLabs hat keine feste deutsche Stimme: ohne Wahl die erste aus dem Konto
    if (provider === "elevenlabs" && !next.elevenVoice) {
      try { next.elevenVoice = (await VOICES.listVoices("elevenlabs", key))[0]?.id || ""; } catch (e) { return send(res, 400, { error: "Stimme funktioniert nicht: " + e.message }); }
      if (!next.elevenVoice) return send(res, 400, { error: "Im ElevenLabs-Konto ist keine Stimme. Füge in ElevenLabs unter „Voices“ eine Stimme hinzu." });
    }
    if (provider !== "browser") {
      try { await synthesize("Hallo! Ich bin " + appName() + ".", next, { key, fixed: true, strict: true }); }
      catch (e) { return send(res, 400, { error: "Stimme funktioniert nicht: " + e.message }); }
    }
    db.settings.tts = next;
    db.settings.ttsChosen = true;
    if (newKey && TTS_SLOT[provider]) db.secrets = { ...(db.secrets || {}), [TTS_SLOT[provider]]: newKey };
    // Schlüssel entfernen: ein Dienst gezielt (removeKey) oder alle Stimmen-Schlüssel (key: "")
    if (b.removeKey && TTS_SLOT[b.removeKey] && db.secrets) { delete db.secrets[TTS_SLOT[b.removeKey]]; if (db.settings.ttsVoiceLists) delete db.settings.ttsVoiceLists[b.removeKey]; }
    if (b.key === "" && db.secrets) for (const slot of Object.values(TTS_SLOT)) delete db.secrets[slot];
    if (newKey && VOICES.CLOUD_IDS.includes(provider)) {
      try { db.settings.ttsVoiceLists = { ...(db.settings.ttsVoiceLists || {}), [provider]: (await VOICES.listVoices(provider, key, next)).slice(0, 200) }; } catch {}
    }
    delete ttsDown[provider];
    ttsCache.clear();
    await saveDb();
    return send(res, 200, parentView(req));
  }
  if (p === "/api/parent/apikey" && m === "DELETE") {
    if (!confirmPassword(req, res)) return;
    if (keyInfo.source === "env") return send(res, 409, { error: "Der Schlüssel kommt aus der .env-Datei." });
    if (db.secrets) delete db.secrets.apiKey;
    useKey(null);
    await saveDb();
    return send(res, 200, parentView(req));
  }
  // Wiederherstellungsschlüssel (Hauptschlüssel der Verschlüsselung) einmal anzeigen, damit Eltern ihn sichern können
  if (p === "/api/parent/recovery-key" && m === "GET") {
    if (!db.settings.recoverySavedAt) { db.settings.recoverySavedAt = new Date().toISOString(); await saveDb(); }
    return send(res, 200, { key: formatRecovery(masterKey), backupDir: BACKUP_DIR });
  }
  // Verlängern direkt im Eltern-Bereich (angemeldet, also ohne erneutes Passwort) und Zurücknehmen
  const extMatch = p.match(/^\/api\/parent\/kids\/([a-f0-9]{16})\/extend$/);
  if (extMatch) {
    const kid = db.kids.find((k) => k.id === extMatch[1]);
    if (!kid) return send(res, 404, { error: "Kind nicht gefunden" });
    if (m === "POST") {
      const b = await readJson(req);
      const r = applyExtension(kid, b.minutes, "Eltern-Bereich");
      if (r.error) return send(res, r.status, { error: r.error });
      await saveDb();
      return send(res, 200, parentView(req));
    }
    if (m === "DELETE") {
      const { u } = kidUsage(kid.id);
      if (u.ext) {
        delete u.ext;
        db.extensions ||= [];
        db.extensions.push({ at: new Date().toISOString(), kidId: kid.id, kidName: kid.name, minutes: "undo", reason: "zurückgenommen", device: "Eltern-Bereich" });
        await saveDb();
      }
      return send(res, 200, parentView(req));
    }
    return send(res, 405, { error: "Methode" });
  }
  // Tagesrückblick für die Eltern: kurze KI-Zusammenfassung der heutigen Gespräche, zwischengespeichert
  if (p === "/api/parent/digest" && (m === "GET" || m === "POST")) {
    if (db.settings.digest === false) return send(res, 200, { on: false });
    const b = m === "POST" ? await readJson(req) : {};
    try { return send(res, 200, { on: true, ...(await digestToday(m === "POST" ? (b.force ? "force" : "stale") : "cached")) }); }
    catch (e) { return send(res, 200, { on: true, error: "Der Rückblick konnte gerade nicht erstellt werden: " + (e.message || e) }); }
  }

  // Papierkorb: ansehen, zurückholen, endgültig löschen (nie aus den Sicherungen)
  if (p === "/api/parent/trash" && m === "GET") return send(res, 200, { days: db.settings.trashDays || 30, items: trashView() });
  if (p === "/api/parent/trash" && m === "DELETE") {
    if (!confirmPassword(req, res)) return;
    const ids = trashView().map((x) => x.id);
    for (const id of ids) trashDelete(id);
    await saveDb();
    return send(res, 200, { deleted: ids.length });
  }
  // Zerplatzte Blase als gelesen markieren: wandert in den Papierkorb (DELETE nimmt das zurück)
  const doneMatch = p.match(/^\/api\/parent\/convos\/([a-f0-9]{16})\/done$/);
  if (doneMatch && (m === "POST" || m === "DELETE")) {
    const c = db.convos.find((x) => x.id === doneMatch[1] && x.kidPoppedAt && !x.poppedByAvatar);
    if (!c) return send(res, 404, { error: "Keine zerplatzte Seifenblase" });
    if (m === "POST") c.parentDoneAt = new Date().toISOString(); else delete c.parentDoneAt;
    await saveDb();
    return send(res, 200, parentView(req));
  }
  const trMatch = p.match(/^\/api\/parent\/trash\/([a-f0-9]{16})(\/restore)?$/);
  if (trMatch) {
    const id = trMatch[1];
    if (!trMatch[2] && m === "GET") {
      const c = db.trash.find((e) => e.id === id && e.type === "convo")?.item || db.convos.find((x) => x.id === id && kidTrashedConvo(x));
      if (!c) return send(res, 404, { error: "Nicht im Papierkorb" });
      return send(res, 200, { id: c.id, kidId: c.kidId, emoji: c.emoji, title: c.title, mode: c.mode || null, memory: c.memory || null, kidPoppedAt: c.kidPoppedAt || null,
        messages: c.messages.map((x) => ({ role: x.role, text: x.text, at: x.at, refused: !!x.refused })) });
    }
    if (trMatch[2] && m === "POST") {
      const err = trashRestore(id);
      if (err) return send(res, 409, { error: err });
      await saveDb();
      return send(res, 200, parentView(req));
    }
    if (!trMatch[2] && m === "DELETE") {
      if (!trashDelete(id)) return send(res, 404, { error: "Nicht im Papierkorb" });
      await saveDb();
      return send(res, 200, parentView(req));
    }
    return send(res, 405, { error: "Methode" });
  }

  if (p === "/api/parent/backup" && m === "POST") {
    const file = await backupNow();
    return send(res, 200, { ok: true, file: path.basename(file) });
  }
  // Wiederherstellen mit Auswahl: Sicherungen auflisten, Inhalt einer Sicherung zeigen, Ausgewähltes zurückholen
  if (p === "/api/parent/backups" && m === "GET") return send(res, 200, await listBackups());
  const bkMatch = p.match(/^\/api\/parent\/backups\/([\w.-]+)(\/restore)?$/);
  if (bkMatch) {
    try {
      if (!bkMatch[2] && m === "GET") return send(res, 200, backupContents(await readBackup(bkMatch[1])));
      if (bkMatch[2] && m === "POST") {
        if (!confirmPassword(req, res)) return;
        const b = await readJson(req);
        const ids = (x) => (Array.isArray(x) ? x.filter((v) => typeof v === "string" && /^[a-f0-9]{16}$/.test(v)) : []);
        return send(res, 200, await restoreFromBackup(bkMatch[1], { kids: ids(b.kids), convos: ids(b.convos), avatars: ids(b.avatars), settings: b.settings === true, keys: b.keys === true, devices: b.devices === true, all: b.all === true }));
      }
    } catch (e) { if (e.status) return send(res, e.status, { error: e.message }); throw e; }
    return send(res, 405, { error: "Methode" });
  }

  if (p === "/api/parent/test" && m === "POST") {
    if (!rateLimit("test", 10, 60 * 60_000)) return send(res, 429, { error: "Zu viele Tests" });
    const b = await readJson(req, 4 * 1024).catch(() => ({}));
    // Getestet wird die gespeicherte globale Wahl, oder ein gerade ausgewählter, schon eingerichteter Anbieter
    let choice = choiceFor(null);
    if (b.provider && b.model && providerConfigured(b.provider) && validChoice(b.provider, b.model)) choice = { provider: b.provider, model: b.model };
    if (!choice) return send(res, 400, { error: "Noch kein KI-Anbieter eingerichtet" });
    try {
      const r = await aiChat(choice, { maxTokens: 1500, system: "Du bist ein freundlicher Assistent.", messages: [{ role: "user", content: "Sag in einem kurzen Satz auf Deutsch Hallo zu einem Kind." }] });
      db.global[globalMonth()] += costUsd(choice.provider, choice.model, r.usage);
      await saveDb();
      return send(res, 200, { ok: true, model: modelLabel(choice.provider, choice.model), text: r.text.trim() });
    } catch (e) {
      return send(res, 502, { error: AI.errorText(e, choice.provider) });
    }
  }

  // ------------------------------------------------ weitere KI-Anbieter
  const provMatch = p.match(/^\/api\/parent\/providers\/([a-z]+)(\/check|\/ack)?$/);
  if (provMatch) {
    const pid = provMatch[1], action = provMatch[2];
    const cat = CATALOG.providers[pid];
    if (!cat) return send(res, 404, { error: "Unbekannter Anbieter" });
    if (pid === "anthropic" && !action) return send(res, 400, { error: "Claude-Schlüssel bitte im Feld „Claude-Verbindung“ eintragen" });
    db.settings.providerChecks ||= {};

    // Schlüssel (bzw. Ollama-Adresse) speichern: wird kostenlos geprüft (Modellliste), dann verschlüsselt gespeichert
    if (!action && m === "PUT") {
      if (!rateLimit("provkey", 20, 60 * 60_000)) return send(res, 429, { error: "Zu viele Versuche" });
      const b = await readJson(req, 8 * 1024);
      if (pid === "ollama") {
        const url = String(b.url || "").trim().replace(/\/+$/, "") || AI.baseUrl("ollama");
        if (!/^https?:\/\/[^\s/]+(\/[\w.\/-]*)?$/.test(url)) return send(res, 400, { error: "Adresse bitte so: http://127.0.0.1:11434" });
        let models;
        try { models = await AI.listModels("ollama", "", url); } catch (e) { return send(res, 400, { error: AI.errorText(e, "ollama") }); }
        if (!models.length) return send(res, 400, { error: "Ollama läuft, hat aber noch kein Modell. In einer Konsole z. B. „ollama pull gemma3:4b“ ausführen." });
        db.settings.ollama = { enabled: true, url };
        (db.settings.discoveredModels ||= {}).ollama = models.slice(0, 50);
      } else {
        if (ENV_KEYS[pid]) return send(res, 409, { error: "Der Schlüssel kommt aus der .env-Datei. Dort ändern oder entfernen." });
        const key = String(b.key || "").trim();
        if (!AI.keyLooksValid(pid, key)) return send(res, 400, { error: `Das sieht nicht wie ein ${cat.label}-Schlüssel aus${cat.keyHint ? " (" + cat.keyHint + ")" : ""}.` });
        let models;
        try { models = await AI.listModels(pid, key); } catch (e) { return send(res, 400, { error: "Schlüssel funktioniert nicht: " + AI.errorText(e, pid) }); }
        db.secrets = { ...(db.secrets || {}), providers: { ...(db.secrets?.providers || {}), [pid]: { key } } };
        (db.settings.discoveredModels ||= {})[pid] = models.slice(0, 200);
      }
      await saveDb();
      return send(res, 200, parentView(req));
    }
    if (!action && m === "DELETE") {
      if (ENV_KEYS[pid]) return send(res, 409, { error: "Der Schlüssel kommt aus der .env-Datei." });
      if (pid === "ollama") delete db.settings.ollama;
      else if (db.secrets?.providers) delete db.secrets.providers[pid];
      delete db.settings.discoveredModels?.[pid];
      delete db.settings.providerAck?.[pid];
      // Wer diesen Anbieter nutzte, fällt auf den Standard zurück
      for (const k of db.kids) if (k.provider === pid) { k.provider = ""; k.model = ""; }
      if (db.settings.provider === pid) { db.settings.provider = DEFAULT_PROVIDER; db.settings.model = DEFAULT_MODEL; }
      await saveDb();
      return send(res, 200, parentView(req));
    }

    // Optionaler Kinderfragen-Test: kritische Fragen mit der echten Persona (Testkind, 7 Jahre), Antworten für Eltern zum Lesen
    if (action === "/check" && m === "POST") {
      if (!providerConfigured(pid)) return send(res, 400, { error: "Erst Schlüssel eintragen" });
      if (!rateLimit("provcheck", 6, 60 * 60_000)) return send(res, 429, { error: "Zu viele Tests. Bitte in einer Stunde nochmal." });
      const b = await readJson(req, 4 * 1024).catch(() => ({}));
      const model = validChoice(pid, b.model) ? b.model : defaultModel(pid);
      if (!model) return send(res, 400, { error: "Kein Modell gefunden" });
      const choice = { provider: pid, model };
      const kid = testKid();
      // Mit dem Standard-Modus (Erkunden), so wie ein Kind die App meist nutzt
      const system = systemFor(kid, MODES.find((x) => x.id === DEFAULT_MODE) || null);
      let usd = 0;
      // Lokal (Ollama) nacheinander, sonst parallel
      const run = async (q) => {
        try {
          const r = await aiChat(choice, { maxTokens: 1500, system, messages: [{ role: "user", content: q.q }] });
          usd += costUsd(pid, model, r.usage);
          return { id: q.id, topic: q.topic, q: q.q, answer: r.text.trim(), refused: r.refused, ...judgeAnswer(q, r.text, r.refused) };
        } catch (e) { return { id: q.id, topic: q.topic, q: q.q, answer: "", error: AI.errorText(e, pid), ok: false, problems: ["Fehler: " + AI.errorText(e, pid)] }; }
      };
      const results = [];
      if (pid === "ollama") for (const q of KIDS_QUESTIONS) results.push(await run(q));
      else results.push(...await Promise.all(KIDS_QUESTIONS.map(run)));
      db.global[globalMonth()] += usd;
      const passed = results.filter((r) => r.ok).length;
      db.settings.providerChecks[pid] = { at: new Date().toISOString(), model, passed, total: results.length, usd: +usd.toFixed(4), results };
      await saveDb();
      return send(res, 200, parentView(req));
    }
    // Häkchen "Ich habe verstanden, ungetestet": macht den Anbieter wählbar. Abhaken setzt Kinder auf den Standard zurück.
    if (action === "/ack" && m === "POST") {
      if (pid === "anthropic") return send(res, 400, { error: "Claude braucht keine Bestätigung" });
      const b = await readJson(req, 1024);
      db.settings.providerAck ||= {};
      if (b.ack === true) db.settings.providerAck[pid] = { at: new Date().toISOString() };
      else {
        delete db.settings.providerAck[pid];
        for (const k of db.kids) if (k.provider === pid) { k.provider = ""; k.model = ""; }
        if (db.settings.provider === pid) { db.settings.provider = DEFAULT_PROVIDER; db.settings.model = DEFAULT_MODEL; }
      }
      await saveDb();
      return send(res, 200, parentView(req));
    }
    return send(res, 405, { error: "Methode nicht erlaubt" });
  }

  return send(res, 404, { error: "Unbekannt" });
}

// Eltern verlängern am Kindergerät, wenn ein Limit erreicht ist. Nur mit Eltern-Passwort;
// gleiche Sperre gegen Raten wie beim Login (5 Fehlversuche pro Gerät/IP in 15 Minuten).
async function extendLimit(req, res) {
  const dev = deviceOf(req);
  if (!dev && !isParent(req)) return send(res, 401, { error: "Gerät nicht freigegeben" });
  const ip = clientIp(req);
  const b = await readJson(req);
  const kid = db.kids.find((k) => k.id === b.kidId);
  if (!kid) return send(res, 404, { error: "Kind nicht gefunden" });
  const choice = b.minutes === "today" ? "today" : Number(b.minutes);
  if (!EXTEND_CHOICES.includes(choice)) return send(res, 400, { error: "Ungültige Dauer" });
  const keys = ["login:" + ip, "login:all", ...(dev ? ["login:dev:" + dev.id] : [])];
  const blocked = keys.some((k) => { const x = buckets.get(k); return x && Date.now() <= x.reset && x.n >= (k === "login:all" ? 20 : 5); });
  if (blocked) return send(res, 429, { error: "Zu viele Versuche. Bitte 15 Minuten warten." });
  if (!checkPassword(String(b.password || ""), db.parent)) {
    for (const k of keys) rateLimit(k, k === "login:all" ? 20 : 5, 15 * 60_000);
    return send(res, 401, { error: "Passwort falsch" });
  }
  const r = applyExtension(kid, choice, dev?.name || "Eltern-Bereich");
  if (r.error) return send(res, r.status, { error: r.error });
  const u = r.u;
  await saveDb();
  const untilText = u.ext.allDay ? "für heute" : "bis " + localParts(new Date(u.ext.until)).time + " Uhr";
  return send(res, 200, { ok: true, allDay: !!u.ext.allDay, until: u.ext.until || null,
    say: `Juhu, ${kid.name}! Mama oder Papa haben verlängert. Wir können ${untilText} weiter quatschen.` });
}
// Gemeinsame Verlängerung für Kindergerät und Eltern-Bereich: gilt nur heute, Dollar-Budgets bleiben hart.
function applyExtension(kid, minutes, deviceName) {
  const choice = minutes === "today" ? "today" : Number(minutes);
  if (!EXTEND_CHOICES.includes(choice)) return { error: "Ungültige Dauer", status: 400 };
  const reason = limitMessage(kid, true) ? limitName(kid) : "vorsorglich";
  if (reason === "Budget") return { error: "Das Dollar-Budget ist aufgebraucht. Das lässt sich nur unter Einstellungen › KI-Anbieter ändern.", status: 409 };
  const { u } = kidUsage(kid.id);
  const now = Date.now();
  const prev = extensionActive(kid.id);
  const base = prev && !prev.allDay ? Math.max(now, prev.until) : now;
  u.ext = choice === "today" ? { date: u.date, allDay: true } : { date: u.date, until: base + choice * 60_000 };
  db.extensions ||= [];
  db.extensions.push({ at: new Date(now).toISOString(), kidId: kid.id, kidName: kid.name, minutes: choice, reason, device: deviceName });
  if (db.extensions.length > 200) db.extensions.splice(0, db.extensions.length - 200);
  console.log(`Verlängerung für ${kid.name}: ${choice === "today" ? "für heute" : choice + " Min."} (${reason})`);
  return { u };
}

// Gefährliche Aktionen (viel löschen, Kind löschen, Schlüssel entfernen, Wiederherstellen) brauchen das
// Eltern-Passwort noch einmal, im Header X-LC-Confirm (URI-kodiert). Gleiche Sperre gegen Raten wie beim Login.
// Antwortet 403 statt 401, damit ein Tippfehler nicht abmeldet.
function confirmPassword(req, res) {
  const ip = clientIp(req);
  const keys = ["login:" + ip, "login:all"];
  const blocked = keys.some((k) => { const x = buckets.get(k); return x && Date.now() <= x.reset && x.n >= (k === "login:all" ? 20 : 5); });
  if (blocked) { send(res, 429, { error: "Zu viele Versuche. Bitte 15 Minuten warten." }); return false; }
  let pw = "";
  try { pw = decodeURIComponent(String(req.headers["x-lc-confirm"] || "")); } catch {}
  if (!pw || !checkPassword(pw, db.parent)) {
    for (const k of keys) rateLimit(k, k === "login:all" ? 20 : 5, 15 * 60_000);
    send(res, 403, { error: pw ? "Passwort falsch." : "Bitte zur Bestätigung das Eltern-Passwort eingeben." });
    return false;
  }
  return true;
}

// Tagesrückblick: was die Kinder heute besprochen haben, für die Eltern. Einmal erzeugt und zwischengespeichert;
// neu nur auf Wunsch oder wenn seit dem letzten Rückblick neue Gespräche dazukamen (frühestens nach 20 Minuten).
const DIGEST_MIN_AGE = 20 * 60_000;
async function digestToday(how) {
  const { date } = localParts();
  const todays = db.convos.filter((c) => c.kidId && localParts(new Date(c.updated)).date === date && c.messages?.length);
  const sig = todays.map((c) => c.id + ":" + c.messages.length).sort().join(",");
  const cur = db.digest?.date === date ? db.digest : null;
  const stale = !cur || cur.sig !== sig;
  if (!todays.length) return { date, text: "", empty: true };
  if (how === "cached" || (how === "stale" && (!stale || (cur && Date.now() - Date.parse(cur.at) < DIGEST_MIN_AGE))))
    return cur ? { date, text: cur.text, at: cur.at, stale } : { date, text: "", stale: true };
  // Pro Kind derselbe Anbieter wie in seinen Gesprächen: Daten wandern nie zu einem zweiten Anbieter
  const groups = new Map();
  for (const k of db.kids) {
    const mine = todays.filter((c) => c.kidId === k.id);
    const choice = mine.length && choiceFor(k);
    if (!choice) continue;
    const sc = summaryChoice(choice);
    const lines = mine.map((c) => {
      const asked = c.messages.filter((x) => x.role === "user" && localParts(new Date(x.at)).date === date).map((x) => (x.refused ? "[abgelehnt] " : "") + x.text.slice(0, 160));
      const mode = modeById(c.mode);
      return `- Gespräch „${c.title}“${mode ? ` (Modus ${mode.name})` : ""}${c.kidPoppedAt ? " (vom Kind zerplatzt)" : ""}: ` + asked.slice(-12).join(" | ");
    });
    const key = sc.provider + "|" + sc.model;
    if (!groups.has(key)) groups.set(key, { sc, parts: [] });
    groups.get(key).parts.push(`${k.name}, ${ageFrom(k.birth)} Jahre:\n` + lines.join("\n").slice(0, 4000));
  }
  if (!groups.size) throw new Error("kein KI-Anbieter eingerichtet");
  const texts = [];
  for (const { sc, parts } of groups.values()) {
    const r = await aiChat(sc, {
      maxTokens: 700,
      system: "Du schreibst für Eltern einen kurzen Tagesrückblick zur Kinder-App " + appName() + ". " +
        "Pro Kind zwei bis drei Sätze: worüber es gesprochen hat, was es gelernt oder erfunden hat. " +
        "Wenn etwas auffällt, sag es sachlich in einem eigenen Satz (abgelehnte Fragen, Angst, Streit, heikle Themen, persönliche Daten). Fällt nichts auf, erwähne das nicht. " +
        "Nur Fakten aus den Fragen der Kinder, nichts erfinden, nicht bewerten. Deutsch, freundlich, gesprochene Sprache ohne Listen, Fettdruck oder Emojis. Höchstens 120 Wörter.",
      messages: [{ role: "user", content: "Die Fragen der Kinder von heute:\n\n" + parts.join("\n\n") }],
    });
    db.global[globalMonth()] += costUsd(sc.provider, sc.model, r.usage);
    texts.push(String(r.text || "").trim());
  }
  db.digest = { date, sig, at: new Date().toISOString(), text: texts.join("\n\n").slice(0, 3000) };
  await saveDb();
  return { date, text: db.digest.text, at: db.digest.at, stale: false };
}

function limitName(kid) {
  const { u, month } = kidUsage(kid.id);
  const { time } = localParts();
  if (!inWindow(time, kid.from, kid.to)) return "Uhrzeit";
  if (kid.minutesPerDay > 0 && u.minutes >= kid.minutesPerDay) return "Minuten";
  if (kid.questionsPerDay > 0 && u.questions >= kid.questionsPerDay) return "Fragen";
  if (kid.tokensPerDay > 0 && u.tokens >= kid.tokensPerDay) return "Tokens";
  return "Budget";
}

function loginOk(res) {
  const t = token();
  const now = Date.now();
  parentSessions.set(sha256(t), { exp: now + PARENT_IDLE_MS, max: now + PARENT_MAX_MS });
  return send(res, 200, { ok: true, idleMin: PARENT_IDLE_MS / 60_000 }, { "Set-Cookie": cookie("lc_parent", t, null) });
}

// ---------------------------------------------------------------- Avatare
// Was die KI im Gespräch über Avatare weiß: im Avatar-Modus den Stand, sonst einen Hinweis auf den Kreativ-Modus
function avatarMemory(kid, mode, editing = null, story = null) {
  const list = kidAvatars(kid.id);
  const allowed = kidModes(kid);
  if (mode?.avatars && story) return "Avatare: " + AV.storyState(kid.name, story);
  if (mode?.avatars && editing) return "Avatare: " + AV.editState(kid.name, editing) +
    "\n\n" + AV.otherModesHint(kid.name, allowed.filter((m) => m.id !== mode.id));
  if (mode?.avatars) return "Avatare: " + AV.avatarState(kid.name, list, activeAvatar(kid)?.id) +
    "\n\n" + AV.otherModesHint(kid.name, allowed.filter((m) => m.id !== mode.id));
  const avMode = allowed.find((m) => m.avatars);
  return avMode ? "Avatare: " + AV.avatarHintOtherMode(kid.name, list.length > 0, avMode, !!mode?.figurTip) : "";
}
// Alle Avatare (Elternbereich) und die sichtbaren (Kind). Vom Kind gelöschte haben hiddenAt.
const allAvatars = (kidId) => db.avatars.filter((a) => a.kidId === kidId).sort((a, b) => a.created.localeCompare(b.created));
const kidAvatars = (kidId) => allAvatars(kidId).filter((a) => !a.hiddenAt);
const activeAvatar = (kid) => (kid.avatarId && db.avatars.find((a) => a.id === kid.avatarId && a.kidId === kid.id && !a.hiddenAt)) || null;
const avatarView = (kid) => (a) => ({ id: a.id, name: a.name, desc: a.desc, svg: AV.styledSvg(a.svg), created: a.created, active: kid.avatarId === a.id && !a.hiddenAt,
  ...(a.hiddenAt ? { hiddenAt: a.hiddenAt } : {}) });
function hideAvatar(av) {
  av.hiddenAt = new Date().toISOString();
  for (const k of db.kids) if (k.avatarId === av.id) k.avatarId = null;
}
function deleteAvatar(av) {
  db.avatars = db.avatars.filter((a) => a !== av);
  for (const k of db.kids) if (k.avatarId === av.id) k.avatarId = null;
}
// Die KI des Kindes zeichnet den Avatar als SVG; der Server baut daraus ein sicheres SVG.
// Liefert den Satz, den die App danach vorliest, und bei Erfolg die Kennung des neuen Avatars.
const drawing = new Set();
async function drawAvatar(kid, choice, mark, convo, replace = null) {
  if (!replace && kidAvatars(kid.id).length >= AV.MAX_AVATARS)
    return { say: `Oh, du hast schon ${AV.MAX_AVATARS} Avatare. Wenn du einen neuen willst, halte erst eine Avatar-Seifenblase lange fest und tipp auf das rote X, dann ist Platz.` };
  if (drawing.has(kid.id)) return { say: "Ich zeichne gerade schon. Einen Moment!" };
  drawing.add(kid.id);
  try {
    // Jede Anfrage an die KI zählt auf Tokens und Kosten des Kindes
    const call = async (system, content, maxTokens = 8000) => {
      const r = await aiChat(choice, { maxTokens, system, messages: [{ role: "user", content }] });
      const { u, month } = kidUsage(kid.id);
      const cost = costUsd(choice.provider, r.model || choice.model, r.usage);
      u.tokens += AI.totalTokens(r.usage);
      u.months[month] += cost;
      db.global[globalMonth()] += cost;
      return r;
    };
    for (let attempt = 0; attempt < 2; attempt++) {
      const r = await call(AV.DRAW_SYSTEM, replace ? AV.redrawRequest(replace, mark) : `Zeichne diesen Avatar.\nName: ${mark.name}\nBeschreibung: ${mark.desc}`);
      let svg = !r.refused && AV.sanitizeSvg(r.text);
      if (!svg) continue;
      // Selbstprüfung: fehlen Merkmale oder sitzt das Gesicht schief, einmal mit genau diesen Hinweisen nachbessern
      try {
        const c = await call(AV.CHECK_SYSTEM, AV.checkRequest(mark.name, mark.desc, svg), 1200);
        if (!c.refused && c.text && !AV.checkPassed(c.text)) {
          const f = await call(AV.DRAW_SYSTEM, AV.fixRequest(mark.name, mark.desc, svg, c.text));
          const fixed = !f.refused && AV.sanitizeSvg(f.text);
          if (fixed) svg = fixed;
        }
      } catch (e) { console.error("[avatar-check]", choice.provider, AI.errorText(e, choice.provider)); }
      if (replace) {
        // Umgestaltet: gleiche Kennung, Platz und Profilbild bleiben
        Object.assign(replace, { name: mark.name, desc: mark.desc, svg, updated: new Date().toISOString() });
        delete convo.avatarEdit;
        await saveDb();
        return { id: replace.id, say: `Tadaa! ${replace.name} ist fertig umgestaltet und fliegt oben in der Seifenblase herum.` };
      }
      const av = { id: id(), kidId: kid.id, name: mark.name, desc: mark.desc, svg, created: new Date().toISOString(), convoId: convo.id };
      db.avatars.push(av);
      const first = !activeAvatar(kid);
      if (first) kid.avatarId = av.id;
      await saveDb();
      return { id: av.id, say: first
        ? `Tadaa! ${av.name} ist fertig und ist jetzt dein Profilbild. Schau mal, ${av.name} fliegt oben als Seifenblase herum.`
        : `Tadaa! ${av.name} ist fertig und fliegt oben als Seifenblase herum. Tipp drauf, wenn ${av.name} dein Profilbild werden soll.` };
    }
    return { say: "Hoppla, das Bild ist mir leider verwischt. Sag einfach nochmal, dass ich zeichnen soll." };
  } catch (e) {
    console.error("[avatar]", choice.provider, AI.errorText(e, choice.provider));
    return { say: "Hoppla, mein Malstift streikt gerade. Versuch es gleich nochmal." };
  } finally {
    drawing.delete(kid.id);
  }
}

async function talk(req, res) {
  reportBusy();
  const dev = deviceOf(req);
  if (!dev) return send(res, 401, { error: "Gerät nicht freigegeben" });
  if (!rateLimit("talk:" + dev.id, TALK_PER_MIN, 60_000)) return send(res, 429, { say: "Nicht so schnell! Ich muss erst mal Luft holen. Frag mich gleich nochmal." });
  if (!anyProvider()) return send(res, 503, { say: "Ich bin noch nicht eingeschaltet. Frag Mama oder Papa." });

  const b = await readJson(req, 8 * 1024);
  const kid = db.kids.find((k) => k.id === b.kidId);
  if (!kid) return send(res, 404, { error: "Kind nicht gefunden" });
  if (!kidUnlocked(dev, kid)) return send(res, 423, { say: `Dieses Profil ist mit Farben abgeschlossen. Geh zurück und tipp nochmal auf ${kid.name}.` });
  dev.lastKidId = kid.id;
  // Antippen einer Avatar-Blase: "ändern" startet ein Gespräch zum Umgestalten, "Geschichte" erzählt eine kurze
  // Fantasiegeschichte. Beides läuft als neues Gespräch im Avatar-Modus (Kreativ); der Kindersatz kommt vom Server.
  const avId = b.avatarEdit || b.avatarStory;
  const avTarget = avId ? kidAvatars(kid.id).find((a) => a.id === avId) : null;
  const avMode = avId ? kidModes(kid).find((m) => m.avatars) : null;
  if (avId && (!avTarget || !avMode)) return send(res, 404, { say: "Hm, diesen Avatar finde ich gerade nicht." });
  if (avTarget) { b.convoId = null; b.mode = avMode.id; b.text = b.avatarEdit ? `Ich möchte ${avTarget.name} ändern.` : `Erzähl mir eine Geschichte von ${avTarget.name}.`; }
  const text = String(b.text || "").trim().slice(0, MAX_TEXT);
  if (!text) return send(res, 400, { say: "Ich habe nichts gehört. Drück die Taste und sprich, solange du sie festhältst." });

  const choice = choiceFor(kid);
  if (!choice) return send(res, 503, { say: "Ich bin noch nicht eingeschaltet. Frag Mama oder Papa." });
  const limit = limitMessage(kid);
  if (limit) return send(res, 200, limit, { "X-LC-Limit": limitName(kid) === "Budget" ? "budget" : "1" });

  // Gespräch fortsetzen (Seifenblase) oder neu beginnen
  if (b.convoId && topicChecks.has(b.convoId)) await topicChecks.get(b.convoId); // Themen-Prüfung der letzten Antwort abwarten
  let convo = b.convoId ? db.convos.find((c) => c.id === b.convoId && c.kidId === kid.id && !c.kidPoppedAt) : null;
  // Wurde das Gespräch wegen eines Themenwechsels geteilt, geht es in der neuen Blase weiter
  // (nur einmal: tippt das Kind später die alte Blase an, geht es dort weiter)
  for (let i = 0; convo?.splitTo && i < 20; i++) {
    const next = db.convos.find((c) => c.id === convo.splitTo && c.kidId === kid.id && !c.kidPoppedAt) || null;
    delete convo.splitTo;
    convo = next;
  }
  if (!convo || convo.messages.length >= MAX_CONVO_MESSAGES) {
    const now = new Date().toISOString();
    convo = { id: id(), kidId: kid.id, deviceId: dev.id, emoji: "💬", title: text.slice(0, 30), recap: "", created: now, updated: now, messages: [] };
    db.convos.push(convo);
  }
  // Modus: ein Gespräch behält seinen Modus. Neue Gespräche nehmen den gewählten, wenn er freigeschaltet ist.
  // Haben Eltern den Modus inzwischen abgeschaltet, läuft auch ein altes Gespräch im Standardmodus weiter.
  const mode = resolveMode(kid, convo.messages.length ? convo.mode : b.mode);
  convo.mode = mode?.id || null;
  if (mode?.avatars && !convo.messages.length) convo.emoji = mode.emoji; // Avatar-Blase zeigt gleich das Symbol des Knopfs
  if (avTarget && b.avatarEdit) convo.avatarEdit = avTarget.id;
  const editing = mode?.avatars && convo.avatarEdit ? kidAvatars(kid.id).find((a) => a.id === convo.avatarEdit) || null : null;

  const { u, month } = kidUsage(kid.id);
  trackTime(kid.id);
  u.questions++;

  // Nur Text geht als Verlauf zurück (keine Denk-Blöcke): so lassen sich alte Gespräche
  // auch Tage später fortsetzen und auf ein Fenster kürzen. Ältere Teile stecken in convo.memory.
  // Persona, Modi und Sicherheitsregeln sind bei jedem Anbieter derselbe Systemprompt.
  const messages = [...contextWindow(convo).map((m) => ({ role: m.role, content: m.text })), { role: "user", content: text }];
  // Avatar-Runden: Sobald im Avatar-Modus über einen Avatar gesprochen wird, zählt jede Kinder-Antwort als Runde.
  // Nach 3 Runden und danach alle 3 weiteren fragt die KI, ob es so passt und ob ihr ihn fertig macht (Timo).
  if (mode?.avatars && convo.avatarRounds !== undefined) convo.avatarRounds++;
  const memory = [convo.memory ? `Zusammenfassung des bisherigen Gesprächs mit ${kid.name} (ältere Teile):\n${convo.memory}` : "",
    avatarMemory(kid, mode, editing, avTarget && b.avatarStory ? avTarget : null),
    mode?.avatars ? AV.roundHint(kid.name, convo.avatarRounds) : AV.buttonsHint(kid.name, kidModes(kid).filter((m) => m.id !== mode?.id))].filter(Boolean).join("\n\n");
  // Persona und Modus bilden zusammen den gecachten Anfang (bei Claude Cache-Marke am letzten Block,
  // bei den anderen Anbietern ein gemeinsamer Systemprompt)
  const system = systemFor(kid, mode);

  res.writeHead(200, {
    ...SECURITY_HEADERS,
    "Content-Type": "text/plain; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Accel-Buffering": "no",
    "X-Convo-Id": convo.id,
    "X-Convo-Mode": convo.mode || "",
  });

  const ctl = new AbortController();
  let aborted = false;
  res.on("close", () => { if (!res.writableEnded) { aborted = true; ctl.abort(); } });

  let wrote = false;
  // Avatar-Marken ([[AVATAR: …]]) gehen nie an das Gerät, sonst würden sie vorgelesen
  const out = AV.markFilter((t) => { wrote = true; res.write(t); });
  try {
    const final = await aiChat(choice, {
      system, memory, messages, signal: ctl.signal,
      maxTokens: choice.provider === "anthropic" ? 4000 : 1500,
      onText: (t) => out.push(t),
    });
    out.end();
    const answer = AV.stripMarks(final.text);
    const mark = mode?.avatars && !final.refused && !(avTarget && b.avatarStory) ? AV.parseMark(final.text) : null;
    const actions = mode?.avatars && !final.refused ? AV.parseActions(final.text) : [];
    const cost = costUsd(choice.provider, final.model || choice.model, final.usage);
    u.tokens += AI.totalTokens(final.usage);
    u.months[month] += cost;
    db.global[globalMonth()] += cost;
    const at = new Date().toISOString();
    if (final.refused) {
      const say = "Darüber kann ich leider nicht sprechen. Frag doch mal Mama oder Papa.";
      if (!wrote) res.write(say);
      // Für Eltern sichtbar protokollieren, aber nicht als Kontext an Claude zurückgeben
      convo.messages.push({ role: "user", text, at }, { role: "assistant", text: answer || say, at, refused: true });
      convo.flagged = true; // Eltern sehen im Verlauf einen Hinweis
    } else {
      convo.messages.push({ role: "user", text, at }, { role: "assistant", text: answer.trim(), at });
    }
    convo.provider = choice.provider; // für Eltern: welcher Anbieter hat geantwortet
    convo.model = choice.model;
    convo.updated = at;
    const n = convo.messages.length;
    // Titel/Gedächtnis auffrischen; vorher prüfen, ob ein neues Thema begonnen hat (dann neue Seifenblase)
    watchTopic(kid, choice, convo, mode, n === 2 || n === 6 || n === 14 || needsMemory(convo));
    // Sprachbefehl Profilbild; die App lädt danach die Blasen neu. Löschen geht nur per Festhalten + Mülleimer.
    const said = [];
    for (const a of actions) {
      const av = AV.findByName(kidAvatars(kid.id), a.name);
      if (!av) { said.push(`Hm, einen Avatar namens ${a.name} finde ich nicht.`); continue; }
      if (a.action === "activate") kid.avatarId = av.id;
    }
    // Avatar-Gespräch beginnt: ab jetzt Runden zählen (nicht bei der Geschichte)
    // Im Avatar-Modus geht es immer um Avatare: Runden zählen ab der ersten Antwort, nicht erst, wenn das Wort fällt (Timo)
    if (mode?.avatars && convo.avatarRounds === undefined && !(avTarget && b.avatarStory)) convo.avatarRounds = 0;
    // Ändern abgebrochen: der Avatar bleibt, wie er ist
    if (editing && !final.refused && AV.KEEP_RE.test(final.text)) delete convo.avatarEdit;
    if (actions.length) {
      await saveDb();
      if (!res.writableEnded && !aborted) res.write((said.length ? "\n" + said.join(" ") : "") + "\u001eavatars\u001e");
    }
    if (mark) {
      // Zeichnen läuft weiter, auch wenn das Kind die Antwort unterbricht: das Bild kommt dann als Seifenblase
      const r = await drawAvatar(kid, choice, mark, convo, editing);
      // Fertig: Die Blase dieses Gesprächs platzt für das Kind, der Avatar ist jetzt die Blase. Eltern lesen das Gespräch weiter.
      if (r.id) { convo.kidPoppedAt = new Date().toISOString(); convo.poppedByAvatar = true; delete convo.avatarRounds; }
      if (!res.writableEnded && !aborted) res.write("\n" + r.say + (r.id ? `\u001eavatar:${r.id}\u001e` : ""));
    }
  } catch (e) {
    if (!aborted) {
      console.error("[talk]", choice.provider, AI.errorText(e, choice.provider));
      if (!wrote) res.write("Hoppla, ich habe gerade Funkstörung. Versuch es gleich nochmal.");
    }
  } finally {
    saveDb().catch((e) => console.error("[db]", e));
    if (!res.writableEnded) res.end();
  }
}

// Optionale lokale Spracherkennung: Audio vom Kinder-Gerät an einen Whisper-Server im Heimnetz weiterreichen.
async function stt(req, res) {
  const dev = deviceOf(req);
  if (!dev) return send(res, 401, { error: "Gerät nicht freigegeben" });
  if (!STT_URL) return send(res, 404, { error: "Keine Server-Spracherkennung eingerichtet" });
  if (!rateLimit("stt:" + dev.id, TALK_PER_MIN * 2, 60_000)) return send(res, 429, { error: "Zu viele Aufnahmen" });
  const type = String(req.headers["content-type"] || "audio/webm").split(";")[0];
  if (!/^audio\//.test(type)) return send(res, 415, { error: "Nur Audio" });
  const audio = await readRaw(req, 10 * 1024 * 1024);
  const ext = type.includes("mp4") ? "m4a" : type.includes("ogg") ? "ogg" : type.includes("wav") ? "wav" : "webm";
  const form = new FormData();
  form.append("file", new Blob([audio], { type }), "aufnahme." + ext);
  form.append("model", STT_MODEL);
  form.append("language", "de");
  try {
    const r = await fetch(STT_URL, { method: "POST", body: form, signal: AbortSignal.timeout(30_000) });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const j = await r.json();
    return send(res, 200, { text: String(j.text || "").trim().slice(0, MAX_TEXT) });
  } catch (e) {
    console.error("[stt]", e.message);
    return send(res, 502, { error: "Spracherkennung nicht erreichbar" });
  }
}

// ---------------------------------------------------------------- Sprachausgabe (serverseitig)
// "piper":   eigene Stimme auf dem Server (kostenlos, privat, klingt überall gleich). Standard.
// "google", "azure", "elevenlabs": Cloud-Stimmen mit eigenem Schlüssel (lib/voices.js).
//            Der Antworttext geht an den Dienst. Fällt er aus oder ist das Budget erreicht: Piper.
// "browser": Systemstimme des jeweiligen Geräts (kostenlos, Klang und Verfügbarkeit je nach Gerät).
// "custom":  eigener OpenAI-kompatibler Sprach-Server im Heimnetz.
// OpenAI-Stimmen gibt es nicht mehr (Abschaltung durch OpenAI am 6.1.2027, Timo: weglassen). Wer sie gewählt
// hatte, spricht automatisch mit Piper; der alte Stimmen-Schlüssel wird beim Start gelöscht.
const TTS_PROVIDERS = ["piper", "google", "azure", "elevenlabs", "browser", "custom"];
const TTS_DEFAULT = { provider: "browser", url: "", model: "", customVoice: "", piperVoice: "", piperSpeaker: "", piperSpeed: 1.1,
  googleVoice: "", azureVoice: "", azureRegion: "", elevenVoice: "", elevenModel: "", cloudRate: 1 };
const ttsCache = new Map(); // kurze, häufige Sätze im Speicher (auch Piper)
// Schlüssel je Dienst getrennt: ein Schlüssel geht nie an einen anderen Dienst.
const TTS_SLOT = { custom: "ttsCustomKey", google: "ttsGoogleKey", azure: "ttsAzureKey", elevenlabs: "ttsElevenKey" };
const TTS_ENV = {};
for (const [svc, v] of [["google", "LC_GOOGLE_TTS_KEY"], ["azure", "LC_AZURE_TTS_KEY"], ["elevenlabs", "LC_ELEVENLABS_API_KEY"]]) { TTS_ENV[svc] = process.env[v] || ""; delete process.env[v]; }
function ttsKeyFor(svc) {
  return VOICES.cleanKey(TTS_ENV[svc] || db.secrets?.[TTS_SLOT[svc]] || "");
}
function ttsKeySource(svc) {
  return TTS_ENV[svc] ? "env" : db.secrets?.[TTS_SLOT[svc]] ? "db" : null;
}
function ttsConfigured(svc, t = ttsSettingsRaw()) {
  if (svc === "browser") return true;
  if (svc === "piper") return piperVoices().length > 0;
  if (svc === "custom") return /^https?:\/\/\S+$/.test(t.url || "");
  if (!TTS_PROVIDERS.includes(svc)) return false;
  if (svc === "azure" && !VOICES.validRegion(t.azureRegion)) return false;
  if (svc === "elevenlabs" && !t.elevenVoice) return false;
  return !!ttsKeyFor(svc);
}
const ttsVoiceField = { piper: "piperVoice", google: "googleVoice", azure: "azureVoice", elevenlabs: "elevenVoice" };
// Ausfälle merken: zwei Minuten lang nicht erneut versuchen, damit nicht jeder Satz auf ein Zeitlimit wartet
const ttsDown = {};

// ---- Piper: kostenlose, lokale Stimmen. Läuft auf dem Server, klingt daher auf jedem Tablet gleich.
const PIPER_DIR = process.env.LC_PIPER_DIR || path.join(ROOT, "piper");
const PIPER_BIN = process.env.LC_PIPER_BIN || path.join(PIPER_DIR, "piper", process.platform === "win32" ? "piper.exe" : "piper");
const PIPER_PREFERENCE = ["de_DE-thorsten-high", "de_DE-kerstin-low", "de_DE-thorsten-medium", "de_DE-thorsten_emotional-medium", "de_DE-mls-medium"];
let piperVoiceCache = null;
function piperVoices() {
  if (piperVoiceCache) return piperVoiceCache;
  let list = [];
  try {
    if (fs.existsSync(PIPER_BIN)) {
      const dir = path.join(PIPER_DIR, "voices");
      for (const f of fs.readdirSync(dir).filter((x) => x.endsWith(".onnx") && fs.existsSync(path.join(dir, x + ".json")))) {
        const id = f.replace(/\.onnx$/, "");
        const cfg = JSON.parse(fs.readFileSync(path.join(dir, f + ".json"), "utf8"));
        const cat = Object.values(PIPER_CATALOG).find((v) => v.file === id);
        list.push({ id, label: cat?.label || id, license: cat?.license || "siehe MODEL_CARD", file: path.join(dir, f),
          speakers: Object.keys(cfg.speaker_id_map || {}), speakerMap: cfg.speaker_id_map || {} });
      }
    }
  } catch (e) { console.error("[piper]", e.message); }
  list.sort((a, b) => (PIPER_PREFERENCE.indexOf(a.id) + 1 || 99) - (PIPER_PREFERENCE.indexOf(b.id) + 1 || 99));
  return (piperVoiceCache = list);
}
// Ein dauerhaft laufender Piper-Prozess je Stimme und Tempo: das Modell bleibt geladen, jeder Satz dauert
// nur Bruchteile einer Sekunde. Piper liest JSON-Zeilen und meldet pro Zeile den Pfad der fertigen WAV-Datei.
const piperWorkers = new Map();
let shuttingDown = false;
function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  for (const w of piperWorkers.values()) { w.retired = true; w.proc.kill(); }
  Promise.resolve(writing).finally(() => process.exit(0)); // laufendes Speichern noch abschließen
}
for (const sig of ["SIGINT", "SIGTERM"]) process.once(sig, shutdown);
// Läuft der Server unter scripts/supervisor.js (Auto-Update), kommt das Beenden als Nachricht.
// Verschwindet der Aufpasser (z. B. Aufgabe gestoppt), beendet sich der Server mit, damit der Port frei wird.
if (process.send) {
  process.on("message", (m) => { if (m?.t === "shutdown") shutdown(); });
  process.on("disconnect", shutdown);
}
let busySentAt = 0;
function reportBusy() { // dem Aufpasser melden, dass gerade gesprochen wird (kein Update mitten im Gespräch)
  if (!process.send || Date.now() - busySentAt < 30_000) return;
  busySentAt = Date.now();
  try { process.send({ t: "busy" }); } catch {}
}
// Eigene Warteschlange statt alles sofort an Piper zu schicken: so zählt das Zeitlimit erst ab dem Moment,
// in dem Piper den Satz wirklich bearbeitet (vorher liefen Ansagen hinter einer langen Begrüßung ins Zeitlimit,
// Piper wurde beendet und musste neu laden). Abgebrochene Anfragen (Kind tippt weiter) werden übersprungen,
// und Ansagen, die gerade gebraucht werden, kommen vor dem Vorladen dran.
function piperWorker(voice, speed) {
  const key = voice.id + "|" + speed;
  let w = piperWorkers.get(key);
  if (w && !w.dead) return w;
  for (const [k, old] of piperWorkers) if (k.startsWith(voice.id + "|") || piperWorkers.size > 2) { old.retired = true; old.proc.kill(); piperWorkers.delete(k); }
  const outDir = path.join(DATA_DIR, "tts-tmp");
  fs.mkdirSync(outDir, { recursive: true });
  const proc = spawn(PIPER_BIN, ["--model", voice.file, "--json-input", "--output_dir", outDir, "--length_scale", String(speed), "--sentence_silence", "0.25", "--quiet"],
    { cwd: path.dirname(PIPER_BIN), stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
  w = { proc, voice, speed, queue: [], current: null, done: 0, dead: false, buf: "", started: Date.now() };
  proc.stdout.on("data", (d) => {
    w.buf += d;
    let i;
    while ((i = w.buf.indexOf("\n")) >= 0) {
      const line = w.buf.slice(0, i).trim();
      w.buf = w.buf.slice(i + 1);
      if (!line || !w.current) continue;
      const job = w.current;
      w.current = null;
      w.done++;
      job.resolve(line);
      piperPump(w);
    }
  });
  proc.stderr.on("data", (d) => { const t = String(d).trim(); if (t && !/info/i.test(t)) console.error("[piper]", t.slice(0, 200)); });
  const fail = (err) => {
    if (w.dead) return;
    w.dead = true;
    if (piperWorkers.get(key) === w) piperWorkers.delete(key);
    w.current?.reject(err);
    w.current = null;
    // Wartende Sätze nicht verwerfen: einmal an einen frischen Prozess weitergeben
    const rest = w.queue.splice(0);
    for (const job of rest) {
      if (job.moved || w.retired || shuttingDown) { job.reject(err); continue; }
      job.moved = true;
      try { const nw = piperWorker(voice, speed); nw.queue.push(job); piperPump(nw); } catch (e) { job.reject(e); }
    }
    // Gleich einen frischen Prozess vorwärmen (Modell laden dauert ein paar Sekunden), damit die nächste
    // Ansage wieder mit der gewählten Stimme kommt und nicht in die Systemstimme ausweicht.
    // Nur wenn der Prozess eine Weile lief: ein sofort abstürzendes Piper soll keine Endlosschleife auslösen.
    if (!w.retired && !shuttingDown && Date.now() - w.started > 5000) setTimeout(() => { try { if (!piperWorkers.has(key) && piperVoices().some((v) => v.id === voice.id)) piperWorker(voice, speed); } catch {} }, 500).unref();
  };
  proc.on("error", (e) => fail(e));
  proc.on("exit", (code) => fail(new Error("Piper beendet (" + code + ")")));
  proc.stdin.on("error", (e) => fail(e));
  piperWorkers.set(key, w);
  return w;
}
// Nächsten Satz an Piper geben: dringende zuerst, abgebrochene überspringen
function piperPump(w) {
  if (w.dead || w.current) return;
  for (;;) {
    if (!w.queue.length) return;
    let i = w.queue.findIndex((j) => !j.low);
    if (i < 0) i = 0;
    const job = w.queue.splice(i, 1)[0];
    if (job.signal?.aborted) { job.reject(Object.assign(new Error("abgebrochen"), { name: "AbortError" })); continue; }
    w.current = job;
    // Zeitlimit ab jetzt, mit der Textlänge wachsend. Der erste Satz eines frischen Prozesses darf länger
    // dauern, weil Piper vorher das Modell lädt. Bei Ablauf wird der Prozess beendet und frisch gestartet.
    const ms = 10_000 + job.text.length * 80 + (w.done ? 0 : 20_000);
    const timer = setTimeout(() => {
      if (w.current !== job) return;
      console.error(`[tts] Piper antwortet nicht (${job.text.length} Zeichen, ${Math.round(ms / 1000)} s)`);
      w.proc.kill();
    }, ms);
    const { resolve, reject } = job;
    job.resolve = (v) => { clearTimeout(timer); resolve(v); };
    job.reject = (e) => { clearTimeout(timer); reject(e); };
    try { w.proc.stdin.write(JSON.stringify(job.line) + "\n"); } catch (e) { job.reject(e); w.current = null; continue; }
    return;
  }
}
// low: Vorladen, darf warten. signal: Anfrage des Geräts abgebrochen, dann nicht mehr erzeugen.
async function piperSynth(text, t, { low = false, signal = null } = {}) {
  const voices = piperVoices();
  const voice = voices.find((v) => v.id === t.piperVoice) || voices[0];
  if (!voice) throw new Error("Piper ist nicht installiert");
  const speed = Math.min(1.6, Math.max(0.7, Number(t.piperSpeed) || 1.1));
  const w = piperWorker(voice, speed);
  const outFile = path.join(DATA_DIR, "tts-tmp", crypto.randomBytes(8).toString("hex") + ".wav");
  const line = { text: text.replace(/[\r\n]+/g, " "), output_file: outFile };
  if (voice.speakers.length) line.speaker_id = voice.speakerMap[t.piperSpeaker] ?? voice.speakerMap.neutral ?? voice.speakerMap.amused ?? 0;
  const file = await new Promise((resolve, reject) => {
    w.queue.push({ text, line, low, signal, resolve, reject });
    piperPump(w);
  });
  const audio = await fsp.readFile(path.isAbsolute(file) ? file : outFile);
  fsp.rm(outFile, { force: true }).catch(() => {});
  return { audio, type: "audio/wav" };
}

function ttsSettingsRaw() { return { ...TTS_DEFAULT, ...(db.settings.tts || {}) }; }
function ttsSettings() {
  const t = ttsSettingsRaw();
  // Solange Eltern nichts gewählt haben: Piper, wenn installiert, sonst Systemstimme
  if (!db.settings.ttsChosen) t.provider = piperVoices().length ? "piper" : "browser";
  // Gewählter Dienst nicht (mehr) nutzbar (Schlüssel entfernt, OpenAI abgeschaltet): Piper, sonst Systemstimme
  if (!ttsConfigured(t.provider, t)) t.provider = piperVoices().length ? "piper" : "browser";
  return t;
}
// Stimme für ein Kind: pro Kind abweichend ("dienst:stimme"), sonst die für alle
function ttsFor(kid) {
  const t = ttsSettings();
  if (!kid?.voice) return t;
  const i = kid.voice.indexOf(":");
  const svc = i < 0 ? kid.voice : kid.voice.slice(0, i), v = i < 0 ? "" : kid.voice.slice(i + 1);
  const next = { ...t, provider: svc };
  if (v && ttsVoiceField[svc]) next[ttsVoiceField[svc]] = v;
  return ttsConfigured(svc, next) ? next : t;
}
const ttsClient = (t) => (t.provider === "browser" ? "browser" : "server");

// Feste Ansagen (Begrüßung, Modi, Limits, Schloss) von Cloud-Stimmen auf der Platte zwischenspeichern,
// verschlüsselt wie die Datenbank: so kostet jede Ansage nur einmal. Antworten werden nie gespeichert.
const TTS_DISK = path.join(DATA_DIR, "tts-cache");
const TTS_DISK_MAX = 400;
async function diskCacheGet(k) {
  try {
    const buf = decryptBuf(await fsp.readFile(path.join(TTS_DISK, k + ".bin")));
    const nl = buf.indexOf(10);
    return { audio: buf.subarray(nl + 1), type: buf.subarray(0, nl).toString() };
  } catch { return null; }
}
async function diskCachePut(k, out) {
  try {
    await fsp.mkdir(TTS_DISK, { recursive: true, mode: 0o700 });
    await fsp.writeFile(path.join(TTS_DISK, k + ".bin"), encryptBuf(Buffer.concat([Buffer.from(out.type + "\n"), out.audio])), { mode: 0o600 });
    const files = await fsp.readdir(TTS_DISK);
    if (files.length > TTS_DISK_MAX) {
      const st = await Promise.all(files.map(async (f) => ({ f, t: (await fsp.stat(path.join(TTS_DISK, f)).catch(() => ({ mtimeMs: 0 }))).mtimeMs })));
      for (const { f } of st.sort((a, b) => a.t - b.t).slice(0, files.length - TTS_DISK_MAX)) await fsp.rm(path.join(TTS_DISK, f), { force: true });
    }
  } catch (e) { console.error("[tts-cache]", e.message); }
}
const memCachePut = (k, out) => { ttsCache.set(k, out); if (ttsCache.size > 120) ttsCache.delete(ttsCache.keys().next().value); };
const ttsVoiceOf = (t) => (t.provider === "google" ? t.googleVoice : t.provider === "azure" ? t.azureVoice : t.provider === "elevenlabs" ? t.elevenVoice : "") || VOICES.TTS_SERVICES[t.provider]?.defaultVoice || "";

// Kosten einer Cloud-Stimme: zählen ins Monatsbudget des Kindes und ins Gesamtbudget (voller Listenpreis,
// Gratiskontingente werden nicht abgezogen). Zeichen pro Dienst und Monat für die Anzeige.
function chargeTts(t, chars, kid) {
  const usd = VOICES.costUsd(t.provider, ttsVoiceOf(t), t.elevenModel, chars);
  const gm = globalMonth();
  db.global[gm] += usd;
  db.ttsUsage ||= {};
  const mu = (db.ttsUsage[gm] ||= {});
  mu[t.provider] = (mu[t.provider] || 0) + chars;
  if (kid) { const { u, month } = kidUsage(kid.id); u.months[month] += usd; }
}
function ttsBudgetHit(kid) {
  const gm = globalMonth();
  if (db.settings.globalMonthlyUsd > 0 && db.global[gm] >= db.settings.globalMonthlyUsd) return true;
  if (kid) { const { u, month } = kidUsage(kid.id); if (kid.monthlyUsd > 0 && u.months[month] >= kid.monthlyUsd) return true; }
  return false;
}

// Ein Text als Audio. strict: Fehler melden statt auf Piper auszuweichen (Probehören, Speichern und testen).
// Fingerabdruck der Stimme: ändert sich, sobald Eltern Dienst, Stimme oder Tempo umstellen.
// Das Gerät hält feste Ansagen darunter vor und weiß so, wann sie neu geholt werden müssen.
const ttsVoiceFields = (t) => [t.provider, ttsVoiceOf(t), t.customVoice, t.model, t.url, t.azureRegion, t.elevenModel, t.cloudRate, t.piperVoice, t.piperSpeaker, t.piperSpeed];
const ttsVoiceSig = (t) => (t.provider === "browser" ? "browser" : sha256(ttsVoiceFields(t).join("|")).slice(0, 16));
const ttsCacheKey = (text, t) => sha256([...ttsVoiceFields(t), text].join("|")); // gleiches Format wie bisher: vorhandener Plattenspeicher bleibt gültig
// Schon fertig erzeugt (Speicher oder, bei festen Ansagen, Platte)? Dann kostet die Anfrage nichts.
async function ttsCached(text, t, fixed) {
  const k = ttsCacheKey(text, t);
  if (ttsCache.has(k)) return ttsCache.get(k);
  if (!fixed || t.provider === "browser") return null;
  const hit = await diskCacheGet(k);
  if (hit) memCachePut(k, hit);
  return hit;
}
async function synthesize(text, t = ttsSettings(), { key = ttsKeyFor(t.provider), kid = null, fixed = false, strict = false, low = false, signal = null } = {}) {
  const cacheKey = ttsCacheKey(text, t);
  const hit = await ttsCached(text, t, fixed);
  if (hit) return hit;
  if (t.provider === "piper") {
    const out = await piperSynth(text, t, { low, signal });
    if (text.length <= 300 || fixed) memCachePut(cacheKey, out);
    // Feste Ansagen auch von Piper auf der Platte: überstehen Neustarts (Auto-Update) und kommen sofort
    if (fixed) await diskCachePut(cacheKey, out);
    return out;
  }
  if (t.provider === "browser") throw new Error("Systemstimme läuft auf dem Gerät");
  const cloud = VOICES.CLOUD_IDS.includes(t.provider);
  const viaPiper = async (why) => {
    if (strict || !piperVoices().length) throw why instanceof Error ? why : new Error(why);
    return { ...(await piperSynth(text, t, { low, signal })), fallback: true };
  };
  if (cloud && !strict && ttsBudgetHit(kid)) return viaPiper("Budget erreicht");
  if (!strict && ttsDown[t.provider]?.until > Date.now()) return viaPiper(ttsDown[t.provider].error);
  let out;
  try {
    out = await VOICES.synth(t.provider, text, t, key);
  } catch (e) {
    console.error("[tts]", t.provider, e.message);
    if (!strict) ttsDown[t.provider] = { until: Date.now() + 120_000, at: new Date().toISOString(), error: e.message.slice(0, 200) };
    return viaPiper(e);
  }
  delete ttsDown[t.provider];
  if (cloud) chargeTts(t, text.length, kid);
  if (text.length <= 300 || fixed) memCachePut(cacheKey, out);
  if (fixed) await diskCachePut(cacheKey, out);
  return out;
}
async function tts(req, res) {
  const dev = deviceOf(req);
  if (!dev && !isParent(req)) return send(res, 401, { error: "Gerät nicht freigegeben" });
  const b = await readJson(req, 8 * 1024);
  const kid = b.kidId ? db.kids.find((k) => k.id === b.kidId) || null : null;
  const t = ttsFor(kid);
  if (t.provider === "browser") return send(res, 404, { error: "Keine Server-Stimme eingerichtet" });
  const text = String(b.text || "").replace(/\s+/g, " ").trim().slice(0, 1000);
  if (!text) return send(res, 400, { error: "Kein Text" });
  const fixed = b.fixed === true && text.length <= 400;
  const low = fixed && b.prefetch === true; // Vorladen fester Ansagen: hinten anstellen
  // Fertige Ansagen zählen nicht ins Anfrage-Limit, sie kosten nichts
  const hit = await ttsCached(text, t, fixed);
  if (!hit && !rateLimit((low ? "tts-pre:" : "tts:") + (dev?.id || "parent"), low ? 60 : 120, 60_000)) return send(res, 429, { error: "Zu viele Anfragen" });
  // Gerät bricht ab (Kind tippt weiter): Satz bei Piper nicht mehr erzeugen
  const ac = new AbortController();
  res.on("close", () => { if (!res.writableFinished) ac.abort(); });
  try {
    const out = hit || await synthesize(text, t, { kid, fixed, low, signal: ac.signal });
    if (ac.signal.aborted) return;
    res.writeHead(200, { ...SECURITY_HEADERS, "Content-Type": /^audio\//.test(out.type) ? out.type : "audio/mpeg", "Cache-Control": "no-store", "Content-Length": out.audio.length,
      ...(out.fallback ? { "X-LC-Voice": "piper-fallback" } : {}) });
    return res.end(out.audio);
  } catch (e) {
    if (e.name === "AbortError" || ac.signal.aborted) return;
    console.error("[tts]", e.message);
    return send(res, 502, { error: "Sprachausgabe nicht erreichbar" });
  }
}

// Stimmen-Übersicht für den Eltern-Bereich (Schlüssel selbst nie, nur die letzten vier Zeichen)
function ttsServicesView() {
  const raw = ttsSettingsRaw();
  const month = db.ttsUsage?.[globalMonth()] || {};
  const out = {};
  for (const svc of [...VOICES.CLOUD_IDS, "custom"]) {
    const s = VOICES.TTS_SERVICES[svc];
    const key = svc === "custom" ? db.secrets?.ttsCustomKey : ttsKeyFor(svc);
    out[svc] = {
      label: s.label, guide: s.guide || null, configured: ttsConfigured(svc, raw), keySource: svc === "custom" ? (key ? "db" : null) : ttsKeySource(svc),
      keyLast4: key ? key.slice(-4) : "", voices: db.settings.ttsVoiceLists?.[svc] || (s.fallbackVoices || []).map((id) => ({ id, label: svc === "google" ? `${VOICES.tierLabel("google", id)} · ${id.replace(/^de-DE-(Chirp3-HD-)?/, "")}` : id.replace(/^de-DE-/, "") })),
      defaultVoice: s.defaultVoice || "", models: s.models ? Object.entries(s.models).map(([id, m]) => ({ id, label: m.label })) : null,
      tiers: s.tiers.map(({ label, usdPerM, freeM }) => ({ label, usdPerM, freeM })), expensive: !!s.expensive,
      down: ttsDown[svc]?.until > Date.now() ? { at: ttsDown[svc].at, error: ttsDown[svc].error } : null,
      monthChars: month[svc] || 0,
    };
  }
  return out;
}

// Startet Piper wirklich? Sonst nicht als Standard anbieten (z. B. fehlende VC++-Laufzeit unter Windows).
async function checkPiper() {
  if (!piperVoices().length) return;
  try {
    await piperSynth("Test.", { ...TTS_DEFAULT, piperVoice: piperVoices()[0].id });
    console.log(`  Piper-Stimmen bereit: ${piperVoices().map((v) => v.id).join(", ")}`);
  } catch (e) {
    console.error("  Piper startet nicht (" + e.message + "). Es wird die Stimme des Tablets genutzt." +
      (process.platform === "win32" ? " Unter Windows fehlt oft die Visual-C++-Laufzeit: winget install Microsoft.VCRedist.2015+.x64" : ""));
    piperVoiceCache = [];
    for (const w of piperWorkers.values()) { w.retired = true; w.proc.kill(); }
    piperWorkers.clear();
  }
}

// ---------------------------------------------------------------- Start
await loadDb();
if (db.secrets?.ttsKey) { delete db.secrets.ttsKey; console.log("  OpenAI-Stimme gibt es nicht mehr: alter Stimmen-Schlüssel gelöscht, es spricht Piper."); await saveDb(); }
if (db.settings.tts?.provider === "openai") db.settings.tts.provider = piperVoices().length ? "piper" : "browser";
personaDefault = await fsp.readFile(PERSONA_FILE, "utf8");
// Gespeicherte Fassung, die wörtlich dem (jetzigen oder einem früheren) Standard entspricht, ist keine Anpassung: auf Standard stellen (gleicher Inhalt),
// damit künftige Verbesserungen ankommen. Echte Anpassungen werden nie verändert.
if (db.settings.persona && samePersona(db.settings.persona, personaDefault)) { db.settings.persona = null; await saveDb(); }
safetyDefault = await fsp.readFile(KID_SAFETY_FILE, "utf8");
await loadModes();
// Gleiches Prinzip für Kinderschutz-Regeln und Modi: wörtlich gleich dem Standard = Standard; eigene Texte zu
// Modi, die es nicht mehr gibt, bleiben liegen (falls der Modus zurückkommt), werden aber nicht benutzt.
{
  let changed = false;
  if (db.settings.safety && !TX.normalize(db.settings.safety, safetyDefault)) { db.settings.safety = null; changed = true; }
  for (const [id, t] of Object.entries(db.settings.modeTexts || {})) {
    const mode = modeById(id);
    if (mode && !TX.normalize(t, mode.body)) { delete db.settings.modeTexts[id]; changed = true; }
  }
  if (changed) await saveDb();
}
// Einmalig: Die Figur (Avatare) hat jetzt einen eigenen Knopf statt Kreativ. Wer Kreativ einzeln freigeschaltet
// hatte, bekommt den neuen Knopf dazu, damit vorhandene Figuren erreichbar bleiben.
if (!db.settings.figurModeAdded) {
  for (const k of db.kids) if (Array.isArray(k.modes) && k.modes.includes("kreativ") && !k.modes.includes("figur")) k.modes.push("figur");
  db.settings.figurModeAdded = true;
  await saveDb();
}
if (ENV_API_KEY) useKey(ENV_API_KEY, "env");
else if (db.secrets?.apiKey) useKey(db.secrets.apiKey, "db");
if (!db.parent) {
  setupCode = crypto.randomBytes(4).toString("hex").toUpperCase();
  await fsp.writeFile(SETUP_CODE_FILE, `Einrichtungscode für ${APP_NAME}: ${setupCode}\nDiese Datei verschwindet nach der Einrichtung.\n`, { mode: 0o600 });
  console.log(`\n  Einrichtungscode für den Eltern-Bereich: ${setupCode}\n  (steht auch in ${SETUP_CODE_FILE})\n`);
}
if (!anyProvider()) console.warn("  Hinweis: Noch kein API-Schlüssel. Der Einrichtungs-Assistent im Browser fragt danach.");
backupNow().catch((e) => console.error("[backup]", e.message));
await checkPiper();
setInterval(() => backupNow().catch((e) => console.error("[backup]", e.message)), 6 * 3600_000).unref();

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://x");
    if (url.pathname.startsWith("/api/")) {
      const tz = String(req.headers["x-lc-tz"] || "").slice(0, 64);
      return await requestCtx.run({ tz: /^[A-Za-z_]+(\/[A-Za-z0-9_+-]+)*$/.test(tz) && validTz(tz) ? tz : null }, () => handleApi(req, res, url));
    }
    if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, "Methode nicht erlaubt");
    if (url.pathname.startsWith("/anleitung/")) return await serveGuide(res, url.pathname.slice(11));
    return await serveStatic(req, res, url.pathname);
  } catch (e) {
    if (!res.headersSent) send(res, e.status || 500, { error: e.status ? e.message : "Serverfehler" });
    else res.end();
    if (!e.status) console.error(e);
  }
}).listen(PORT, HOST, () => {
  console.log(`  ${APP_NAME} läuft auf http://${HOST}:${PORT} · Serverzeit ${localParts().date} ${localParts().time} (${ENV_TZ})`);
  try { process.send?.({ t: "ready" }); } catch {}
});
