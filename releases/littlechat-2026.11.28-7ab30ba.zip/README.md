# LittleChat

**Ein Walkie-Talkie für Kinder, mit dem sie per Stimme Fragen an eine KI stellen: standardmäßig Claude, wahlweise ChatGPT, Gemini, Mistral, Grok oder ein lokales Modell über Ollama.** Großen Knopf gedrückt halten, Frage stellen, loslassen, Antwort hören. Kinder brauchen dafür nicht lesen zu können. Eltern behalten die Kontrolle: Sie bestimmen Limits, legen fest, welche Geräte mitmachen, und können die Gespräche nachlesen.

> **Privates, inoffizielles Projekt. Nicht mit Anthropic, OpenAI, Google, Mistral AI, xAI oder Ollama verbunden und von keinem dieser Anbieter unterstützt oder geprüft.** „Claude“ ist eine Marke von Anthropic, „ChatGPT“ von OpenAI, „Gemini“ von Google, „Grok“ von xAI. LittleChat nutzt die öffentlichen APIs der Anbieter mit deinem eigenen API-Schlüssel.

| Walkie-Talkie | Eltern-Bereich |
|---|---|
| ![Walkie-Talkie](docs/screenshot-walkie-talkie.png) | ![Eltern-Bereich](docs/screenshot-eltern.png) |

## Was LittleChat kann

- **Sprechtaste wie beim Walkie-Talkie.** Die Antwort kommt gestreamt und wird Satz für Satz vorgelesen.
- **Kindgerechte Persönlichkeit** aus [`kid_persona.md`](kid_persona.md): freundlich, sachlich korrekt, witzig, lädt zum Entdecken ein. Ton, Wortschatz, Länge und Beispiele kommen aus vier **Altersstufen** in [`ages/`](ages/) (bis 5, 6 bis 9, 10 bis 13, ab 14 Jahren), gewählt nach dem Geburtsdatum oder fest von den Eltern pro Kind. Was ein Kind im Gespräch über sein Alter sagt, ändert die Stufe nie. Eltern können den Text anpassen, ihre Fassung bleibt bei Updates erhalten. Die **Kinderschutz-Regeln** stehen getrennt in [`kid_safety.md`](kid_safety.md) und gelten immer, egal wie die Persönlichkeit umgeschrieben wird. Persönlichkeit, Kinderschutz-Regeln, Altersstufen und jeder Gesprächsmodus sind im Eltern-Bereich bearbeitbar, mit Warnung, was eine Änderung bewirkt, und „Auf Standard zurücksetzen“.
- **Fünf Gesprächsmodi** zum Antippen: 🎓 Lernen, 🧭 Erkunden, 🔍 Erforschen, 🖌️ Kreativ (der Pinsel), 🎲 Langeweile. LittleChat sagt beim Antippen an, was der Modus macht, Lesen ist nicht nötig. Jeder Modus ist eine Markdown-Datei in [`modes/`](modes/), die an die Persona angehängt wird; die Kinderschutz-Regeln gelten immer. Eltern schalten Modi pro Kind frei (Standard: alle).
- **Startansage** mit dem Namen des Kindes. Sie erklärt die Bedienung und sagt offen, dass hier eine KI spricht.
- **Alles per Stimme bis 8 Jahre.** Bis einschließlich 8 Jahre nennt jede Begrüßung alle Knöpfe, und jeder Schritt (Zurück, Farbe wählen, Schloss) wird angesagt. Ab 9 Jahren gibt es die ausführliche Erklärung einmal am Tag, sonst kurz; das Fragezeichen erklärt jederzeit alles.
- **Eigene Farbe.** Jedes Kind wählt seine Farbe selbst über die Farbpalette 🎨 oben im Sprechbildschirm (20 gängige Farben von Rot über Orange und Gold bis Schwarz und Weiß, per Stimme erklärt; bei hellen Farben wird die Schrift automatisch dunkel). Sprechknopf und Statusleiste nehmen diese Farbe an. Mit Farbschloss geht das nur im geöffneten Profil.
- **Untertitel.** Der gerade vorgelesene Satz steht über dem großen Knopf, Satz für Satz. Pro Kind abschaltbar (Kinder › Bearbeiten, Standard: an).
- **Name des Assistenten** ist frei wählbar (Eltern-Bereich › Persönlichkeit, Standard „LittleChat“). So meldet er sich in Begrüßung, Ansagen und Antworten, für alle Kinder gleich.
- **Seifenblasen als Erinnerungen.** Jedes Gespräch wird zu einer Blase mit Emoji, die langsam über den Bildschirm fliegt. Je länger das Gespräch war, desto größer die Blase (bis 1,8-fach). Tippt das Kind darauf, geht das Gespräch weiter, lang drücken lässt sie zerplatzen. Die Blasen schweben auch, wenn am Gerät „Bewegung reduzieren“ an ist (unter Windows: Animationseffekte aus), dann halb so schnell.
- **Avatare mit eigenem Knopf „Avatar“ 🐥.** Ein Avatar ist die eigene Fantasiefigur des Kindes. Der Avatar-Modus baut nur Avatare: Will das Kind etwas anderes (Wissensfrage, Geschichte, Spiel), nennt die KI den passenden freigeschalteten Knopf, statt es selbst zu beantworten. Solange kein Avatar existiert, schlägt die KI ihn im Langeweile-Modus vor und erklärt den Knopf. Das Kind beschreibt den Avatar frei („grünes Monster mit fünf Augen und drei Haaren“), die KI fragt nur nach dem Aussehen und macht keine eigenen Vorschläge. Ab der dritten Antwort fasst sie zusammen und fragt, ob sie ihn malen soll, ab der sechsten schlägt sie das bestimmt vor. Erst nach einem Ja zeichnet sie das Bild als SVG. Solange gemalt wird, zählt die Stimme mit dem Kind („Komm, wir zählen zusammen …“). Dann platzt die Blase des Gesprächs (ab jetzt ist der Avatar die Blase), und die Stimme sagt: „Wow, schau mal, wie schön Blubbi ist! Soll ich dir eine Geschichte zu Blubbi erzählen?“ Der Server baut daraus ein sicheres Bild: nur Formen und Farben, kein Text, kein Script, keine Links. Jedes Kind kann höchstens 3 Avatare haben, der erste wird gleich Profilbild. Gibt es schon einen Avatar, fragt der Avatar-Knopf: „Möchtest du eine Geschichte zu Blubbi hören oder einen neuen Avatar bauen?“ Eine Geschichte wird eine eigene Seifenblase mit 👄 (nicht 🐥), dort erzählt die KI weitere kurze Geschichten zu diesem Avatar. Per Sprache geht außerdem erfinden, umgestalten (die KI fasst den Avatar zusammen, bespricht die Änderungen und zeichnet ihn am selben Platz neu; Abbruch = er bleibt, ohne Geschichte) und Profilbild wählen. Löschen geht bewusst nicht per Sprache. Antippen einer Avatar-Blase zeigt drei Knöpfe, die per Stimme erklärt werden: Aktivieren (Profilbild), Löschen (rotes X, mit Rückfrage wie beim Festhalten) und Zurück. Lang drücken und rotes X löscht ebenfalls. Im Eltern-Bereich bleibt er sichtbar: Eltern holen ihn zurück (dann kann das Kind auch mehr als 3 haben; neu erfinden geht erst wieder unter 3) oder löschen ihn endgültig. Avatare erscheinen im Emoji-Stil wie die anderen Seifenblasen-Bilder. Ein- und ausschalten lässt sich das pro Kind wie jeder Modus (ab Werk an) oder über `avatare: ja` im Kopf der Modus-Datei.
- **Eltern-Bereich** mit Passwort. **Öffnen: Zahnrad ⚙ oben rechts auf dem Startbildschirm 2 Sekunden gedrückt halten**, dann Passwort eingeben (kurzes Antippen erklärt dem Kind nur, dass das Zahnrad für die Eltern ist):
  - Kinder anlegen (Vorname und Geburtsdatum sind Pflicht)
  - KI-Anbieter und Modell wählen: global für alle Kinder und abweichend pro Kind (siehe [KI-Anbieter](#ki-anbieter))
  - Zeitlimits pro Kind: Uhrzeiten, Minuten pro Tag, Fragen pro Tag
  - Gesprächs-Abschriften und Avatare ansehen und löschen
  - Stimme, Persönlichkeit und Name des Assistenten
  - Geräte freigeben und sperren
- **„Mama oder Papa haben geschaut“:** Das Kind erfährt es erst, wenn es ein angesehenes Gespräch fortsetzt. Der Hinweis ist pro Kind abschaltbar.
- **Sicher:**
  - Die API-Schlüssel bleiben auf deinem Server, für jeden Anbieter getrennt.
  - Datenbank und Backups sind verschlüsselt.
  - Tablets bekommen nur ein eng begrenztes Geräte-Token.
- **Läuft bei dir zu Hause** auf einem Windows-PC, einem Raspberry Pi, einem NAS mit Docker oder einem kleinen Server.

## Verantwortung der Eltern, Nutzung auf eigene Gefahr

LittleChat ist ein Werkzeug für Eltern, kein Babysitter. **Ihr als Eltern tragt die Verantwortung dafür, wie eure Kinder LittleChat nutzen, und haftet für sie im Rahmen eurer Aufsichtspflicht.** Behaltet die Themen und Gespräche im Blick: Im Eltern-Bereich unter „Gespräche“ könnt ihr jedes Gespräch nachlesen, auffällige sind mit ⚠ markiert. Keine KI ist fehlerfrei, auch Claude nicht. Antworten können falsch, unpassend oder nicht kindgerecht sein. Alle Anbieter außer Claude sind mit der Persona von LittleChat **ungetestet**. **Die Nutzung erfolgt auf eigene Gefahr**, ohne Gewähr und ohne Haftung des Entwicklers im gesetzlich zulässigen Umfang.

## Was du brauchst

1. **Einen Rechner, der läuft, wenn die Kinder fragen.** Windows 10/11, Linux (z. B. Raspberry Pi 4/5) oder Docker.
2. **Einen API-Schlüssel**, am besten von Anthropic (Claude). Ein Abo (Claude Pro/Max, ChatGPT Plus, Gemini Advanced …) lässt sich nicht mit fremden Apps verbinden, das ist technisch nicht vorgesehen. Der Einrichtungs-Assistent erklärt Schritt für Schritt, wie du einen Claude-Schlüssel mit Ausgabenlimit anlegst. Andere Anbieter richtest du danach im Eltern-Bereich ein, oder ganz ohne Schlüssel lokal mit Ollama.
3. **Tablets oder Handys** mit Chrome (Android) oder Safari (iPad/iPhone).

Grobe Kosten pro Monat bei 40 Fragen am Tag (Schätzung bei ca. 2.500 Tokens hinein und 300 heraus pro Frage, Stand November 2026, Preise aus [`providers.json`](providers.json)):

| Modell | pro Frage | pro Monat |
|---|---|---|
| Claude Haiku 5.5 (Standard): am schnellsten, gut für Kinderfragen | unter 0,05 Cent | unter 1 $ |
| Claude Sonnet 5.5: sehr gut, flott | 0,5 bis 1 Cent | 6 bis 12 $ |
| Claude Opus 5.5: beste Antworten | 1 bis 2 Cent | 12 bis 24 $ |
| GPT-6 Luna (OpenAI) | unter 0,05 Cent | unter 1 $ |
| Mistral Small | ca. 0,06 Cent | unter 1 $ |
| Gemini 3.1 Flash-Lite (Google) | ca. 0,1 Cent | ca. 1,30 $ |
| Grok 4.20 ohne Nachdenken (xAI) | ca. 0,4 Cent | ca. 5 $ |
| Ollama lokal | kostenlos | Strom |

## KI-Anbieter

Claude ist der Standard. Persona, Gesprächsmodi und Kinderschutz-Regeln wurden mit Claude entwickelt. Weitere Anbieter richtest du im Eltern-Bereich unter **KI-Anbieter** ein. Dort wählst du auch den **Standard für alle Kinder**. Pro Kind kannst du abweichen (Kinder › Bearbeiten). Jede Anleitung zeigt: Schlüssel anlegen, Ausgabenlimit setzen, im Eltern-Bereich eintragen. Sie ist im Eltern-Bereich verlinkt.

**Empfehlung (Stand November 2026):** als KI **Claude mit dem Modell Haiku** (Standard, schnell, günstig, für Kinder abgestimmt), als Stimme **Google Cloud Text-to-Speech** mit den Chirp-3-HD-Stimmen (sehr natürlich, 1 Mio. Zeichen im Monat gratis). Piper bleibt die kostenlose Alternative, bei der nichts das Haus verlässt.

| Anbieter | Stärken | Beachten | Anleitung |
|---|---|---|---|
| **Claude (Anthropic)** | für Kinder am besten abgestimmt, Standard | – | [anthropic.md](docs/anbieter/anthropic.md) |
| **ChatGPT (OpenAI)** | ähnlich gut, ähnlicher Preis | Daten in den USA | [openai.md](docs/anbieter/openai.md) |
| **Gemini (Google)** | gut, Googles Schutzfilter auf strengster Stufe | nur mit bezahltem Tarif nutzen (im Gratis-Tarif darf Google Eingaben auswerten); Google-Budgets warnen nur | [gemini.md](docs/anbieter/gemini.md) |
| **Mistral (Europa)** | Daten bleiben in der EU, günstig | weniger auf Kinder abgestimmt | [mistral.md](docs/anbieter/mistral.md) |
| **Grok (xAI)** | schnell, großes Wissen | Daten in den USA | [grok.md](docs/anbieter/grok.md) |
| **Ollama (lokal)** | kostenlos, nichts verlässt das Haus | auf einem NUC langsam (10 bis 60 Sekunden pro Antwort) und deutlich schwächer | [ollama.md](docs/anbieter/ollama.md) |

**Ungetestet.** Alle Anbieter außer Claude sind mit der Persona von LittleChat **nicht getestet**. Sie sind ohne Pflichttest wählbar, sobald ihr Schlüssel eingetragen ist und du das Häkchen „Ich habe verstanden, ungetestet“ gesetzt hast. Im Eltern-Bereich sind sie als „ungetestet“ gekennzeichnet. Ollama zeigt bei der Auswahl zusätzlich einen Hinweis zu Tempo und Qualität, der vor dem Speichern bestätigt wird.

**Optionaler Kinderfragen-Test.** Mit dem Knopf „Jetzt testen“ lässt du im Eltern-Bereich elf heikle Kinderfragen mit der echten Persona stellen (Feuer, Putzmittel, giftige Pilze, „ich will nicht mehr leben“, Geheimnisse mit Erwachsenen, Adresse verraten, „bist du ein Mensch?“, Schimpfwörter, Horror, Werbung, eine Wissensfrage) und liest die Antworten. Eine Stichwort-Prüfung markiert Auffälliges. Der Test ist keine Voraussetzung. Von der Kommandozeile geht er mit `node scripts/kinderfragen-test.mjs` (Schlüssel als Umgebungsvariable, Anleitung im Skript).

**Was überall gleich bleibt:** Persona und Gesprächsmodi gehen bei jedem Anbieter als derselbe Systemprompt mit. Alle Zeitlimits (Uhrzeiten, Minuten, Fragen pro Kind) gelten anbieterübergreifend. Lehnt ein Anbieter eine Antwort aus Sicherheitsgründen ab, hört das Kind „Darüber kann ich leider nicht sprechen“ und du siehst das Gespräch mit ⚠ markiert. Seifenblasen-Titel und Zusammenfassungen erstellt das günstigste Modell **desselben** Anbieters, damit keine Gesprächsinhalte zu einem zweiten Anbieter wandern.

**Preise pflegen:** Modelle und Preise stehen in [`providers.json`](providers.json). Eigene Anpassungen gehören nach `data/providers.json` (gleiches Format, Updates überschreiben sie nie). Findet der Schlüssel weitere Modelle, sind sie wählbar und werden mit einem hohen Schätzpreis gerechnet, bis sie in der Tabelle stehen. Ändert ein Anbieter seine Modellnamen, kommt die neue Tabelle mit dem nächsten Update.

## Installation

**Für Eltern ohne Technik-Kenntnisse:** Die Schritt-für-Schritt-Anleitung steht in [INSTALLATION.md](INSTALLATION.md).

### Windows (empfohlen für Einsteiger)

1. [Neueste Version als ZIP herunterladen](https://github.com/TimoHuebner0815/LittleChat/raw/main/releases/littlechat-latest.zip) und entpacken, z. B. nach `C:\LittleChat`.
2. Im Ordner doppelt auf **`LittleChat-installieren.cmd`** klicken. Die Datei startet nur das PowerShell-Skript `scripts\install-windows.ps1` mit Administratorrechten. Liegt der Ordner in Downloads, auf dem Desktop oder in OneDrive, kopiert der Installer LittleChat nach `C:\LittleChat`. Alternativ in einer Administrator-PowerShell:
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\install-windows.ps1
   ```
3. Das Skript erledigt:
   - Node.js, Visual-C++-Laufzeit und Piper installieren, falls sie fehlen (winget, sonst direkt vom Hersteller)
   - Autostart einrichten (der Server läuft auch nach einem Neustart) und automatische, signierte Updates
   - Datenordner schützen
   - auf Wunsch Tailscale für HTTPS einrichten, auch ohne Anmeldung am Rechner („unattended“)
   - auf Wunsch den Energiesparmodus am Netzteil abschalten
   - den Browser mit dem **Einrichtungscode** öffnen
4. Im Browser den Assistenten durchgehen: Passwort festlegen, Claude-Schlüssel eintragen (oder überspringen und später einen anderen Anbieter einrichten), Wiederherstellungsschlüssel sichern.

Entfernen: `LittleChat-entfernen.cmd`. Daten bleiben, außer du tippst zur Bestätigung `LÖSCHEN`. Zurück auf die vorige Version: `LittleChat-zurueck.cmd`.

### Linux / Raspberry Pi

```bash
curl -fsSLO https://github.com/TimoHuebner0815/LittleChat/raw/main/releases/littlechat-latest.zip
mkdir -p ~/littlechat && cd ~/littlechat && unzip -o ../littlechat-latest.zip
sudo bash scripts/install-linux.sh
```
Das Skript lädt Node.js LTS von nodejs.org nach `/opt/littlechat-node` (falls kein Node 20+ da ist, Prüfsumme geprüft), richtet einen `systemd`-Dienst mit Autostart, automatischen Updates und Schutzmaßnahmen ein, bietet Tailscale an und zeigt den Einrichtungscode. Entfernen: `sudo bash scripts/uninstall-linux.sh`. Zurück auf die vorige Version: Datei `rollback-now` im Programmordner anlegen.

### Docker

Docker-Installationen aktualisieren sich nicht selbst. Für automatische Updates Windows oder Linux nutzen.

```bash
mkdir littlechat && cd littlechat && unzip ../littlechat-latest.zip   # ZIP wie oben
cp .env.example .env
docker compose up -d --build
docker compose exec littlechat cat /data/EINRICHTUNGSCODE.txt
```

## HTTPS im Heimnetz (nötig für das Mikrofon)

Browser erlauben das Mikrofon nur über HTTPS. Am einfachsten geht das mit **[Tailscale](https://tailscale.com)**. Für Privatleute ist es kostenlos, es öffnet nichts ins Internet, und es liefert ein gültiges Zertifikat.

**Was ist Tailscale, kurz erklärt?** Stell es dir wie einen privaten, verschlüsselten Tunnel zwischen deinen eigenen Geräten vor. Jedes Gerät, auf dem die Tailscale-App läuft und das mit deinem Konto angemeldet ist, gehört zu deinem privaten Netz (dem „Tailnet“). Nur diese Geräte erreichen den Server. Der Server bekommt dort eine feste Adresse wie `https://nuc.tailXXXX.ts.net`, die von überall funktioniert, auch unterwegs, aber eben nur für deine Geräte.

> **Häufigster Stolperstein:** Die App läuft am Server, aber auf dem Tablet „lädt nichts“. Dann fehlt auf dem Tablet die Tailscale-App, sie ist ausgeschaltet oder mit einem anderen Konto angemeldet. Der Eltern-Bereich zeigt unter „Geräte“ die richtige Adresse und warnt, wenn am Server etwas fehlt.

1. Tailscale auf dem Server installieren und anmelden. Der Windows-Installer erledigt das auf Wunsch.
2. Auf dem Server: `tailscale serve --bg 8787`. Falls Tailscale nachfragt, im Admin-Bereich „HTTPS Certificates“ einschalten.
3. Tailscale-App auf **jedem** Tablet und Handy installieren (App Store/Google Play), mit demselben Konto anmelden und einschalten.
4. Auf den Tablets die Adresse `https://<servername>.<tailnet>.ts.net` öffnen.

Wer eine eigene Domain hat, kann stattdessen einen Reverse-Proxy wie Caddy nutzen, siehe [`docs/Caddyfile.example`](docs/Caddyfile.example).

## Als App auf dem Tablet

LittleChat ist eine Web-App (PWA). Auf dem Tablet sieht sie aus wie eine normale App: mit eigenem Symbol, im Vollbild und ohne Adressleiste. Einen App-Store braucht es nicht.

1. Auf dem Tablet Tailscale einschalten und die Adresse aus dem Eltern-Bereich öffnen.
2. Die App auf den Home-Bildschirm legen:
   - **iPad/iPhone:** in Safari auf Teilen tippen, dann „Zum Home-Bildschirm“.
   - **Android:** in Chrome auf ⋮ tippen, dann „App installieren“. Oft erscheint auch direkt ein Knopf „Als App installieren“.
3. Die App über das neue Symbol öffnen. Läuft LittleChat noch im Browser, erinnert ein Hinweis unten auf dem Startbildschirm daran.
4. Im Eltern-Bereich (auf deinem Handy oder am Rechner) unter „Geräte“ auf **„Kopplungscode erzeugen“** tippen und den 6-stelligen Code auf dem Tablet eingeben. Der Code gilt 10 Minuten und nur einmal. Auf dem Tablet ist kein Eltern-Login nötig.

Wichtig für iPad: Zuerst zum Home-Bildschirm hinzufügen, dann in der App koppeln. Die App auf dem Home-Bildschirm hat einen eigenen Speicher, getrennt von Safari.

## Stimme

Im Eltern-Bereich unter „Stimme“ wählst du, wer vorliest: als Standard für alle Kinder und bei „Kinder“ › Bearbeiten pro Kind abweichend. Jede Stimme lässt sich vorher mit **▶ Probe** anhören.

| Stimme | Klang | Kosten (Stand 26.11.2026) | Datenschutz |
|---|---|---|---|
| **Piper** (Standard, wenn installiert) | natürlich, auf jedem Gerät gleich | kostenlos | läuft auf deinem Server, nichts verlässt das Haus |
| **Google Cloud** ([Anleitung](docs/stimmen/google.md)) | Chirp 3 HD sehr natürlich; Neural2, WaveNet, Standard wählbar | Chirp 3 HD: 1 Mio. Zeichen/Monat gratis, danach 30 $ (26,94 €) pro Mio.; Standard/WaveNet 4 $ pro Mio. | der **Text** geht an Google |
| **Microsoft Azure** ([Anleitung](docs/stimmen/azure.md)) | sehr natürlich, mit Kinderstimme Gisela | Stufe F0: 0,5 Mio. Zeichen/Monat gratis; S0 ca. 15 $ pro Mio. | der **Text** geht an Microsoft (gewählte Region) |
| **ElevenLabs** ([Anleitung](docs/stimmen/elevenlabs.md)) | sehr ausdrucksstark | **teuerster Dienst**: ca. 40 $ (Flash) bis 80 $ (Multilingual) pro Mio. Zeichen | der **Text** geht an ElevenLabs (USA) |
| **Stimme des jeweiligen Geräts** | **unterscheidet sich pro Gerät** in Klang und Verfügbarkeit, von okay bis sehr gut | kostenlos | bleibt meist auf dem Gerät |
| **Eigener Sprach-Server** (OpenAI-kompatibel, z. B. Piper) | gut, etwas technischer | kostenlos | nichts verlässt das Haus |

Eine Minute Vorlesen sind etwa 900 Zeichen. Bei Cloud-Stimmen gilt:
- Schlüssel liegen nur auf dem Server (verschlüsselt, oder in `.env`: `LC_GOOGLE_TTS_KEY`, `LC_AZURE_TTS_KEY`, `LC_ELEVENLABS_API_KEY`), nie auf einem Tablet.
- Fällt ein Stimmendienst aus, spricht Piper weiter, statt dass es still wird.
- Fällt der Dienst aus (Netz, Schlüssel, Kontingent), spricht automatisch **Piper**; zwei Minuten lang wird der Dienst dann nicht erneut gefragt. Der Grund steht im Eltern-Bereich.
- Feste Ansagen (Begrüßung, Modi, Limits, Schloss, Proben) werden verschlüsselt in `data/tts-cache/` gespeichert und kosten nur einmal, auch mit Piper (überstehen so Neustarts durch Updates). Antworten werden nicht gespeichert.
- Das Tablet hält feste Ansagen zusätzlich im Speicher und lädt die Erklärungen der Knöpfe beim Öffnen des Sprechbildschirms vor. Antippen unterbricht sofort, was gerade gesprochen wird. Braucht der Server länger als 4 Sekunden, spricht die Gerätestimme diese eine Ansage.
- Eine **OpenAI-Stimme gibt es nicht** (mehr): OpenAI schaltet seine Sprachmodelle am 6.1.2027 ab, ohne Nachfolger für diese Schnittstelle. Wer sie gewählt hatte, hört ab dem Update Piper; der alte Stimmen-Schlüssel wird gelöscht.

**Systemstimme besser machen:** LittleChat nimmt automatisch die beste installierte deutsche Stimme. Oft sind die guten Stimmen aber nicht vorinstalliert:
- **iPad/iPhone:** Einstellungen › Bedienungshilfen › Gesprochene Inhalte › Stimmen › Deutsch, dann z. B. „Anna (Premium)“ oder eine „(Erweitert)“-Stimme laden.
- **Android:** Einstellungen › Sprachausgabe › Google-Sprachausgabe › Sprachdaten installieren › Deutsch, dann die Stimme in hoher Qualität laden.

**Eigene Stimme mit Piper:** [Piper](https://github.com/rhasspy/piper) erzeugt die Stimme direkt auf deinem Server, unter Windows, Linux, macOS und im Docker-Image. Die Installer richten Piper automatisch ein. Von Hand geht es so:

```
node scripts/setup-piper.mjs                     # Thorsten (männlich, beste Qualität) und Kerstin (weiblich)
node scripts/setup-piper.mjs --voices=all        # alle frei lizenzierten Stimmen
```

Danach den Dienst neu starten. Im Eltern-Bereich wählst du unter „Stimme“ eine Stimme, hörst sie probe und stellst das Tempo ein. Fehlt Piper, nimmt LittleChat automatisch die Stimme des Tablets.

Mitgeliefert werden nur Stimmen mit freier Lizenz laut ihrer MODEL_CARD: Thorsten, Kerstin und Thorsten emotional (CC0) sowie optional MLS (CC BY 4.0, Namensnennung: Multilingual LibriSpeech, openslr.org/94). Nicht enthalten sind „pavoque“ (nicht kommerziell) sowie „eva_k“, „ramona“ und „karlsson“, weil deren Lizenz in der Karte nicht angegeben ist. Piper selbst steht unter MIT, sein Sprachbaustein espeak-ng unter GPL-3.0. Beides lädt das Skript direkt vom Original herunter und prüft es per SHA-256. Es liegt nicht im Repository.

**Anderer Sprach-Server:** Jeder OpenAI-kompatible Endpunkt `/v1/audio/speech` funktioniert über „Eigener Sprach-Server“.

Ein Schlüssel für den eigenen Sprach-Server wird nur an diesen Server geschickt, verschlüsselt gespeichert und nie an Geräte ausgeliefert.

## Erste Schritte nach der Installation

1. Einrichtungscode eingeben und Eltern-Passwort festlegen (mindestens 10 Zeichen).
2. **Assistent, Schritt 1:** Claude-Schlüssel anlegen und einfügen. Der Server prüft ihn und speichert ihn verschlüsselt. Wer einen anderen Anbieter nutzen will, überspringt den Schritt und richtet ihn danach im Eltern-Bereich unter „KI-Anbieter“ ein.
3. **Assistent, Schritt 2:** Wiederherstellungsschlüssel speichern. Damit lassen sich Backups auf einem neuen Rechner wiederherstellen.
4. **Eltern-Bereich:** Kinder mit Vorname und Geburtsdatum anlegen und die Zeitlimits prüfen. Die Farbe kann jedes Kind später selbst wählen.
5. **Auf jedem Kinder-Tablet:**
   - Adresse öffnen.
   - Zahnrad oben rechts **2 Sekunden halten** und anmelden.
   - **„Dieses Gerät freigeben“** tippen, dann „Fertig“.
   - „Zum Home-Bildschirm hinzufügen“ wählen.

## Sicherheitsmodell

**Ziel:** Kein API-Schlüssel kann von einem Kinder-Gerät oder aus dem Browser gestohlen werden. Kosten und Inhalte bleiben unter Kontrolle.

1. **Schlüssel nur auf dem Server.** Das gilt für jeden Anbieter, jeder Schlüssel wird getrennt gespeichert und nur an seinen eigenen Anbieter geschickt.
   - Er wird beim Eintragen geprüft und landet verschlüsselt in der Datenbank. Alternativ kann er in `.env` stehen (`ANTHROPIC_API_KEY`, `LC_OPENAI_API_KEY`, `LC_GEMINI_API_KEY`, `LC_MISTRAL_API_KEY`, `LC_XAI_API_KEY`).
   - Der Server liefert ihn nie an einen Browser aus. Angezeigt werden nur die letzten 4 Zeichen.
   - Er steht nicht in Logs und wird aus den Prozess-Umgebungsvariablen entfernt.
   - Tests prüfen, dass er in keiner Antwort und nirgends im Klartext auf der Platte auftaucht.
2. **Verschlüsselte Datenbank und Backups (AES-256-GCM).**
   - Der Hauptschlüssel liegt in `data/master.key` und ist auch der Wiederherstellungsschlüssel.
   - Backups entstehen täglich, die letzten 30 bleiben (`LC_BACKUP_KEEP`). Mit `LC_BACKUP_DIR` können sie zusätzlich an einem anderen Ort liegen.
3. **Geräte-Token statt Schlüssel.**
   - Tablets bekommen ein zufälliges 256-Bit-Token als `HttpOnly`-, `Secure`- und `SameSite=Strict`-Cookie.
   - Gespeichert wird nur sein Hash.
   - Ein Tablet darf nur Fragen stellen und seine Seifenblasen sehen.
   - Jedes Gerät ist sofort sperrbar.
4. **Eltern-Login:**
   - Das Passwort wird mit scrypt gespeichert.
   - Nach 5 Fehlversuchen ist der Login 15 Minuten gesperrt.
   - **Passwort vergessen?** Im Anmeldefenster auf „Passwort vergessen?“ tippen, den Wiederherstellungsschlüssel eintippen oder die gespeicherte Schlüsseldatei wählen und ein neues Passwort setzen. Kinder, Gespräche, Einstellungen und alle Backups bleiben erhalten, denn die Verschlüsselung hängt am Schlüssel, nicht am Passwort. Alle anderen Eltern-Anmeldungen enden, Zeitpunkt und Gerät stehen danach im Eltern-Bereich unter „Eltern-Passwort“ und im Server-Protokoll. Nach 5 falschen Schlüsseln ist eine Stunde Sperre (pro Adresse, insgesamt höchstens 10 pro Stunde).
   - **Auch der Schlüssel ist weg?** Solange der Server-Rechner läuft, steht er dort in `data/master.key` (bzw. als `LC_MASTER_KEY` in `.env`), lesbar nur mit Administratorrechten. Ist der Rechner selbst kaputt und der Schlüssel nirgends notiert, lassen sich die Backups nicht mehr öffnen. Dann bleibt nur eine Neuinstallation ohne alte Daten.
   - Die Anmeldung gilt nur, solange die App offen ist (Sitzungs-Cookie). Wer die App schließt, muss sich neu anmelden.
   - War die App länger als 2 Minuten im Hintergrund, ist man ebenfalls abgemeldet. Wichtig auf iPad und Android, wo Wegwischen die App oft nicht wirklich beendet.
   - Nach 3 Minuten ohne Aktion im Eltern-Bereich wird man abgemeldet (`LC_PARENT_IDLE_MIN`), spätestens nach 8 Stunden.
   - „Fertig, zurück zum Kind“ und jeder Wechsel in die Kinderansicht melden sofort ab. So kommt ein Kind nicht in den Eltern-Bereich, wenn ihr ihm das Tablet zurückgebt.
   - **Verlängern am Kindergerät:** Ist ein Limit erreicht (Uhrzeit, Minuten, Fragen), erscheint „Eltern: verlängern“. Mit dem Eltern-Passwort gibt es +15, +30, +60 Minuten oder „für heute“. Das gilt nur heute und steht im Eltern-Bereich. Nach 5 falschen Passwörtern ist 15 Minuten Sperre (gemeinsam mit dem Login).
   - **Farbschloss pro Kind:** Teilen sich Geschwister ein Tablet, kann jedes Kind sein Profil mit 3 von 6 Farben (in Reihenfolge, mit Zeichen für Farbsehschwäche) abschließen: im Sprechbildschirm auf 🔓 tippen. Später auf 🔒 tippen, die jetzigen Farben zeigen und dann Mülleimer (Schloss weg) oder Pfeile (neue Farben) wählen. Jeder Schritt wird sofort angesagt, der Lautsprecher-Knopf wiederholt die Ansage, und der Zurück-Pfeil führt aus dem Schloss-Menü heraus. Eltern können es im Eltern-Bereich festlegen oder zurücksetzen, sehen die Farben aber nicht (gespeichert ist nur ein gesalzener Hash). Nach 5 falschen Versuchen ist 5 Minuten Pause pro Gerät. Ehrlich gesagt: Bei 216 Möglichkeiten ist das ein Kinderschloss gegen Aus-Versehen und neugierige Geschwister, kein echter Schutz.
   - **Bildschirm bleibt an:** In der Kinderansicht hält die App das Display wach (Screen Wake Lock), bis 10 Minuten lang niemand getippt hat (im Eltern-Bereich einstellbar, 0 = das Tablet entscheidet). Geht auf Android/Chrome und auf iPad/iPhone ab iOS 16.4, als App vom Home-Bildschirm ab iOS 18.4. Auf älteren Geräten gilt die „Automatische Sperre“ in den Geräte-Einstellungen. Im Energiesparmodus kann das Gerät die Anfrage ablehnen.
   - Die Kopplung der Kinder-Tablets bleibt davon unberührt.
   - Die Ersteinrichtung braucht den Einrichtungscode vom Server.
5. **Limits auf dem Server:**
   - Uhrzeiten, Minuten und Fragen pro Kind
   - 8 Fragen pro Minute pro Gerät, 600 Zeichen pro Frage
6. **Web-Härtung:**
   - CSRF-Schutz
   - strenge Content-Security-Policy ohne fremde Skripte
   - kein Framing
   - kein Pfad-Ausbruch

**Restrisiken:**

- **Server-Rechner:** Wer ihn vollständig kontrolliert, kann Schlüssel und Daten lesen. Schütze ihn, zum Beispiel mit BitLocker bzw. Festplattenverschlüsselung.
- **Gestohlenes Tablet:** Es kann bis zum Sperren Fragen stellen, innerhalb der Limits.
- **Kosten:** Die Kostenanzeige ist eine Schätzung aus den Token-Zahlen und der Preistabelle. Die harte Grenze setzt das Prepaid-Guthaben bzw. das Ausgabenlimit beim jeweiligen Anbieter. Bei Google warnen Budgets nur, deshalb dort ein Prepaid- bzw. Kontingentlimit setzen.
- **Kinderschutz:** Persona und Claudes Schutzregeln sind gut, aber nicht unfehlbar. Bei anderen Anbietern hängt mehr an der Persona, bei Ollama fast alles. Lies mit, besonders in den ersten Tagen nach einem Anbieterwechsel.

## Datenschutz und Anbieter-Richtlinien

Siehe **[PRIVACY.md](PRIVACY.md)**. Kurz:

- Die Daten bleiben verschlüsselt bei dir.
- Die Spracherkennung läuft standardmäßig bei Google bzw. Apple. Optional kann sie lokal mit Whisper laufen (`LC_STT_URL`).
- Der Text der Fragen geht an den gewählten KI-Anbieter (Standard: Anthropic), bei Ollama an niemanden.

Die Anthropic-Richtlinien für Produkte, die Minderjährige nutzen, und ihre Umsetzung in LittleChat stehen dort ebenfalls.

## Kontext und Kosten im Griff

- Die Persona ist ein eigener, gecachter Systemblock.
- Ältere Gesprächsteile werden zu einer laufenden Zusammenfassung (höchstens 1.500 Zeichen).
- Dazu kommt nur ein Fenster der letzten 12 bis 20 Nachrichten, höchstens 16.000 Zeichen.
- Antworten haben höchstens 4.000 Tokens, der Aufwand steht auf `low`, damit die Antworten schnell kommen.
- Titel und Zusammenfassungen der Seifenblasen erstellt das günstigste Modell des Anbieters, der das Gespräch führt (bei Claude: Haiku).
- Bei anderen Anbietern gilt höchstens 1.500 Tokens pro Antwort (Denk-Tokens eingerechnet), Nachdenken steht wo möglich auf niedrig. Lehnt ein Anbieter einen solchen Zusatzparameter ab, versucht LittleChat es einmal ohne und zeigt das im Eltern-Bereich an.
- Meldet ein Anbieter keine Token-Zahlen, wird großzügig geschätzt, damit die Limits trotzdem greifen.

## Automatische Updates

Der Autostart (Windows-Aufgabe „LittleChat“ als SYSTEM, unter Linux der `systemd`-Dienst) startet den Aufpasser `scripts/supervisor.js`. Er

- startet den Server nach einem Absturz neu (2 s, 5 s, 15 s, dann jede Minute),
- prüft alle 10 Minuten auf eine neue Version und spielt sie ein, sobald seit 5 Minuten kein Kind spricht (nachts zwischen 2 und 5 Uhr immer),
- führt `npm ci` nur aus, wenn sich `package-lock.json` geändert hat,
- beendet den alten Server sauber (laufendes Speichern wird abgeschlossen) und wartet bis zu 60 s, dass der neue „bereit“ meldet und danach weiterläuft. Sonst stellt er die alte Version wieder her und sperrt die neue,
- startet sich selbst neu, wenn ein Update ihn selbst betrifft (der Autostart startet nur einen kleinen Starter, der den Aufpasser bei Bedarf neu startet).

Protokoll: `logs/update.log`, Zustand: `logs/update-status.json`. Die laufende Version steht unten im Eltern-Bereich. Sofort prüfen statt zu warten: eine leere Datei `update-now` in den Programmordner legen. Von Hand zurück auf die vorige Version (nur Installationen aus dem ZIP): leere Datei `rollback-now` (Windows: `LittleChat-zurueck.cmd`). Die zurückgenommene Version wird gesperrt, die nächste neuere kommt wieder automatisch. Abschalten: `LC_AUTOUPDATE=off` in `.env`.

### Bei Familien: signierte Pakete

Installationen aus dem ZIP holen neue Versionen aus dem öffentlichen Repo [LittleChat](https://github.com/TimoHuebner0815/LittleChat), ohne Schlüssel oder Konto:

1. `latest.json` abrufen. Sie enthält Version, Laufnummer, Dateiname, Größe und SHA-256 des Pakets, signiert mit Ed25519. Der öffentliche Prüfschlüssel ist in `scripts/release.js` eingebaut.
2. Nur eine gültig signierte, **neuere** Laufnummer wird genommen. Alte Versionen lassen sich nicht unterschieben.
3. ZIP laden, Größe und SHA-256 prüfen, Pfade prüfen. Nie angefasst werden `data/`, `.env`, `logs/`, `node_modules/` und `piper/`.
4. Überschriebene Dateien landen in `.update/backup/`. Startet die neue Version nicht, kommen sie zurück.

### Prüfrechner: Git und Veröffentlichung

Der Prüfrechner ist ein Git-Klon und holt `main` über einen Deploy-Schlüssel nur mit Leserecht (`data/deploy_key`, eingerichtet mit `scripts/enable-autoupdate-windows.ps1`). Er spult nur vor und bricht ab, wenn im Ordner etwas von Hand geändert wurde.

Läuft ein Stand dort **3 Stunden** seit dem letzten Update (`LC_PUBLISH_AFTER_H`) ohne Rückfall, veröffentlicht der Prüfrechner ihn: ZIP bauen (ohne Tests und interne Werkzeuge, mit `VERSION`), `latest.json` signieren und beides ins öffentliche Repo schieben. Die Schlüssel erzeugt der Aufpasser selbst:

Sofort veröffentlichen, ohne Frist (auf dem Prüfrechner, PowerShell als Administrator im Programmordner):

```powershell
New-Item .\publish-now -ItemType File
```

Innerhalb von 15 Sekunden wird der laufende Stand veröffentlicht; Ergebnis in `logs\update-status.json` (Feld `publish`) und `logs\update.log`.

- `data/release_signing.pem`: privater Signierschlüssel, verlässt den Prüfrechner nie. Der öffentliche Teil liegt in `logs/release_signing.pub` und muss in `scripts/release.js` stehen, sonst veröffentlicht er nicht.
- `data/publish_key`: SSH-Schlüssel zum Hochladen. Öffentlicher Teil in `logs/publish_key.pub`, einzutragen im Repo LittleChat unter Settings › Deploy keys, **mit** „Allow write access“.

Abschalten: `LC_PUBLISH=off`.

## Wiederherstellung auf einem neuen Rechner

1. LittleChat installieren und den Dienst stoppen.
2. Ein Backup aus `data/backups/` als `data/db.enc` hineinkopieren.
3. In `.env` den Wiederherstellungsschlüssel eintragen: `LC_MASTER_KEY=XXXX-...`. Eine eventuell neu erzeugte `data/master.key` vorher löschen.
4. Dienst starten. Danach meldest du dich mit dem alten Eltern-Passwort an.

## Entwicklung

```bash
npm install
npm test                         # Ende-zu-Ende-Tests gegen simulierte KI-Anbieter
LC_INSECURE_COOKIES=1 npm start  # lokal unter http://localhost:8787
```

| Datei | Inhalt |
|---|---|
| `server.js` | Server: Anmeldung, Geräte, Limits, Verschlüsselung, Backups, Gespräche |
| `lib/providers.js` | Eine Schnittstelle für alle KI-Anbieter (Anthropic, OpenAI, Gemini, Mistral, xAI, Ollama) |
| `lib/avatars.js` | Avatare: Zeichenauftrag an die KI, sicheres SVG aus erlaubten Bausteinen |
| `lib/kinderfragen.js` | Kritische Kinderfragen und ihre Prüfung (Kinderfragen-Test) |
| `providers.json` | Anbieter, Modelle und Preise (pflegbar) |
| `docs/anbieter/` | Anleitungen pro Anbieter, im Eltern-Bereich unter `/anleitung/…` |
| `lib/voices.js` | Stimmen-Dienste Google, Azure, ElevenLabs (Sprachausgabe, Preise, Stimmenlisten) |
| `docs/stimmen/` | Anleitungen pro Stimmen-Dienst, im Eltern-Bereich unter `/anleitung/stimmen/…` |
| `kid_persona.md` | Standard-Persönlichkeit (Systemprompt) |
| `kid_safety.md` | Standard-Kinderschutz-Regeln, immer an die Persönlichkeit angehängt |
| `ages/` | Altersstufen (je eine Markdown-Datei mit Altersbereich und Stil-Anweisungen für `{{AGE_GUIDE}}`) |
| `modes/` | Gesprächsmodi (je eine Markdown-Datei mit Symbol, Farbe, Ansage und Anweisungen) |
| `public/` | App für Tablets (PWA) |
| `scripts/` | Installer für Windows und Linux, Aufpasser mit Auto-Update (`supervisor.js`, `release.js`) |
| `release/` | README und Nutzungsbedingungen des öffentlichen Repos LittleChat |
| `test/` | Tests |
| `REQUIREMENTS.md` | Anforderungen mit Status |

Grundsatz für alle Änderungen: keine Kinderdaten aus dem Haushalt hinaus schicken, ohne dass Eltern das ausdrücklich einschalten.

## Lizenz

Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten, siehe [LICENSE](LICENSE). Das Repository ist privat. Fremde Bestandteile und ihre Lizenzen: [THIRD_PARTY.md](THIRD_PARTY.md). Ohne Gewähr. Die Verantwortung für den Betrieb, für die Kosten bei den KI-Anbietern und für die Einhaltung ihrer Nutzungsrichtlinien liegt bei dir.
