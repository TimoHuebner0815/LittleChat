# ElevenLabs-Stimme einrichten

ElevenLabs hat sehr ausdrucksstarke Stimmen. **Achtung: Es ist der mit Abstand teuerste Stimmen-Dienst in LittleChat.** Rechne vorher kurz nach und setz unbedingt die Limits unten.

## Was es kostet (Stand 26.11.2026, laut Vergleichsseiten mit Bezug auf die ElevenLabs-Preisseite)

- **Flash v2.5** (in LittleChat Standard, schnell): ca. 4 US-Cent pro 1.000 Zeichen, also 40 Dollar pro Million.
- **Multilingual v2** (beste Qualität): ca. 8 Cent pro 1.000 Zeichen, also 80 Dollar pro Million.
- Zum Vergleich: Google Chirp 3 HD kostet 30 Dollar pro Million und hat 1 Million gratis. Piper kostet nichts.
- Grob: Eine Minute Vorlesen sind etwa 900 Zeichen. Eine Stunde Vorlesen kostet mit Flash rund 2 Dollar, mit Multilingual rund 4 Dollar.
- Abos: Gratis 10.000 Zeichen-Credits im Monat (nur privat, ob die API damit geht, nennt ElevenLabs nicht klar), Starter 6 Dollar für 30.000 Credits. Credits sind schnell weg: 30.000 Zeichen sind etwa eine halbe Stunde.

LittleChat rechnet die Kosten mit dem vollen Preis in die Monatsbudgets (Kind und gesamt) ein. Feste Ansagen werden verschlüsselt auf dem Server gespeichert und kosten nur einmal.

Aktuelle Preise: [elevenlabs.io/pricing](https://elevenlabs.io/pricing)

## Konto und Limit

1. Konto auf [elevenlabs.io](https://elevenlabs.io) anlegen und ein Abo wählen.
2. **Nutzungsbasierte Abrechnung (Usage-based billing) ausgeschaltet lassen.** Dann ist bei aufgebrauchten Credits Schluss statt teuer weiter.
3. Unter **Voices** eine Stimme in „My Voices“ übernehmen, die gut Deutsch spricht (in der Bibliothek nach Sprache „German“ filtern). LittleChat zeigt nur Stimmen aus deinem Konto.

## Schlüssel

1. Profil › **API Keys** › **Create API Key**.
2. Rechte einschränken: **Text to Speech** und **Voices (lesen)** reichen. Wenn möglich ein **Zeichen-Limit** für den Schlüssel setzen.
3. Schlüssel kopieren (beginnt meist mit `sk_`).

## In LittleChat eintragen

1. Eltern-Bereich › **Stimme** › „ElevenLabs“ wählen.
2. Schlüssel einfügen, **Stimmen laden** (kostet nichts), Stimme und Modell wählen.
3. **▶ Probe** zum Anhören, dann **Speichern und testen**.
4. Pro Kind eine andere Stimme: „Kinder“ › Bearbeiten › Stimme. Tipp: ElevenLabs nur für ein Kind, die anderen mit Piper.

> Was gesendet wird: nur der **Text**, der vorgelesen wird (Antworten und Ansagen, darin auch der Vorname des Kindes). ElevenLabs sitzt in den USA. Die Stimme deines Kindes geht nicht an ElevenLabs.

> Sind die Credits aufgebraucht, fällt ElevenLabs aus oder ist ein Budget erreicht, spricht automatisch **Piper** auf dem Server.
