// Release-Pakete für LittleChat: ZIP bauen und lesen, Manifest signieren und prüfen, Dateien sicher austauschen.
// Ohne fremde Abhängigkeiten (nur Node), damit der Aufpasser auch dann läuft, wenn node_modules kaputt ist.
// Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, nicht mit Anthropic verbunden.

import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";

// Öffentlicher Schlüssel, mit dem jede Installation die Pakete prüft (Ed25519, SPKI, base64).
// Der private Teil liegt nur auf dem Prüf-NUC (data/release_signing.pem) und verlässt ihn nie.
export const RELEASE_PUBKEY = process.env.LC_RELEASE_PUBKEY || "MCowBQYDK2VwAyEAW5SzZhoHKyYgXHdlkrw86QqrZv1RzQ/K/pkVauyxlRU=";
export const RELEASE_REPO = process.env.LC_RELEASE_REPO || "TimoHuebner0815/LittleChat";
export const RELEASE_BASE = process.env.LC_RELEASE_BASE || `https://raw.githubusercontent.com/${RELEASE_REPO}/main/`;

// Nie durch ein Update angefasst: Daten, Einstellungen, Abhängigkeiten, Stimmen, Protokolle
const PROTECTED = [/^data\//, /^logs\//, /^node_modules\//, /^piper\//, /^\.update\//, /^\.publish\//, /^\.git\//, /^\.env$/, /^update-now$/, /^rollback-now$/];
// Ins Paket für Familien kommt NUR, was hier ausdrücklich steht (Allowlist). Neue Dateien im Repo müssen
// entweder hier oder in EXCLUDE stehen, sonst schlägt test/release.test.js fehl.
export const ALLOW = [
  /^server\.js$/, /^kid_persona\.md$/, /^modes\/[\w-]+\.md$/, /^package(-lock)?\.json$/,
  /^README\.md$/, /^PRIVACY\.md$/, /^LICENSE$/, /^THIRD_PARTY\.md$/, /^\.env\.example$/,
  /^Dockerfile$/, /^docker-compose\.yml$/, /^\.dockerignore$/, /^docs\/[\w.-]+\.(png|example)$/, /^docs\/(anbieter|stimmen)\/[a-z]+\.md$/, /^providers\.json$/, /^lib\/[\w-]+\.js$/,
  /^public\/[\w.-]+\.(html|js|css|webmanifest)$/, /^public\/icons\/[\w.-]+\.(png|svg)$/,
  /^scripts\/(supervisor|release)\.js$/, /^scripts\/kinderfragen-test\.mjs$/, /^scripts\/setup-piper\.mjs$/, /^scripts\/(install|uninstall)-windows\.ps1$/, /^scripts\/(install|uninstall)-linux\.sh$/,
  /^LittleChat-(installieren|entfernen|zurueck)\.cmd$/, /^INSTALLATION\.md$/,
];
// Bewusst nicht im Paket: Tests, Entwicklung, Werkzeuge nur für den Prüf-NUC, Vorher/Nachher-Bilder aus PRs
export const EXCLUDE = [/^test\//, /^\.github\//, /^release\//, /^REQUIREMENTS\.md$/, /^scripts\/deploy-key\.mjs$/, /^scripts\/enable-autoupdate-windows\.ps1$/, /^\.gitignore$/, /^docs\/eltern-bereich\//];
export const isProtected = (p) => PROTECTED.some((r) => r.test(p));
export const inPackage = (p) => ALLOW.some((r) => r.test(p)) && !EXCLUDE.some((r) => r.test(p)) && !isProtected(p);

// Letzte Sicherung vor dem Veröffentlichen: nichts Persönliches vom Prüf-NUC im Paket.
// extra: Zeichenketten, die nie vorkommen dürfen (z. B. eigene Adresse, Programmpfad), vom Aufrufer ermittelt.
const SECRET_PATTERNS = [
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, "privater Schlüssel"],
  [/sk-ant-[A-Za-z0-9_-]{12,}/, "Anthropic-API-Schlüssel"],
  [/sk-[A-Za-z0-9]{32,}/, "API-Schlüssel"],
  [/\b[a-z0-9-]+\.(?!tailX+\.)[a-z0-9-]+\.ts\.net\b/i, "echte Tailscale-Adresse"],
  [/[\w.%+-]+@(gmail|googlemail|gmx|web|outlook|hotmail|yahoo|icloud|t-online|posteo|mailbox)\.[a-z]{2,}/i, "private E-Mail-Adresse"],
  [/[A-Za-z]:\\Users\\[^\\\s"']+/i, "Windows-Benutzerpfad"],
];
export function scanForPersonalData(entries, extra = []) {
  const found = [];
  for (const { name, data } of entries) {
    const text = data.toString("latin1");
    for (const [re, what] of SECRET_PATTERNS) if (re.test(text)) found.push(`${name}: ${what}`);
    for (const x of extra) if (x && x.length >= 6 && text.toLowerCase().includes(x.toLowerCase())) found.push(`${name}: enthält „${x.slice(0, 3)}…“`);
  }
  return found;
}
const safePath = (p) => typeof p === "string" && p.length > 0 && p.length < 300 && !p.startsWith("/") && !/^[a-zA-Z]:/.test(p) &&
  !p.includes("\\") && !p.split("/").some((s) => s === ".." || s === "." || s === "");

// ------------------------------------------------------------------ ZIP
const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
export function crc32(buf) { let c = 0xffffffff; for (const b of buf) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }

export function writeZip(files) { // files: [{ name, data }]
  const parts = [], central = [];
  let offset = 0;
  for (const { name, data } of files) {
    const nameBuf = Buffer.from(name, "utf8"), comp = zlib.deflateRawSync(data, { level: 9 }), crc = crc32(data);
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8);
    h.writeUInt16LE(0, 10); h.writeUInt16LE(0x21, 12); // 1980-01-01: feste Zeit, damit Pakete reproduzierbar sind
    h.writeUInt32LE(crc, 14); h.writeUInt32LE(comp.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(nameBuf.length, 26); h.writeUInt16LE(0, 28);
    const c = Buffer.alloc(46);
    // „Erstellt unter Unix“ mit Rechten 755 für Skripte bzw. 644 sonst, damit unzip unter Linux
    // ./scripts/install-linux.sh direkt ausführbar entpackt (Windows ignoriert das)
    c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(0x0314, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10);
    c.writeUInt16LE(0, 12); c.writeUInt16LE(0x21, 14); c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(data.length, 24);
    c.writeUInt16LE(nameBuf.length, 28); c.writeUInt32LE(((/\.sh$/.test(name) ? 0o100755 : 0o100644) << 16) >>> 0, 38); c.writeUInt32LE(offset, 42);
    parts.push(h, nameBuf, comp);
    central.push(c, nameBuf);
    offset += 30 + nameBuf.length + comp.length;
  }
  const cd = Buffer.concat(central), e = Buffer.alloc(22);
  e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(files.length, 8); e.writeUInt16LE(files.length, 10); e.writeUInt32LE(cd.length, 12); e.writeUInt32LE(offset, 16);
  return Buffer.concat([...parts, cd, e]);
}

export function readZip(buf) {
  let e = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error("ZIP beschädigt (kein Verzeichnis)");
  const count = buf.readUInt16LE(e + 10);
  let p = buf.readUInt32LE(e + 16);
  const out = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error("ZIP beschädigt (Eintrag)");
    const method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), lho = buf.readUInt32LE(p + 42);
    const name = buf.toString("utf8", p + 46, p + 46 + nlen);
    p += 46 + nlen + xlen + clen;
    if (name.endsWith("/")) continue; // Ordner
    if (!safePath(name)) throw new Error("Unzulässiger Pfad im Paket: " + name);
    if (buf.readUInt32LE(lho) !== 0x04034b50) throw new Error("ZIP beschädigt (Kopf)");
    const start = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
    const raw = buf.subarray(start, start + csize);
    const data = method === 8 ? zlib.inflateRawSync(raw, { maxOutputLength: 50 * 1024 * 1024 }) : method === 0 ? Buffer.from(raw) : null;
    if (!data) throw new Error("Unbekannte Kompression in " + name);
    if (data.length !== usize || crc32(data) !== crc) throw new Error("Prüfsumme falsch: " + name);
    out.push({ name, data });
  }
  return out;
}

// ------------------------------------------------------------------ Signatur
export function newSigningKey() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519");
  return { pem: privateKey.export({ type: "pkcs8", format: "pem" }), pub: publicKey.export({ type: "spki", format: "der" }).toString("base64") };
}
export const pubFromPem = (pem) => crypto.createPublicKey(pem).export({ type: "spki", format: "der" }).toString("base64");
export function signManifest(payloadObj, pem) {
  const payload = JSON.stringify(payloadObj);
  return { payload, signature: crypto.sign(null, Buffer.from(payload), pem).toString("base64") };
}
export function verifyManifest(signed, pub = RELEASE_PUBKEY) {
  if (!pub) throw new Error("Kein öffentlicher Prüfschlüssel eingebaut");
  if (typeof signed?.payload !== "string" || typeof signed?.signature !== "string") throw new Error("Manifest unvollständig");
  const key = crypto.createPublicKey({ key: Buffer.from(pub, "base64"), format: "der", type: "spki" });
  if (!crypto.verify(null, Buffer.from(signed.payload), key, Buffer.from(signed.signature, "base64"))) throw new Error("Signatur ungültig");
  const m = JSON.parse(signed.payload);
  if (m.app !== "LittleChat" || !m.version || !Number.isFinite(m.seq) || !/^releases\/[\w.-]+\.zip$/.test(m.file || "") || !/^[0-9a-f]{64}$/.test(m.sha256 || ""))
    throw new Error("Manifest ungültig");
  return m;
}
export const sha256 = (buf) => crypto.createHash("sha256").update(buf).digest("hex");

// ------------------------------------------------------------------ Paket bauen (auf dem Prüf-NUC)
// files: Pfade relativ zu root (aus git ls-files). Fügt VERSION hinzu.
export function buildPackage(root, files, info) {
  const list = files.filter(inPackage).filter((f) => fs.existsSync(path.join(root, f))).sort();
  const version = { app: "LittleChat", version: info.version, seq: info.seq, commit: info.commit };
  const entries = list.map((name) => ({ name, data: fs.readFileSync(path.join(root, name)) }));
  entries.push({ name: "VERSION", data: Buffer.from(JSON.stringify(version, null, 1) + "\n") });
  // Nutzungserlaubnis für Familien (privat, im eigenen Haushalt) liegt dem Paket bei
  const terms = path.join(root, "release", "LICENSE.txt");
  if (fs.existsSync(terms)) entries.push({ name: "NUTZUNGSBEDINGUNGEN.txt", data: fs.readFileSync(terms) });
  const found = scanForPersonalData(entries, info.forbidden || []);
  if (found.length) throw new Error("Paket enthält persönliche Daten, nicht veröffentlicht: " + found.join("; "));
  return { zip: writeZip(entries), files: entries.map((e) => e.name), version };
}

// ------------------------------------------------------------------ Paket einspielen (bei Familien)
// Schreibt die neuen Dateien, merkt sich alles Überschriebene für die Rückkehr. Gibt eine Rückkehr-Funktion zurück.
export function installFiles(root, entries, stateDir) {
  const listFile = path.join(stateDir, "files.json");
  const oldList = (() => { try { return JSON.parse(fs.readFileSync(listFile, "utf8")); } catch { return []; } })();
  const backupDir = path.join(stateDir, "backup");
  fs.rmSync(backupDir, { recursive: true, force: true });
  fs.mkdirSync(backupDir, { recursive: true });
  const newNames = new Set(entries.map((e) => e.name));
  const touched = [...new Set([...entries.map((e) => e.name), ...oldList.filter((n) => !newNames.has(n))])];
  const existed = [];
  for (const name of touched) {
    if (isProtected(name) || !safePath(name)) throw new Error("Unzulässiger Pfad: " + name);
    const f = path.join(root, name);
    if (fs.existsSync(f)) { const b = path.join(backupDir, name); fs.mkdirSync(path.dirname(b), { recursive: true }); fs.copyFileSync(f, b); existed.push(name); }
  }
  fs.writeFileSync(path.join(stateDir, "backup.json"), JSON.stringify({ existed, touched, oldList }));
  for (const { name, data } of entries) { const f = path.join(root, name); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, data); }
  for (const name of oldList) if (!newNames.has(name) && !isProtected(name)) fs.rmSync(path.join(root, name), { force: true });
  fs.writeFileSync(listFile, JSON.stringify([...newNames]));
  return () => restoreFiles(root, stateDir);
}
export function restoreFiles(root, stateDir) {
  const b = JSON.parse(fs.readFileSync(path.join(stateDir, "backup.json"), "utf8"));
  const existed = new Set(b.existed);
  for (const name of b.touched) {
    const f = path.join(root, name);
    if (existed.has(name)) { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.copyFileSync(path.join(stateDir, "backup", name), f); }
    else fs.rmSync(f, { force: true });
  }
  fs.writeFileSync(path.join(stateDir, "files.json"), JSON.stringify(b.oldList));
}

// ------------------------------------------------------------------ SSH-Schlüssel (Deploy-Keys)
export function sshKeygen(file, comment) {
  if (fs.existsSync(file)) return fs.readFileSync(file + ".pub", "utf8").trim();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const cands = process.platform === "win32"
    ? ["C:\\Program Files\\Git\\usr\\bin\\ssh-keygen.exe", path.join(process.env.SystemRoot || "C:\\Windows", "System32", "OpenSSH", "ssh-keygen.exe"), "ssh-keygen"]
    : ["ssh-keygen"];
  const bin = cands.find((c) => c === "ssh-keygen" || fs.existsSync(c));
  const r = spawnSync(bin, ["-q", "-t", "ed25519", "-N", "", "-C", comment, "-f", file], { encoding: "utf8", windowsHide: true });
  if (r.status !== 0) throw new Error("ssh-keygen fehlgeschlagen: " + (r.error?.message || r.stderr));
  return fs.readFileSync(file + ".pub", "utf8").trim();
}
