#!/usr/bin/env node
// Kinderfragen-Test von der Kommandozeile: stellt jedem Anbieter, für den ein Schlüssel da ist, die kritischen
// Kinderfragen mit der Standard-Persona (Testkind Mia, 7 Jahre) und zeigt Antworten und Auffälligkeiten.
// Im Eltern-Bereich gibt es denselben Test (optional) mit der dort eingestellten Persona.
//
// Aufruf (Schlüssel nur als Umgebungsvariable, nie als Argument, damit sie nicht im Verlauf landen):
//   PowerShell:  $env:LC_OPENAI_API_KEY="sk-…"; node scripts/kinderfragen-test.mjs
//   Linux/macOS: LC_OPENAI_API_KEY=sk-… node scripts/kinderfragen-test.mjs
// Variablen: ANTHROPIC_API_KEY, LC_OPENAI_API_KEY, LC_GEMINI_API_KEY, LC_MISTRAL_API_KEY, LC_XAI_API_KEY, LC_OLLAMA_URL
// Optionen:  --provider openai   nur diesen Anbieter     --model gpt-6-luna   bestimmtes Modell
//            --mode lernen       anderen Gesprächsmodus aus modes/ anhängen (Standard: erkunden, --mode keiner = ohne)
//            --runs 3            jede Frage mehrmals stellen (Antworten schwanken)
// Ergebnis: Rückgabecode 0 = alles unauffällig, 1 = Auffälligkeiten (Antworten trotzdem selbst lesen!).
// Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import * as AI from "../lib/providers.js";
import { QUESTIONS, judge, testKid } from "../lib/kinderfragen.js";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const args = Object.fromEntries(process.argv.slice(2).join(" ").split(/\s*--/).filter(Boolean).map((a) => { const [k, ...v] = a.split(/\s+/); return [k, v.join(" ") || true]; }));
const catalog = AI.loadCatalog(ROOT, path.join(ROOT, "data"));
const KEYS = { anthropic: process.env.ANTHROPIC_API_KEY, openai: process.env.LC_OPENAI_API_KEY, gemini: process.env.LC_GEMINI_API_KEY,
  mistral: process.env.LC_MISTRAL_API_KEY, xai: process.env.LC_XAI_API_KEY, ollama: process.env.LC_OLLAMA_URL ? "lokal" : "" };

// Persona wie im Server, für ein 7-jähriges Kind (Sprachstufe Grundschule)
const kid = testKid();
let persona = fs.readFileSync(path.join(ROOT, "kid_persona.md"), "utf8").replace(/<!--[\s\S]*?-->/g, "").trim()
  .replaceAll("{{NAME}}", kid.name).replaceAll("{{AGE}}", "7").replaceAll("{{APP}}", process.env.LC_APP_NAME || "LittleChat")
  .replaceAll("{{TODAY}}", new Intl.DateTimeFormat("de-DE", { dateStyle: "full" }).format(new Date()))
  .replaceAll("{{AGE_GUIDE}}", "Sprich wie mit einem Grundschulkind der ersten bis dritten Klasse: einfache Sätze, schwierige Wörter sofort erklären, anschauliche Beispiele, drei bis vier Sätze pro Antwort.");
args.mode ??= "erkunden";
if (args.mode !== "keiner") {
  const f = path.join(ROOT, "modes", String(args.mode) + ".md");
  if (fs.existsSync(f)) persona += "\n\n" + fs.readFileSync(f, "utf8");
  else console.warn(`Modus ${args.mode} nicht gefunden (${f}), teste ohne.`);
}

const providers = (args.provider ? [String(args.provider)] : AI.PROVIDER_IDS).filter((p) => KEYS[p]);
if (!providers.length) {
  console.error("Kein Schlüssel gefunden. Beispiel: LC_OPENAI_API_KEY=sk-… node scripts/kinderfragen-test.mjs");
  process.exit(2);
}
const runs = Math.max(1, Math.min(5, Number(args.runs) || 1));
let anyBad = false;
for (const pid of providers) {
  const cat = catalog.providers[pid];
  let model = typeof args.model === "string" ? args.model : Object.entries(cat.models).find(([, m]) => m.default)?.[0];
  if (pid === "ollama" && !model) model = (await AI.listModels("ollama", "", process.env.LC_OLLAMA_URL))[0];
  console.log(`\n=== ${cat.label} · ${model} ===`);
  if (cat.warning) console.log("⚠ " + cat.warning);
  let ok = 0, total = 0, usd = 0;
  for (const q of QUESTIONS) for (let i = 0; i < runs; i++) {
    total++;
    try {
      const r = await AI.chat({ catalog, provider: pid, key: KEYS[pid], url: process.env.LC_OLLAMA_URL, model, system: persona, maxTokens: 1500, messages: [{ role: "user", content: q.q }] });
      usd += AI.costUsd(catalog, pid, model, r.usage);
      const j = judge(q, r.text, r.refused);
      if (j.ok) ok++;
      console.log(`\n${j.ok ? "✓" : "✗"} [${q.topic}] ${q.q}\n  → ${(r.text.trim() || (r.refused ? "(vom Anbieter blockiert)" : "(leer)")).replace(/\n/g, "\n    ")}`);
      if (!j.ok) console.log("  ! " + j.problems.join(" · "));
    } catch (e) {
      console.log(`\n✗ [${q.topic}] ${q.q}\n  ! Fehler: ${AI.errorText(e, pid)}`);
    }
  }
  if (AI.degraded[pid]) console.log(`\n! Zusatzparameter abgelehnt: ${AI.degraded[pid].params.join(", ")} (${AI.degraded[pid].error})`);
  console.log(`\nErgebnis ${cat.label}: ${ok}/${total} unauffällig · Kosten ca. $${usd.toFixed(4)}`);
  if (ok < total) anyBad = true;
}
console.log("\nHinweis: Die Prüfung sucht nur nach Stichworten. Bitte jede Antwort selbst lesen.");
process.exit(anyBad ? 1 : 0);
