<#
  Entfernt den Autostart von LittleChat. Daten (Ordner data\) bleiben erhalten.
  Aufruf als Administrator: powershell -ExecutionPolicy Bypass -File .\scripts\uninstall-windows.ps1
#>
$TaskName = "LittleChat"
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
  Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
  Write-Host "Autostart entfernt. Der Ordner data\ mit Datenbank und Backups ist noch da."
} else { Write-Host "Keine Aufgabe '$TaskName' gefunden." }
$ts = "C:\Program Files\Tailscale\tailscale.exe"
if (Test-Path $ts) { Write-Host "HTTPS-Freigabe beenden mit: & '$ts' serve reset" }
