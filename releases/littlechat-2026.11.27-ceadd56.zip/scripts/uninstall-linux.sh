#!/usr/bin/env bash
# LittleChat entfernen (Linux).  Aufruf: sudo bash scripts/uninstall-linux.sh [--delete-data]
# Entfernt Dienst, HTTPS-Freigabe und den Benutzer „littlechat“. Daten bleiben, außer du bestätigst das Löschen.
# Tailscale bleibt installiert (entfernen: sudo apt remove tailscale).
# Copyright (c) 2026 LittleChat. Alle Rechte vorbehalten. Inoffiziell, nicht mit Anthropic verbunden.
set -uo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
[ "$(id -u)" -eq 0 ] || { echo "Bitte mit sudo starten."; exit 1; }
DEL=0; [ "${1:-}" = "--delete-data" ] && DEL=1
systemctl disable --now littlechat 2>/dev/null && echo "Dienst gestoppt und entfernt." || echo "Kein Dienst littlechat gefunden."
rm -f /etc/systemd/system/littlechat.service; systemctl daemon-reload
if command -v tailscale >/dev/null; then
  read -r -p "HTTPS-Freigabe von LittleChat in Tailscale beenden? (J/n) " r </dev/tty || true
  [[ "${r:-}" =~ ^[nN] ]] || { tailscale serve reset && echo "HTTPS-Freigabe beendet."; }
fi
if [ "$DEL" = 0 ]; then
  echo; echo "Sollen auch alle Daten gelöscht werden (Kinder, Gespräche, Figuren, Backups, Schlüssel) in $APP_DIR?"
  echo "Das lässt sich NICHT rückgängig machen."
  read -r -p "Zum Löschen LÖSCHEN eintippen, sonst Enter: " r </dev/tty || true
  [ "${r:-}" = "LÖSCHEN" ] && DEL=1
fi
if [ "$DEL" = 1 ]; then cd /; rm -rf "$APP_DIR"; echo "LittleChat und alle Daten gelöscht."
else [ -n "${SUDO_USER:-}" ] && chown -R "$SUDO_USER": "$APP_DIR"; echo "Der Ordner $APP_DIR mit deinen Daten bleibt. Neu einrichten: sudo bash scripts/install-linux.sh"; fi
userdel littlechat 2>/dev/null || true
[ -d /opt/littlechat-node ] && rm -rf /opt/littlechat-node && echo "Mitgebrachtes Node.js entfernt."
