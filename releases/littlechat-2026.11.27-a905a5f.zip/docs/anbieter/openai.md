# ChatGPT (OpenAI) einrichten

LittleChat kann statt Claude auch Modelle von OpenAI nutzen. Qualität und Preis sind ähnlich. Persona und Kinderschutz-Regeln wurden mit Claude entwickelt, darum ist OpenAI mit LittleChat **ungetestet**. Lies die Gespräche anfangs mit. Ein ChatGPT-Abo (Plus/Pro) funktioniert hier nicht, du brauchst einen API-Schlüssel.

## Schlüssel anlegen

1. Öffne [platform.openai.com](https://platform.openai.com) und melde dich an.
2. Unter **Settings › Billing** Guthaben aufladen (Prepaid), z. B. 5 bis 10 Dollar. **Auto-Recharge ausgeschaltet lassen.**
3. Unter **Settings › Projects** ein Projekt „Kinder“ anlegen. Dort unter **Limits** ein monatliches Budget setzen und nur die nötigen Modelle erlauben.
4. Im Projekt „Kinder“ unter **API keys** einen neuen Schlüssel erstellen. Er beginnt mit `sk-`.

## In LittleChat eintragen

1. Eltern-Bereich › **KI-Anbieter** › **ChatGPT (OpenAI)**.
2. Schlüssel einfügen, **Prüfen & speichern**. Die Prüfung kostet nichts, sie fragt nur die verfügbaren Modelle ab.
3. Häkchen setzen: **„Ich habe verstanden, ungetestet“**. Erst dann ist OpenAI wählbar.
4. OpenAI als Standard für alle Kinder oder nur für einzelne Kinder wählen.
5. Optional: **Jetzt testen** (Kinderfragen-Test) und die Antworten lesen.

> Was gesendet wird: der Text der Frage, die Persona mit Vorname und Alter des Kindes und der Gesprächsverlauf. OpenAI verarbeitet die Daten in den USA. Laut OpenAI werden API-Daten nicht zum Training genutzt.

Die Menüs der Anbieter-Seiten ändern sich gelegentlich. Die Schritte bleiben im Kern gleich: Konto, Guthaben, Limit, Schlüssel.

> **Verantwortung:** Eltern tragen die Verantwortung für die Nutzung durch ihre Kinder und haften im Rahmen ihrer Aufsichtspflicht. Behaltet Themen und Gespräche im Blick. Nutzung auf eigene Gefahr.
