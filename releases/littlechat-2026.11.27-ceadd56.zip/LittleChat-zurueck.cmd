@echo off
rem Zurueck auf die vorige Version von LittleChat: doppelt anklicken.
rem Die aktuelle Version wird danach uebersprungen, bis eine neuere erscheint.
type nul > "%~dp0rollback-now" 2>nul
if errorlevel 1 (
  echo Konnte die Anforderung nicht anlegen. Bitte mit rechter Maustaste "Als Administrator ausfuehren".
) else (
  echo Angefordert. In etwa 30 Sekunden laeuft die vorige Version.
  echo Ergebnis steht in logs\update.log
)
pause
